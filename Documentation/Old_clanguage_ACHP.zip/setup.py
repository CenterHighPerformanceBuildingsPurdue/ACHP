#!/usr/bin/env python

"""
setup.py file for ACHP core code
"""

from distutils.core import setup, Extension

import subprocess

subprocess.call(['swig','-python','PythonEntry.i'])

CoolProp_module = Extension('_ACHP',
                           sources=['PythonEntry_wrap.c', 
                           'PythonEntry.c',
                           'Compressor.c',
                           'Condenser.c',
                           'Correlations.c',
                           'IHX.c',
                           'Solvers.c',
                           'RefCycleSolver.c',
                           'IndoorCoil.c',
                           'Evaporator.c',
                           'LineSet.c',
                           'Props/HumAir.c',
                           'Props/CoolProp.c',
                           'Props/R290.c',
                           'Props/R744.c',
                           'Props/R134a.c',
                           'Props/R32.c',
                           'Props/Brine.c',
                           'Props/R717.c',
                           'Props/R410A.c',
                           'Props/R404A.c',
                           'Props/R407C.c',
                           'Props/R507A.c',
                           'Props/Nitrogen.c',
                           'Props/Argon.c'
                           ],
                           include_dirs=['Props']
                           )

setup (name = 'ACHP',
       version = '0.0',
       author      = "Ian Bell",
       description = """ACHP""",
       ext_modules = [CoolProp_module],
       py_modules = ["CoolProp"],
       )
