#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>

#include "string.h"
#include <stdio.h>
#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"
#include "IHX.h"
#include "Solvers.h"
#include "RefCycleSolver.h"

static char * PrimaryRef;
static char * SecondaryRef;
static struct IHXInputVals Inputs;
static struct IHXOutputVals Outputs;

// Private function prototypes
static double Superheat(double w_superheat);
static double TwoPhase(double w_2phase);
static double Subcool(double w_subcool);

 static void swap(double *x, double *y)
 {
        double temp;
        temp = *x;
        *x = *y;
        *y = temp;
 }

static double minVal(double x1, double x2)
{
	if (x1<x2)
		return x1;
	else
		return x2;
}

static double maxVal(double x1, double x2)
{
	if (x1>x2)
		return x1;
	else
		return x2;
}


int IHX_Calculate(char * PrimaryRef_, char * SecondaryRef_,struct IHXInputVals *Inputs_, struct IHXOutputVals *Outputs_)
{
    double w_subcool,w_2phase,w_superheat,xin_r;
	extern int runFail;

	//Copy values from passed variables to temporary global variables
	Inputs=*Inputs_;
	Outputs=*Outputs_;
	PrimaryRef=PrimaryRef_;
	SecondaryRef=SecondaryRef_;

	//Set Exists_subcool to uninitialized value
	Outputs.Exists_subcool=-1;

	if (Inputs.Tin_g>Props('M','T',283,'P',0.0,SecondaryRef))
	{
		fprintf(stderr,"Error: IHX inlet temperature above fluid correlation max temp\n");
		runFail=1;
		strcpy(runFailString,"Error: IHX inlet temperature above fluid correlation max temp");
		return FUNC_FAILED;
	}

	//if(1<0)
	//{
	//	// Geometric parameters
	//	Inputs.FPN_g=Inputs.N;
	//	Inputs.FPN_r=Inputs.N;
	//	Inputs.V_r = Inputs.FPdelta*Inputs.FPW*Inputs.L*Inputs.FPN_g; //'Internal volume of refrigerant side of one channel
	//	Inputs.A_g = 2*Inputs.FPW*Inputs.L;
	//	Inputs.A_r = 2*Inputs.FPW*Inputs.L;
	//	Inputs.Dh_g= 2 * Inputs.FPdelta*Inputs.FPW / (Inputs.FPdelta+Inputs.FPW);
	//	Inputs.Dh_r= 2 * Inputs.FPdelta*Inputs.FPW / (Inputs.FPdelta+Inputs.FPW);
	//	Inputs.G_g=Inputs.mdot_g/(Inputs.FPN_g*Inputs.FPL*Inputs.FPdelta);
	//	Inputs.G_r=Inputs.mdot_r/(Inputs.FPN_r*Inputs.FPL*Inputs.FPdelta);
	//	Inputs.mdot_IHX_g=Inputs.mdot_g/Inputs.FPN_g;
	//	Inputs.mdot_IHX_r=Inputs.mdot_r/Inputs.FPN_r;
	//}
	//else
	//{
		// Coaxial heat exchanger
		Inputs.V_r = pi * Inputs.OD_i*Inputs.OD_i / 4.0 * Inputs.L;				//'TotalInternal volume of refrigerant side
		Inputs.A_g = pi * Inputs.ID_o * Inputs.L;
		Inputs.A_r = pi * Inputs.OD_i * Inputs.L;
		Inputs.Dh_g=Inputs.OD_o-Inputs.ID_o;									//[m]
		Inputs.Dh_r=Inputs.OD_i;												//[m]
		Inputs.G_g=Inputs.mdot_g/(pi*(Inputs.OD_o*Inputs.OD_o-Inputs.ID_o*Inputs.ID_o)/4.0*(double)Inputs.N);		//[kg/m^2-s]
		Inputs.G_r=Inputs.mdot_r/(pi*Inputs.OD_i*Inputs.OD_i/4.0*(double)Inputs.N);	//[kg/m^2-s]
		Inputs.mdot_IHX_g=Inputs.mdot_g/((double)Inputs.N);
		Inputs.mdot_IHX_r=Inputs.mdot_r/((double)Inputs.N);
	/*}*/

	//Solve for the fraction of length which gives saturation temp between essentially 0% and 100%
	w_superheat=Dekker(Superheat,0.000001,0.9999999,0.01);
	Outputs.w_superheat=w_superheat;
	/*Evaluate with new superheated fraction since Dekker sometimes 
	uses worse guess values in the convergence process, potentially 
	leaving a stale output state
	*/
	Superheat(w_superheat);

	//// Try to use the remaining length for the 2phase region.
	TwoPhase(1-w_superheat);

	/*
	If you can get all the refrigerant to condense, use Dekker to solve
	for the amount of length that is two-phase. 
	*/
	if (Outputs.Exists_subcool)
	{
		/* 
		There is a subcooled region, so first solve for the length of tube which
		yields the heat transfer equal to the full latent heat
		*/
		w_2phase=Dekker(TwoPhase,0.000001,1-w_superheat,0.01);
		/*Evaluate with new two-phase fraction since Dekker sometimes 
		uses worse guess values in the convergence process, potentially 
		leaving a stale output state
		*/
		TwoPhase(w_2phase);
		Outputs.w_2phase=w_2phase;
		/* Then run the subcooled section */
		w_subcool=1-w_superheat-w_2phase;
		Subcool(w_subcool);
		Outputs.w_subcool=w_subcool;
		Outputs.hin_r=Props('H','T',Inputs.Tsat_r,'Q',0,PrimaryRef)*1000-Outputs.Q_subcool/(Inputs.mdot_r); //Find subcooled enthalpy at inlet
		Outputs.sin_r=Props('S','T',Outputs.Tin_r,'P',Inputs.pout_r,PrimaryRef)*1000;						//[J/kg]
	}
	else
	{
		//There is no subcooled section
		Outputs.w_2phase=1-w_superheat;
		Outputs.Q_subcool=0.0;
		Outputs.Charge_subcool=0.0;
		Outputs.DP_g_subcool=0.0;
		Outputs.DP_r_subcool=0.0;
		Outputs.w_subcool=0.0;
		Outputs.h_r_subcool=0.0;
		Outputs.h_g_subcool=0.0;
		Outputs.Re_g_subcool=0.0;

		Outputs.hin_r=Props('H','T',Inputs.Tsat_r,'Q',1,PrimaryRef)*1000-Outputs.Q_2phase/(Inputs.mdot_r); //Find two-phase enthalpy at inlet
		xin_r=(Outputs.hin_r-Props('H','T',Inputs.Tsat_r,'Q',0,PrimaryRef)*1000)/
			(Props('H','T',Inputs.Tsat_r,'Q',1,PrimaryRef)*1000-Props('H','T',Inputs.Tsat_r,'Q',0,PrimaryRef)*1000);
		Outputs.Tin_r=Inputs.Tsat_r;
		Outputs.sin_r=Props('S','T',Inputs.Tsat_r,'Q',xin_r,PrimaryRef)*1000;
		Outputs.xin_r=xin_r;
	}

	Outputs.Charge = Outputs.Charge_subcool+Outputs.Charge_2phase + Outputs.Charge_superheat;
	Outputs.Q = Outputs.Q_subcool+Outputs.Q_2phase + Outputs.Q_superheat;
	Outputs.DP_r=Outputs.DP_r_superheat+Outputs.DP_r_2phase+Outputs.DP_r_subcool;
	Outputs.hout_r=Props('H','T',Inputs.Tout_r,'P',Inputs.pout_r,PrimaryRef)*1000;						//[J/kg]
	Outputs.sout_r=Props('S','T',Inputs.Tout_r,'P',Inputs.pout_r,PrimaryRef)*1000;						//[J/kg]
	

	
	if (Outputs.Tout_g < Props('F','T',283,'P',0.0,SecondaryRef))
	{
		fprintf(stderr,"Outlet temp of IHX below freezing point");
	}
	//Copy values back to passed variables
	*Inputs_=Inputs;
	*Outputs_=Outputs;
	return 0;
}
static double Superheat(double w_superheat)
{
	double mdot_r,pout_r,Tsat_r,Tout_r,mdot_g,Tin_g,Tinter_g,pin_g,xin_r,OD_g,ID_g,OD_r,L,
		V_r,A_g_superheat,A_r_superheat,f_r_superheat,h_r_superheat,h_g_superheat,
		f_g_superheat,cp_r,cp_g,Cmin,Cmax,Cr,UA_superheat,Ntu_superheat,epsilon_superheat,
		Q_superheat,Tsat_r_temp,dT_error,rho_superheat,charge_superheat,Dh_r,G_r,v_r,
		dp_dz_r,DP_r,Dh_g,G_g,v_g,dp_dz_g,DP_g,Re_r_superheat,Re_g_superheat;
	int NIHX;

	// Retrieve values from the 
	// structure for code compactness
    mdot_r =	Inputs.mdot_r;
	pout_r =	Inputs.pout_r;
	Tsat_r =	Inputs.Tsat_r;
	Tout_r =	Inputs.Tout_r;
    mdot_g =	Inputs.mdot_g;
    Tin_g =		Inputs.Tin_g;
	Tinter_g =	Tin_g; //Initial guess; will be overwritten
    pin_g =		Inputs.pin_g;
    xin_r =		Inputs.xin_r;
    OD_g =		Inputs.OD_o;
    ID_g =		Inputs.ID_o;
    OD_r =		Inputs.OD_i;
    L =			Inputs.L;
	NIHX =		Inputs.N;

	//Check input state
	if (Tout_r>Tin_g)
	{
		fprintf(stderr,"IHX ref. output temp (%g K) is greater than inlet glycol temp (%g K)\n",Tout_r,Tin_g);
	}
	

	// ************************************************************************************
	//									SUPERHEATED PART 
	// ************************************************************************************

	// Geometric parameters
    V_r = Inputs.V_r; //'Internal volume of refrigerant side
	A_g_superheat = Inputs.A_g * w_superheat;
	A_r_superheat = Inputs.A_r * w_superheat;
	Dh_g=Inputs.Dh_g;																
	Dh_r=Inputs.Dh_r;																
	G_g=Inputs.G_g;
	G_r=Inputs.G_r;

	/* 
	Friction factor and HTC in the refrigerant and glycol(Water) portions.
	Average fluid temps are used for the calculation of properties 
		Average temp of refrigerant is average of sat. temp and outlet temp
		Average temp of refrigerant is average of glycol inlet temp and interface temp 
			(initially unknown)
			
	Secondary fluid is in the outer annulus, refrigerant on the inside 
	*/
	f_h_1phase_Tube(Inputs.mdot_IHX_r, OD_r, (Tsat_r + Tout_r) / 2.0, pout_r, PrimaryRef, 		//[kg/s],[m],[K],[kPa]
		"Single",&f_r_superheat, &h_r_superheat, &Re_r_superheat);								//[-],[W/m^2-K],[-]
	cp_r = Props('C', 'T', (Tsat_r + Tout_r) / 2.0, 'P', pout_r, PrimaryRef)*1000;				//[J/kg-K]

	f_h_1phase_Annulus(Inputs.mdot_IHX_g, OD_g, ID_g, (Tinter_g+Tin_g)/2.0, pin_g, SecondaryRef,//[kg/s],[m],[K],[kPa]
		"Single", &f_g_superheat, &h_g_superheat, &Re_g_superheat);								//[-],[W/m^2-K],[-]
	cp_g = Props('C', 'T', (Tinter_g+Tin_g)/2.0, 'P', pin_g, SecondaryRef)*1000;				//[J/kg-K]
   
	/* 
	Counter-flow in the superheated region.  
	Using effectiveness-Ntu relationships for counter-current flow with non-zero Cr.
	*/
		UA_superheat = 1 / 
			(1/(h_r_superheat * A_r_superheat) + 1 / (h_g_superheat * A_g_superheat));	
																				//[W/K]
		Cmin = minVal(cp_r * mdot_r, cp_g * mdot_g);							//[W/K]
		Cmax = maxVal(cp_r * mdot_r, cp_g * mdot_g);							//[W/K]
		Cr = Cmin / Cmax;														//[-]
		Ntu_superheat = UA_superheat / Cmin;									//[-]
		epsilon_superheat = (1 - exp(-Ntu_superheat * (1 - Cr))) / 
			(1 - Cr * exp(-Ntu_superheat * (1 - Cr)));							//[-]

	// Positive Q is heat input to the refrigerant, negative Q is heat 
	//		output from refrigerant. 
	// Heat is input here to the refrigerant since it is evaporating
		Q_superheat = epsilon_superheat * Cmin * (Tin_g-Tsat_r);				//[W]

	// Back calculate the interface glycol temperature
		Tinter_g = Tin_g - Q_superheat / (mdot_g * cp_g);						//[K]

	// Calculate a temporary saturation temperature.
	// This will be driven to zero by the secant solver
		Tsat_r_temp=Tout_r - Q_superheat / (mdot_r * cp_r);						//[K]

	// Calculation of the charge in the superheated region based on average temp
	// This is for one element (either channel or IHX)
		rho_superheat=Props('D', 'T',(Tsat_r + Tout_r)/2,'P', pout_r, PrimaryRef);//[kg/m^3]
		charge_superheat = w_superheat * V_r * rho_superheat;					//[kg]

	//Pressure drop calculations for superheated refrigerant
		v_r=1/rho_superheat;
	//Pressure gradient using Darcy friction factor
		dp_dz_r=-f_r_superheat*v_r*G_r*G_r/(2*Dh_r);  
		DP_r=dp_dz_r*L*w_superheat;

	//Pressure drop calculations for glycol (water)
		v_g=1/Props('D','T',(Tinter_g+Tin_g)/2.0, 'P',pin_g,SecondaryRef);
	//Pressure gradient using Darcy friction factor
		dp_dz_g=-f_g_superheat*v_g*G_g*G_g/(2*Dh_g);  //Pressure gradient
		DP_g=dp_dz_g*L*w_superheat;

	Inputs.Tinter_g_sh_2p=Tinter_g;
	Outputs.DP_r_superheat=DP_r;
	Outputs.DP_g_superheat=DP_g;
	Outputs.Charge_superheat=charge_superheat * ((double)NIHX);
	Outputs.Q_superheat=Q_superheat * ((double)NIHX);
	Outputs.h_r_superheat=h_r_superheat;
	Outputs.h_g_superheat=h_g_superheat;
	Outputs.Re_r_superheat=Re_r_superheat;
	Outputs.Re_g_superheat=Re_g_superheat;

	// Error between temporary solved-for saturation temperature and actual saturation temp
		dT_error= Tsat_r_temp-Tsat_r;											//[K]

	return dT_error;
}
static double TwoPhase(double w_2phase)
{
	double mdot_r,pout_r,Tsat_r,Tout_r,mdot_g,Tin_g,Tinter_g,pin_g,xin_r,OD_g,
		ID_g,OD_r,L,V_r,A_g_2phase,A_r_2phase,h_r_2phase,h_g_2phase,
		f_g_2phase,cp_g,Q_2phase,rho_2phase[30],charge_2phase,h_fg,Tout_g,
		Q_2phase_Shah,xv[30],alpha[30],G_r,UA_2phase,Ntu_2phase,epsilon_2phase,
		sum=0.0,residual,Dh_g,G_g,v_g,dp_dz_g,DP_g,x1,x2,x3,y1,y2,Re_g_2phase,dpdz_dummy,alpha_min,
		DP_accel,DP_frict,v_f,rhog,rhof,S,C,alpha_average,rho_average;
	int doneQ=0,i,iter=1,NIHX;

	// Retrieve values from the structure for code compactness
    mdot_r =	Inputs.mdot_r;
	pout_r =	Inputs.pout_r;
	Tsat_r =	Inputs.Tsat_r;
	Tout_r =	Inputs.Tout_r;
    mdot_g =	Inputs.mdot_g;
    Tin_g =		Inputs.Tin_g;
	//Interface temp between superheated and two-phase regions
	Tinter_g =	Inputs.Tinter_g_sh_2p; 
    pin_g =		Inputs.pin_g;
    xin_r =		Inputs.xin_r;
    OD_g =		Inputs.OD_o;
    ID_g =		Inputs.ID_o;
    OD_r =		Inputs.OD_i;
    L =			Inputs.L;
	NIHX =		Inputs.N;

	// *********************************************************************************
	//									TWO PHASE PART 
	// *********************************************************************************

	V_r = Inputs.V_r;
	A_g_2phase=Inputs.A_g*w_2phase;
	A_r_2phase=Inputs.A_r*w_2phase;
	G_g = Inputs.G_g;
	G_r = Inputs.G_r;
	Dh_g = Inputs.Dh_g;

	// Latent heat at given saturation temp
	h_fg = ( Props('H','T',Tsat_r,'Q',1,PrimaryRef)
		-Props('H','T',Tsat_r,'Q',0,PrimaryRef) )*1000;							//[J/kg] 

	// Guess values for the two-phase section 
	Tout_g=Tinter_g-4;	 // guess of outlet temp of glycol										//[K]
	/* Initially assume that inlet state is saturated liquid) */
	xin_r=0.0;			 // guess of refrigerant inlet quality into IHX							//[-]
	
	// Iterate to match the heat flux for the evaporative HTC correlation to the actual heat flux
	while(doneQ==0)
	{
		if (iter==1){x1=0.0; xin_r=x1;}
		if (iter==2){x2=0.99; xin_r=x2;}
		if (iter>2){xin_r=x2;}

		Q_2phase_Shah=mdot_r*h_fg*(1-xin_r); // updated value for 2phase HT						// [W]

		// This block calculates the average refrigerant heat transfer coefficient by
		// integrating the local heat transfer coefficient between the
		// inlet quality and a quality of 1.0
		h_r_2phase = ShahEvaporation_Average(PrimaryRef,G_r, OD_r, xin_r, 1.000000, Tsat_r, Q_2phase_Shah / A_r_2phase);
	
		// Guess the mean "glycol" temp to be average of interface and (intially guessed) outlet temp
		f_h_1phase_Annulus(Inputs.mdot_IHX_g, OD_g, ID_g, (Tout_g+Tin_g)/2, pin_g, SecondaryRef,			//[kg/s],[m],[m],[K],[kPa]
			"Single", &f_g_2phase, &h_g_2phase, &Re_g_2phase);									//[-],[W/m^2-K]
		cp_g = Props('C', 'T',(Tout_g+Tin_g)/2, 'P', pin_g, SecondaryRef)*1000;					//[J/kg-K]		

		// Counter-flow heat transfer relations with Cr=0 since Cmax is infinite (boiling refrigerant)
		UA_2phase = 1 / (1 / (h_r_2phase * A_r_2phase) + 1 / (h_g_2phase * A_g_2phase));		//[W/K]
		Ntu_2phase = UA_2phase / (mdot_g * cp_g);												//[-]
		epsilon_2phase = 1 - exp(-Ntu_2phase);													//[-]
		Q_2phase = epsilon_2phase * mdot_g * cp_g * ( Tinter_g-Tsat_r);							//[W]		

		Tout_g = Tin_g - Q_2phase / (mdot_g * cp_g);											//[K]

		/* 
		First time through assume that the inlet state is saturated liquid.  If when using this inlet,
		the amount of heat transfered (Q_2phase) is still larger than mdot_r*h_fg, there is a 
		subcooled refrigerant section
		*/
		if (Outputs.Exists_subcool==-1)
		{
			if (iter==1 && fabs(Q_2phase)>mdot_r*h_fg)
			{
				Outputs.Exists_subcool=1;
				return 0.0;
			}
			else
			{
				Outputs.Exists_subcool=0;
			}
		}

		
		if (Outputs.Exists_subcool==1)
		{	
			/*
			If there is a subcooled region, the inlet quality has to be 0, and you are trying
			to drive the heat transfer equal to the latent heat with the external solver
			*/
			xin_r=0.0;
			residual=Q_2phase-mdot_r*h_fg;
			doneQ=1;
		}
		else 
		{
			/*
			Otherwise it is dependent on the evaporation heat transfer coefficient, and 
			once the heat transfer is converged, the solution is reached.

			There is no residual to be driven by an external solver
			*/
			if (fabs(Q_2phase-Q_2phase_Shah)>1)
			{	
				//xin_r=1-Q_2phase/(mdot_r*h_fg);
				residual=0.0;
			}
			else //You are done now jump out of this loop
			{
				doneQ=1;
			}
		}

		if (iter==1){y1=Q_2phase-Q_2phase_Shah;}
		if (iter>1)
		{
			y2=Q_2phase-Q_2phase_Shah;
			x3=x2-y2/(y2-y1)*(x2-x1);
			if (x3<0)
				x3=x2-0.01*y2/(y2-y1)*(x2-x1);
			if (x3<0)
				printf("IHX TwoPhase quality < 0\n");
			y1=y2; x1=x2; x2=x3;
		}
		iter++;

		if (iter>100 && fabs(Q_2phase-Q_2phase_Shah)<10)
			printf("Max iteration count of 100 in TwoPhase() in IHX reached, error of %g W",fabs(Q_2phase-Q_2phase_Shah));
	}

	/*
	After finishing the two-phase part, 
	Calculations for refrigerant charge, with the assumption of homogeneous flow
	*/
	rhog=Props('D', 'T', Tsat_r, 'Q', 1, PrimaryRef);
	rhof=Props('D', 'T', Tsat_r, 'Q', 0, PrimaryRef);
	S=pow(rhof/rhog,0.3333);
	for (i=1;i<30;i++)
	{	
		xv[i] = (i - 1) * (xin_r - 0.0) / 29;	
		alpha[i] = 1 / (1 + S*(1 - xv[i]) / xv[i] * rhog/rhof);
		rho_2phase[i] = alpha[i] * rhog + (1 - alpha[i]) * rhof;
	}
	for(i=1;i<29;i++)
		sum += (rho_2phase[i] + rho_2phase[i + 1]) / 2 / 29;
	charge_2phase = sum * w_2phase * V_r; //For one IHX

	rhog=Props('D', 'T', Tsat_r, 'Q', 1, PrimaryRef);
	rhof=Props('D', 'T', Tsat_r, 'Q', 0, PrimaryRef);
	S=pow(rhof/rhog,0.3333);
	C=S*rhog/rhof;
	x1=xin_r;
	x2=1.0;
	alpha_average=-(C*(log( ((x2-1.0)*C-x2)/((x1-1.0)*C-x1) )+x2-x1)-x2+x1)/(C*C-2*C+1)/(x2-x1);
	rho_average= alpha_average*rhog + (1-alpha_average)*rhof;
	charge_2phase = rho_average * w_2phase * V_r; //For one IHX


	// Find void fraction at inlet quality from Lockhart-Martinelli separated flow relation
		LockhartMartinelli(PrimaryRef, G_r, OD_r, xin_r, Inputs.Tsat_r, &dpdz_dummy, &alpha_min);
	// Accelerational pressure drop component
		v_g=1./Props('D','T',Inputs.Tsat_r,'Q',1.0,PrimaryRef);
		v_f=1./Props('D','T',Inputs.Tsat_r,'Q',0.0,PrimaryRef);
		if (xin_r==0.0)
			DP_accel=G_r*G_r*(v_f-v_g);
		else if (xin_r==1.0)
			DP_accel=0.0;
		else
			DP_accel=G_r*G_r*(v_f-(xin_r*xin_r/alpha_min*v_g+(1-xin_r)*(1-xin_r)*v_f/(1-alpha_min)));
	// Frictional pressure drop component
		DP_frict=LMPressureGradientAvg(PrimaryRef,G_r,OD_r,xin_r,1.0,Inputs.Tsat_r)*L*w_2phase;

	Outputs.DP_r_2phase=-(DP_frict+DP_accel);

	Outputs.Q_2phase = Q_2phase * ((double)NIHX);
	Outputs.Charge_2phase = charge_2phase * ((double)NIHX);

	if (Outputs.Exists_subcool==1)
	{
		Inputs.Tinter_g_sc_2p=Tout_g;
	}
	else
	{
		Outputs.Tout_g = Tout_g;
	}
	
	//Pressure drop calculations for glycol
		v_g=1/Props('D','T',(Tinter_g+Tin_g)/2.0, 'P',pin_g,SecondaryRef);	//[m^3/kg]
	//Pressure gradient using Darcy friction factor
		dp_dz_g=-f_g_2phase*v_g*G_g*G_g/(2*Dh_g);  						//[Pa/m]
		DP_g=dp_dz_g*L*w_2phase;										//[Pa]

	Outputs.DP_g_2phase=DP_g;
	Outputs.h_r_2phase=h_r_2phase;
	Outputs.h_g_2phase=h_g_2phase;
	Outputs.Re_g_2phase=Re_g_2phase;
    return residual;
}

static double Subcool(double w_subcool)
{
	double mdot_r,pout_r,Tsat_r,Tout_r,mdot_g,Tin_g,pin_g,xin_r,OD_g,ID_g,OD_r,L,
		V_r,A_g_subcool,A_r_subcool,f_r_subcool,h_r_subcool,h_g_subcool,
		f_g_subcool,cp_r,cp_g,Cmin,Cmax,Cr,UA_subcool,Ntu_subcool,epsilon_subcool,
		Q_subcool,rho_subcool,charge_subcool,Tout_g_temp,Tout_g,Tin_r,
		Re_r_subcool,Re_g_subcool,v_r,dp_dz_r,dp_dz_g,G_r,Dh_r,
		DP_r,DP_g,v_g,G_g,Dh_g;
	int doneTin=0,NIHX;

	// Retrieve values from the 
	// structure for code compactness
	mdot_r =	Inputs.mdot_r;
	pout_r =	Inputs.pout_r;
	Tsat_r =	Inputs.Tsat_r;
	Tout_r =	Inputs.Tout_r;
	mdot_g =	Inputs.mdot_g;
	Tin_g =		Inputs.Tinter_g_sh_2p;
	pin_g =		Inputs.pin_g;
	xin_r =		Inputs.xin_r;
	OD_g =		Inputs.OD_o;
	ID_g =		Inputs.ID_o;
	OD_r =		Inputs.OD_i;
	L =		Inputs.L;
	NIHX =		Inputs.N;
	

	// **********************************************************************************
	//									SUBCOOLED PART 
	// **********************************************************************************

	// Geometric parameters
	V_r = pi * OD_r*OD_r / 4.0 * L; //'Internal volume of refrigerant side
	A_g_subcool = pi * ID_g * L * w_subcool;
	A_r_subcool = pi * OD_r * L * w_subcool;

	//Guess value
	Tout_g=Tin_g; //Only impacts the mean temps for HTC and f calcs
	Tin_r=Tsat_r; //Only impacts the mean temps for HTC and f calcs

	while (doneTin==0)
	{
		/* 
		Friction factor and HTC in the refrigerant and glycol(Water) portions.
		Average fluid temps are used for the calculation of properties 
		Average temp of refrigerant is average of sat. temp and outlet temp
		Average temp of refrigerant is average of glycol inlet temp and interface temp 
			(initially unknown)
			
		Secondary fluid is in the outer annulus, refrigerant on the inside 
		*/
		f_h_1phase_Tube(Inputs.mdot_IHX_r, OD_r, (Tsat_r + Tin_r) / 2.0, pout_r, PrimaryRef, "Single",		//[kg/s],[m],[K],[kPa]
			&f_r_subcool, &h_r_subcool, &Re_r_subcool);											//[-],[W/m^2-K]
		cp_r = Props('C', 'T', (Tsat_r + Tin_r) / 2.0, 'P', pout_r, PrimaryRef)*1000;			//[J/kg-K]

		f_h_1phase_Annulus(Inputs.mdot_IHX_g, OD_g, ID_g, (Tin_g+Tin_g)/2.0, pin_g, SecondaryRef,			//[kg/s],[m],[K],[kPa]
			"Single", &f_g_subcool, &h_g_subcool, &Re_g_subcool);								//[-],[W/m^2-K]
		cp_g = Props('C', 'T', (Tin_g+Tin_g)/2.0, 'P', pin_g, SecondaryRef)*1000;				//[J/kg-K]
   
		/* 
		Counter-flow in the subcooled region.  
		Using effectiveness-Ntu relationships for counter-current flow with non-zero Cr.
		*/
		UA_subcool = 1 / (1 / (h_r_subcool * A_r_subcool) + 1 / (h_g_subcool * A_g_subcool));//[W/K]
		Cmin = minVal(cp_r * mdot_r, cp_g * mdot_g);										//[W/K]
		Cmax = maxVal(cp_r * mdot_r, cp_g * mdot_g);										//[W/K]
		Cr = Cmin / Cmax;																	//[-]
		Ntu_subcool = UA_subcool / Cmin;													//[-]
		epsilon_subcool = (1 - exp(-Ntu_subcool * (1 - Cr))) / (1 - Cr * exp(-Ntu_subcool * (1 - Cr)));		
																							//[-]
		/* 
		Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
		Heat is input here to the refrigerant since it is warming
		*/
		Q_subcool = epsilon_subcool * Cmin * (Tin_g-Tin_r);									//[W]

		// Back calculate the glycol inlet temperature
		Tout_g_temp = Tin_g - Q_subcool / (mdot_g * cp_g);									//[K]
		Tin_r = Tsat_r - Q_subcool / (mdot_r * cp_r);										//[K]

		rho_subcool=Props('D', 'T', (Tsat_r + Tin_r) / 2, 'P', pout_r, PrimaryRef);				//[kg/m^3]
		charge_subcool = w_subcool * V_r *rho_subcool;										//[kg]

		if (fabs(Tout_g_temp-Tout_g)>0.001)
		{
			doneTin=1;
		}
		else
		{
			Tout_g=Tout_g_temp;
		}
	}

	//Pressure drop calculations for subcooled refrigerant
		v_r=1/rho_subcool;
		G_r=Inputs.G_r;
		Dh_r=Inputs.Dh_r;
	//Pressure gradient using Darcy friction factor
		dp_dz_r=-f_r_subcool*v_r*G_r*G_r/(2*Dh_r);  
		DP_r=dp_dz_r*L*w_subcool;

	//Pressure drop calculations for glycol (water)
		v_g=1/Props('D','T',(Tout_g+Tin_g)/2.0, 'P',pin_g,SecondaryRef);
		G_g=Inputs.G_g;
		Dh_g=Inputs.Dh_g;
	//Pressure gradient using Darcy friction factor
		dp_dz_g=-f_g_subcool*v_g*G_g*G_g/(2*Dh_g);  //Pressure gradient
		DP_g=dp_dz_g*L*w_subcool;


	Outputs.DP_g_subcool=DP_g;
	Outputs.DP_r_subcool=DP_r;
	Outputs.Q_subcool=Q_subcool * ((double)NIHX);
	Outputs.Charge_subcool=charge_subcool * ((double)NIHX);
	Outputs.Tout_g=Tout_g;	
	Outputs.Tin_r=Tin_r;
	Outputs.h_r_subcool=h_r_subcool;
	Outputs.h_g_subcool=h_g_subcool;
	Outputs.Re_r_subcool=Re_r_subcool;
	Outputs.Re_g_subcool=Re_g_subcool;
	return 0.0;
}