/*
 *  PropErrorCodes.h
 *  BellProp
 *
 *  Created by Ian Bell on 5/2/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */


#define OUT_RANGE_T 1
#define OUT_RANGE_P 2
#define TWO_PHASE 3

#define BAD_PROPCODE 11
