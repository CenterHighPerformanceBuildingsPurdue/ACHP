double rho_Lookup_R744(double T, double P);
double h_Lookup_R744(double T, double P);
double u_Lookup_R744(double T, double P);
double s_Lookup_R744(double T, double P);
double cp_Lookup_R744(double T, double P);
double cv_Lookup_R744(double T, double P);






