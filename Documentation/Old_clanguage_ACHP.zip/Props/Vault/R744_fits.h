double R744_rho_fit_supercrit(double T, double P);
double R744_h_fit_supercrit(double T, double P);
double R744_s_fit_supercrit(double T, double P);
double R744_u_fit_supercrit(double T, double P);
double R744_cv_fit_supercrit(double T, double P);

double R744_rho_fit_subcrit(double T, double P);
double R744_h_fit_subcrit(double T, double P);
double R744_s_fit_subcrit(double T, double P);
double R744_u_fit_subcrit(double T, double P);
double R744_cv_fit_subcrit(double T, double P);

