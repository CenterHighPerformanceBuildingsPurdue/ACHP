

#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#include <stdio.h>
#include "RefCycleSolver.h"
#include "PythonEntry.h"
#include "Props/CoolProp.h"

int main()
{
	// Make empty structures for compatibility with Python Call
	struct CycleInputVals Inputs;
	struct CycleOutputVals Outputs;
	
	Props('H','T',360,'P',4000,"R410A");
	
	//SecondarySolver_ChargeImposed(1,&Inputs,&Outputs);
	
	//strcpy(Inputs.ImposedVariable,"Subcooling");
	DXSolver_SubcoolImposed(1,&Inputs,&Outputs);
	
	//DXSolver_ChargeImposed(1,&Inputs,&Outputs);

	#if defined(_MSC_VER)
	_CrtDumpMemoryLeaks();
	#endif

	//getchar();
	return EXIT_SUCCESS;
}

