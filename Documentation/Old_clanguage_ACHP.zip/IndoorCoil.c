
#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>

#include "string.h"
#include <stdio.h>
#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"
#include "IndoorCoil.h"
#include "Solvers.h"
#include "RefCycleSolver.h"

static char * SecondaryRef;
static struct IndoorCoilInputVals Inputs;
static struct IndoorCoilOutputVals Outputs;
static struct FinHTCDPInputsVals FinInputs;

// Private function prototypes

static double minVal(double x1, double x2)
{
	if (x1<x2)
		return x1;
	else
		return x2;
}

static double maxVal(double x1, double x2)
{
	if (x1>x2)
		return x1;
	else
		return x2;
}


int IndoorCoil_Calculate(char *SecondaryRef_, struct FinHTCDPInputsVals *FinInputs_, struct IndoorCoilInputVals *Inputs_, struct IndoorCoilOutputVals *Outputs_)
{
	double h_a,cp_a,A_a,eta_a,mdot_a,f_a,dP_a,mdot_g,ID,Tin_g,pin_g,f_g,h_g,cp_g,
		Ncircuits,Lcircuit,A_g,Tdp, omega_ha, hin_a, RH, v_ha,Tin_a,pin_a,RHin_a,UA_i,Ntu_i,
		Ntu_o,Ntu_dry,C_star,Tout_s,Tout_a_dry,epsilon_dry,Q_dry,v_dummy,omega_dummy,Tdp_dummy,
		RH_dummy,h_s_w_i,c_s,m_star,Ntu_wet,epsilon_wet,hout_a,Q_wet,Tin_s,Tout_g,OD,Tout_g_wet,
		Tout_g_dry,T_w_x,change,Tout_g_temp,K,f_dry,h_s_s_e,Q,T_s_e,Tout_a,Dh_g,dp_dz_g,v_g,
		G_g,DP_g,changeToutg=999.0,Tout_g_guess,h_s_w_o,Re_g,T_a_x,h_a_x;
	int iter=1,finType,WAVY_LOUVERED_FINS=2,WAVY_FINS=1;
	void (*finFunc)(struct FinHTCDPInputsVals*);

	//Copy values from passed variables to temporary global variables
		Inputs=*Inputs_;
		FinInputs=*FinInputs_;
		Outputs=*Outputs_;
		SecondaryRef=SecondaryRef_;

	//Retrieve values from structs
		pin_g=Inputs.pin_g;
		Tin_g=Inputs.Tin_g;
		mdot_g=Inputs.mdot_g;
		ID=Inputs.ID;
		OD=Inputs.OD;
		Ncircuits=Inputs.Ncircuits;
		Lcircuit=Inputs.Lcircuit;
		Tin_a=Inputs.Tin_a;
		pin_a=Inputs.pin_a;
		RHin_a=Inputs.RHin_a;

	finType=WAVY_LOUVERED_FINS;

	if (finType==WAVY_FINS)
		finFunc=WavyFins;
	else if (finType==WAVY_LOUVERED_FINS)
		finFunc=WavyLouveredFins;

	// Evaluate the air-side heat transfer and pressure drop
		finFunc(&FinInputs);

	// Retrieve output vals
		h_a =		FinInputs.Fins.h_a;
		cp_a =		FinInputs.Fins.cp_a;
		A_a =		FinInputs.Fins.A_a;
		eta_a =		FinInputs.Fins.eta_a;
		mdot_a =	FinInputs.Fins.mdot_a;
		f_a =		FinInputs.Fins.f_a;
		dP_a =		FinInputs.Fins.dP_a;

	// Check that inlet temp is above freezing point
		if (Tin_g < Props('F','T',283,'P',0.0,SecondaryRef))
		{
			runFail=1;
			strcpy(runFailString,"Cooling coil inlet temperature below sec. fluid freezing temperature");
			return FUNC_FAILED;
		}


	//Evaluate the glycol-side heat transfer for dry conditions
		f_h_1phase_Tube(mdot_g/((double)Ncircuits), ID, Tin_g, pin_g, SecondaryRef,				//[kg/s],[m],[K],[kPa]
			"Single", &f_g, &h_g, &Re_g);															//[-],[W/m^2-K]
		cp_g = Props('C', 'T', Tin_g, 'P', pin_g, SecondaryRef)*1000;							//[J/kg-K]

	// Glycol-side area
		A_g=Ncircuits*Lcircuit*pi*OD;														//[m^2]

	//Calculate the dewpoint (amongst others)
		HumAir(Tin_a, pin_a, GIVEN_RH, RHin_a, &Tdp, &omega_ha, &hin_a, &RH, &v_ha);
		hin_a=hin_a*1000.0;																	//[J/kg]

	// Internal UA between water stream and outside surface (neglecting tube conduction)
		UA_i=h_g*A_g;																		//[W/K]
	// Internal Ntu
		Ntu_i=UA_i/(mdot_g*cp_g);															//[-]
	// External Ntu (multiplied by eta_a since surface is finned and has lower effectiveness)
		Ntu_o=eta_a*h_a*A_a/(mdot_a*cp_a);														//[-]

	// Capacitance ratio
		C_star=mdot_a*cp_a/(mdot_g*cp_g);													//[-]

	// Overall Ntu 
		Ntu_dry=Ntu_o/(1+C_star*(Ntu_o/Ntu_i));										//[-]

	// Counterflow effectiveness
		epsilon_dry = (1 - exp(-Ntu_dry * (1 - C_star))) / 
		(1 - C_star * exp(-Ntu_dry * (1 - C_star)));										//[-]

	// Dry-analysis air outlet temp
		Tout_a_dry=Tin_a-epsilon_dry*(Tin_a-Tin_g);											//[K]

	// Dry-analysis glycol outlet temp
		Tout_g=Tin_g-C_star*(Tin_a-Tout_a_dry);												//[K]

	// Dry-analysis air outlet enthalpy from energy balance
		hout_a=hin_a-mdot_g*cp_g*(Tin_g-Tout_g)/mdot_a;

	// Dry-analysis surface outlet temp
		Tout_s=Tin_g+C_star*(Ntu_dry/Ntu_i)*(Tout_a_dry-Tin_g);								//[K]

	// Dry-analysis surface outlet temp
		Q_dry=epsilon_dry*mdot_a*cp_a*(Tin_a-Tin_g);										//[W]

	// Dry-analysis outlet glycol temp
		Tout_g_dry=Tout_g;

	// Dry fraction
		f_dry=1.0;


	if (Tout_s<Tdp)
	{
		/* There is some wetting, either the coil is fully wetted or partially wetted */

		// Loop to get the correct c_s 
		// Start with the inlet temp as the outlet temp
			Tout_g=Tin_g;
			Tout_g_guess=Tout_g;

		while (iter==1 || fabs(changeToutg)>0.001)
		{

		// Saturated air enthalpy at the inlet water temperature
		// (Bounding outlet state of air stream)
		// Load other outputs into dummy values
			HumAir(Tin_g, pin_a, GIVEN_RH, 1.0, &Tdp_dummy, &omega_dummy, &h_s_w_i, &RH_dummy, &v_dummy);
			h_s_w_i*=1000.0;																		//[J/kg]

		// Saturation specific heat at mean water temp
			c_s=cair_sat((Tin_g+Tout_g)/2.0)*1000;												//[J/kg-K]

		// Ratio of specific heats
			FinInputs.Air.cs_cp=c_s/cp_a;

		// Find new, effective fin efficiency
			finFunc(&FinInputs);

		// Effective humid air mass flow ratio
			m_star=mdot_a/(mdot_g*(cp_g/c_s));													//[-]

		// Wet-analysis overall Ntu
			Ntu_wet=Ntu_o/(1+m_star*(Ntu_o/Ntu_i));												//[-]

		// Counterflow effectiveness for wet analysis
			epsilon_wet = (1 - exp(-Ntu_wet * (1 - m_star))) / 
				(1 - m_star * exp(-Ntu_wet * (1 - m_star)));										//[-]

		// Air outlet enthalpy
			hout_a=hin_a-epsilon_wet*(hin_a-h_s_w_i);												//[J/kg]

		// Wet-analysis heat transfer rate
			Q_wet=epsilon_wet*mdot_a*(hin_a-h_s_w_i);												//[W]

		// Water outlet temp
			Tout_g = Tin_g+mdot_a/(mdot_g*cp_g)*(hin_a-hout_a);									//[K]

		// Water outlet saturated surface enthalpy (and others)
			HumAir(Tout_g, pin_a, GIVEN_RH, 1.0, &Tdp_dummy, &omega_dummy, &h_s_w_o, &RH_dummy, &v_dummy);
			h_s_w_o*=1000.0;																	//[J/kg]

		// Wet-analysis surface inlet temp
			Tin_s = Tout_g+mdot_a/(mdot_g*cp_g)*(Ntu_wet/Ntu_i)*(hin_a-h_s_w_o);					//[K]

		// Wet-analysis saturation enthalpy
			h_s_s_e=hin_a+(hout_a-hin_a)/(1-exp(-Ntu_o));										//[J/kg]

		// Surface effective temperature
			T_s_e=T_hss(h_s_s_e/1000.0,pin_a,Tin_g);											//[K]

		// Air outlet temp based on effective temp
			Tout_a=T_s_e + (Tin_a-T_s_e)*exp(-Ntu_o);											//[K]

		// Update outlet temp guess
			changeToutg=Tout_g-Tout_g_guess;
			Tout_g_guess=Tout_g;

		//Update loop counter
			iter++;
		}

		// Fully wetted 
			Tout_g_wet=Tout_g;																	//[K]

		// Dry fraction
			f_dry=0.0;

		if (Tin_s>Tdp)
		{
			// Initial guess is the larger value of the outlet temps calculated 
			// by fully wet and fully dry analysis
			if (Tout_g_wet>Tout_g_dry)
				Tout_g=Tout_g_wet;
			else
				Tout_g=Tout_g_dry;

			change=999.0;
			/* Now do an iterative solver to find the fraction of the coil that is wetted */
			while (change>1e-3)
			{
				K=Ntu_dry*(1.0-C_star);
				f_dry=-1.0/K*log( ((Tdp-Tout_g)+C_star*(Tin_a-Tdp)) / ((1.0-K/Ntu_o)*(Tin_a-Tout_g)) );
				if (f_dry<0)
				{
					f_dry=0.0;
				}
				// Wet and dry effective effectivenesses
					epsilon_wet = (1 - exp(-(1-f_dry)*Ntu_wet * (1 - m_star))) / 
						(1 - m_star * exp(-(1-f_dry)*Ntu_wet * (1 - m_star)));
					epsilon_dry = (1 - exp(-f_dry*Ntu_dry * (1 - C_star))) / 
						(1 - C_star * exp(-f_dry*Ntu_dry * (1 - C_star)));
				// Temperature of water where condensation begins
					T_w_x=(Tin_g+C_star*epsilon_wet*(hin_a-h_s_w_i)/cp_a-C_star*epsilon_wet*epsilon_dry*Tin_a)/(1-C_star*epsilon_wet*epsilon_dry);
				// New water temperature (stored temporarily to be able to build change
					Tout_g_temp=C_star*epsilon_dry*Tin_a+(1-C_star*epsilon_dry)*T_w_x;
					change=fabs(Tout_g_temp-Tout_g);
					Tout_g=Tout_g_temp;
			}
			// Temperature of air where condensation begins
				T_a_x=Tin_a-epsilon_dry*(Tin_a-T_w_x);											//[K]

			// Enthalpy of air where condensation begins
				h_a_x=hin_a-epsilon_dry*cp_a*(Tin_a-T_w_x);										//[J/kg]

			// Air outlet enthalpy from energy balance
				hout_a=hin_a-mdot_g*cp_g*(Tout_g-Tin_g)/mdot_a;									//[J/kg]

			// Wet-analysis saturation enthalpy
				h_s_s_e=h_a_x+(hout_a-h_a_x)/(1-exp(-(1-f_dry)*Ntu_o));							//[J/kg]

			// Surface effective temperature
				T_s_e=T_hss(h_s_s_e/1000.0,pin_a,Tin_g);										//[K]

			// Air outlet temp based on effective surface temp
				Tout_a=T_s_e + (T_a_x-T_s_e)*exp(-(1-f_dry)*Ntu_o);								//[K]
	
			// Heat transferred
				Q=mdot_g*cp_g*(Tout_g-Tin_g);													//[W]

		}
		else
		{
			Q=Q_wet;
		}
	
	}
	else
	{
		Tout_a=Tout_a_dry;
		Q=Q_dry;
	}


	//Pressure drop calculations for glycol (water)
	Dh_g=ID;														//[m]
	A_g=pi*Dh_g*Dh_g/4.0*((double)Ncircuits);						//[m^2]
	G_g=mdot_g/A_g;													//[kg/m^2-s]
	v_g=1/Props('D','T',Tin_g, 'P',pin_g,SecondaryRef);					//[m^3/kg]
	//Pressure gradient using Darcy friction factor
	dp_dz_g=-f_g*v_g*G_g*G_g/(2*Dh_g);  							//[Pa/m]
	DP_g=dp_dz_g*Lcircuit;											//[Pa]

	Outputs.f_dry=f_dry;
	Outputs.DP_g=DP_g;
	Outputs.Q=Q;
	Outputs.Tout_g=Tout_g;
	Outputs.Tout_a=Tout_a;
	Outputs.hout_a=hout_a;
	Outputs.hin_a=hin_a;
	Outputs.SHR=cp_a*(Tout_a-Tin_a)/(hout_a-hin_a);
	Outputs.h=h_g;
	Outputs.Re=Re_g;

	//Copy values back to passed variables
	*Inputs_=Inputs;
	*FinInputs_=FinInputs;
	*Outputs_=Outputs;
	return 0;
}

