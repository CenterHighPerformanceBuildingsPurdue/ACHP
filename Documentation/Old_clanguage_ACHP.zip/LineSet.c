
#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>
#include "string.h"
#include <stdio.h>

#include "Props/CoolProp.h"
#include "RefCycleSolver.h"
#include "Correlations.h"
#include "LineSet.h"

int LineSet_Calculate(char *Ref, struct LineSetInputVals *Inputs, struct LineSetOutputVals *Outputs)
{
	double ID,OD,L,k_insul,t_insul,k_tube,R_tube,R_insul,mdot,Tin,pin,f,h,UA,h_air,G,v,
		dp_dz,UA_i,UA_o,T_air,Tout,cp,Re;

	// Retrieve values from structures
		L=Inputs->L;
		ID=Inputs->ID;
		OD=Inputs->OD;
		pin=Inputs->pin;
		mdot=Inputs->mdot;
		Tin=Inputs->Tin;

		k_tube=Inputs->k_tube;
		k_insul=Inputs->k_insul;
		t_insul=Inputs->t_insul;
		h_air=Inputs->h_air;
		T_air=Inputs->T_air;

	f_h_1phase_Tube(mdot, ID, Tin, pin, Ref, 		//[kg/s],[m],[K],[kPa]
		"Single",&f, &h, &Re);						//[-],[W/m^2-K],[-]
	cp=Props('C','T',Tin,'P',pin,Ref)*1000;			//[J/kg-K]

	R_tube=log(OD/ID)/(2*pi*L*k_tube);
	R_insul=log((OD+2.0*t_insul)/OD)/(2*pi*L*k_insul);
	UA_i=pi*ID*L*h;
	UA_o=pi*(OD+2*t_insul)*L*h_air;

	UA=1/(1/UA_i+R_tube+R_insul+1/UA_o);
	
	////Secant-solve for the outlet temp
	//while ((iter<=3 || fabs(r)>eps) && iter<100)
	//{
	//	if (iter==1){x1=Tin+0.0001; Tout=x1;}
	//	if (iter==2){x2=Tin+0.1; Tout=x2;}
	//	if (iter>2) {Tout=x2;}
	//		if (Tout>T_air && Tin<T_air)
	//		{
	//			runFail=1;
	//			strcpy(runFailString,"Line set temperature brackets the ambient temperature, LMTD is not defined");
	//			return FUNC_FAILED;
	//		}
	//		dT_o=T_air-Tout;
	//		dT_i=T_air-Tin;
	//		LMTD=(dT_o-dT_i)/log(dT_o/dT_i);
	//		r=UA*LMTD-mdot*cp*(Tout-Tin);
	//		
	//	if (iter==1){y1=r;}
	//	if (iter>1)
	//	{
	//		y2=r;
	//		x3=x2-y2/(y2-y1)*(x2-x1);
	//		y1=y2; x1=x2; x2=x3;
	//	}
	//	iter=iter+1;
	//}
	Tout=T_air-exp(-UA/(mdot*cp))*(T_air-Tin);


	Outputs->Q=mdot*cp*(Tout-Tin);
	Outputs->Tout=Tout;

	G=mdot/(pi*ID*ID/4.0);
	v=1/Props('D','T',(Tin+Tout)/2.0, 'P',pin,Ref);
	//Pressure gradient using Darcy friction factor
	dp_dz=-f*v*G*G/(2*ID);  //Pressure gradient
	Outputs->DP=dp_dz*L;
	Outputs->Re=Re;
	Outputs->h=h;
	Outputs->hout=Props('H','T',Tout,'P',pin,Ref)*1000; //[J/kg]
	Outputs->Charge=pi*ID*ID/4.0*L/v;

	return 0;

}