
#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>

#include "string.h"
#include <stdio.h>
#include "Props/CoolProp.h"

#include "Correlations.h"
#include "Evaporator.h"
#include "Props/HumAir.h"
#include "Solvers.h"
#include "RefCycleSolver.h"

struct DWSVals
{
	double Tin_a, pin_a, mdot_a, h_a, cp_a, A_a, eta_a, RHin_a;
	double Tin_r, pin_r, mdot_r, h_r, cp_r, A_r, Re_r,f_dry;
	int IsTwoPhase;

	double Q,SHR,hout_a,Tdbout_a,RHout_a,hin_a;
	double omega_out;
};


static char * Ref;
static struct EvaporatorInputVals Inputs;
static struct EvaporatorOutputVals Outputs;
static struct FinHTCDPInputsVals FinInputs;
static struct DWSVals DWS2phase;
static double w_subcool;
void (*finFunc)(struct FinHTCDPInputsVals*);

static double minVal(double x1, double x2)
{
	if (x1<x2)
		return x1;
	else
		return x2;
}

static double maxVal(double x1, double x2)
{
	if (x1>x2)
		return x1;
	else
		return x2;
}

static void DryWetSegment(struct DWSVals *DWS)
{
	// Generic solver function for dry-wet mixed surface conditions for a given element.
	// Can handle superheated, subcooled and two-phase regions.
	// Does not handle the pressure drops, only HT required to get the dry/wet interface

	double Tin_a,h_a,eta_a,cp_a,A_a,mdot_a,Tin_r,h_r,cp_r,A_r,mdot_r, Tdp,hin_a,
		RH,v_ha,UA_i,Ntu_i,Ntu_o,C_star,Ntu_dry,epsilon_dry,Tout_a_dry,Tout_r,hout_a,Tout_s,
		Q_dry,Tout_r_dry,f_dry,pin_a,pin_r,RHin_a, Tout_r_guess,Tdp_dummy,omega_dummy, omega_in,
		h_s_w_i, RH_dummy, v_dummy, c_s, epsilon_wet,Ntu_wet,T_w_x,m_star,K,changeToutr,Q_wet,
		h_s_w_o,h_s_s_e,Tin_s,T_s_e,Tout_a,Q,Tout_r_wet,Tout_r_temp,change,UA,UA_o,UA_wet,
		h_dummy,h_ac,T_ac,T_so_a,T_so_b,Cmax,Cmin,h_s_s_o,expk,C=1.0,x1,x2,x3,y1,y2,eps,
		Tout_r_start;
	//HOWARDCHANGE
	double Ntu_owet; //Ntu_o for the fully wet analysis
	double h_ins; //Effective surface enthlapy at the inlet
	int iter=1,isFullyWet=0;
	//HOWARDCHANGE
	double mdot_min; //Similar to Cmin but in the context of mass flow
	double UA_star; //Entahlpy conductance


	double T_a_x, h_a_x;

	//Retrieve values from structures defined above
		Tin_a=DWS->Tin_a;
		h_a=DWS->h_a;
		cp_a=DWS->cp_a;
		eta_a=DWS->eta_a;
		A_a=DWS->A_a;
		pin_a=DWS->pin_a;
		RHin_a=DWS->RHin_a;
		mdot_a=DWS->mdot_a;

		Tin_r=DWS->Tin_r;
		pin_r=DWS->pin_r;
		h_r=DWS->h_r;
		cp_r=DWS->cp_r;
		A_r=DWS->A_r;
		mdot_r=DWS->mdot_r;

	//Calculate the dewpoint (amongst others)
		HumAir(Tin_a, pin_a, GIVEN_RH, RHin_a, &Tdp, &omega_in, &hin_a, &RH, &v_ha);
		hin_a *= 1000.0;		//[J/kg]

	// Internal UA between water stream and outside surface (neglecting tube conduction)
		UA_i=h_r*A_r;																		//[W/K]
	// External UA between wall and free stream
		UA_o=eta_a*h_a*A_a;																	//[W/K]
	// Internal Ntu
		Ntu_i=UA_i/(mdot_r*cp_r);															//[-]
	// External Ntu (multiplied by eta_a since surface is finned and has lower effectiveness)
		Ntu_o=eta_a*h_a*A_a/(mdot_a*cp_a);													//[-]

	if (DWS->IsTwoPhase==1)
	{

		UA=1/(1/(h_a*A_a*eta_a)+1/(h_r*A_r));
		Ntu_dry=UA/(mdot_a*cp_a);
		epsilon_dry=1-exp(-Ntu_dry);
		Q_dry=C*epsilon_dry*mdot_a*cp_a*(Tin_a-Tin_r);
		Tout_a=Tin_a-Q_dry/(mdot_a*cp_a);

		T_so_a=(UA_o*Tin_a+UA_i*Tin_r)/(UA_o+UA_i);
		T_so_b=(UA_o*Tout_a+UA_i*Tin_r)/(UA_o+UA_i);

		if (T_so_b>Tdp)
		{
			//printf("All Dry: %g,%g\n",Ntu_dry,RHin_a);
			//All dry
			f_dry=1.0;
			Q=Q_dry;
			hout_a=hin_a-Q/mdot_a;
		// Air outlet humidity ratio
			DWS->omega_out = omega_in;								//[kg/kg]
		}
		else
		{
			if (T_so_a<Tdp)
			{
				//printf("All Wet: %g,%g\n",Ntu_dry,RHin_a);
				// All wet
				f_dry=0.0;
				Q_dry=0.0;
				T_ac=Tin_a;
				h_ac=hin_a;
			}
			else
			{
				// Partially wet and dry

				// Air temperature at the interface between wet and dry surface
				// Based on equating heat fluxes at the wall which is at dew point UA_i*(Tw-Ti)=UA_o*(To-Tw)
					T_ac = Tdp + UA_i/UA_o*(Tdp - Tin_r);
				// Dry effectiveness (minimum capacitance on the air side by definition)
					epsilon_dry=(Tin_a-T_ac)/(Tin_a-Tin_r);
				// Dry fraction found by solving epsilon=1-exp(-f_dry*Ntu) for known epsilon from above equation
					f_dry=-1.0/Ntu_dry*log(1.0-epsilon_dry);
				// Air humidity at the interface between wet and dry surfaces (same humidity ratio as inlet)
					HumAir(T_ac, pin_a, GIVEN_HUMRAT, omega_in, &Tdp_dummy, &omega_dummy, &h_ac, &RH_dummy, &v_dummy);
					h_ac*=1000.0;													//[J/kg]
				// Dry heat transfer
					Q_dry=mdot_a*cp_a*(Tin_a-T_ac);
			}

		// Saturation specific heat at mean water temp
			c_s=cair_sat(Tin_r)*1000;												//[J/kg-K]
		// Ratio of specific heats
			FinInputs.Air.cs_cp=c_s/cp_a;
		// Find new, effective fin efficiency since cs/cp is changed from wetting
			finFunc(&FinInputs);
			eta_a=FinInputs.Fins.eta_a;
			UA_o=eta_a*h_a*A_a;
			//HOWARDCHANGE
			Ntu_o=eta_a*h_a*A_a/(mdot_a*cp_a);	
		// Wet analysis overall Ntu for two-phase refrigerant
		// Minimum capacitance rate is by definition on the air side
		// Ntu_wet is the NTU if the entire two-phase region were to be wetted
			UA_wet=1/(c_s/UA_i+cp_a/UA_o);
			Ntu_wet=UA_wet/(mdot_a);
		// Wet effectiveness
			epsilon_wet=1-exp(-(1-f_dry)*Ntu_wet);
		// Air saturated at refrigerant saturation temp
			HumAir(Tin_r, pin_a, GIVEN_RH, 1.0, &Tdp_dummy, &omega_dummy, &h_s_s_o, &RH_dummy, &v_dummy);
			h_s_s_o*=1000.0;													//[J/kg]
		
		// Wet heat transfer
			Q_wet=C*epsilon_wet*mdot_a*(h_ac-h_s_s_o);
		// Total heat transfer
			Q=Q_wet+Q_dry;
		// Air exit enthalpy
			hout_a=h_ac-Q_wet/mdot_a;
		// Saturated air temp at effective surface temp
			h_s_s_e=h_ac-(h_ac-hout_a)/(1-exp(-(1-f_dry)*Ntu_o));
		// Effective surface temperature
			T_s_e = T_hss(h_s_s_e/1000.0,pin_a,Tin_r);
		// Outlet dry-bulb temp
			Tout_a = T_s_e+(T_ac-T_s_e)*exp(-(1-f_dry)*Ntu_o);
		}
	}
	else //(Single-Phase)
	{
		//Overall UA
			UA = 1 / (1 / (UA_i) + 1 / (UA_o));
		// Min and max capacitance rates
			Cmin = minVal(cp_r * mdot_r, cp_a * mdot_a);
			Cmax = maxVal(cp_r * mdot_r, cp_a * mdot_a);
		// Capacitance rate ratio
			C_star = Cmin / Cmax;
		// Ntu overall
			Ntu_dry = UA / Cmin;

		// Counterflow effectiveness
			epsilon_dry = (1 - exp(-Ntu_dry * (1 - C_star))) / 
			(1 - C_star * exp(-Ntu_dry * (1 - C_star)));							//[-]
			/*epsilon_dry = 1-exp(1/C_star*pow(Ntu_dry,0.22)*( exp(-C_star*pow(Ntu_dry,0.78)) -1));
			epsilon_dry = 1 - exp(-1 / C_star * (1 - exp(-C_star * Ntu_dry)));*/

		// Heat transfer
			Q_dry = epsilon_dry*Cmin*(Tin_a-Tin_r);									//[W]

		// Dry-analysis air outlet temp
			Tout_a_dry=Tin_a-Q_dry/(mdot_a*cp_a);									//[K]

		// Dry-analysis glycol outlet temp
			Tout_r=Tin_r+mdot_a*cp_a/(mdot_r*cp_r)*(Tin_a-Tout_a_dry);				//[K]

		// Dry-analysis air outlet enthalpy from energy balance
			hout_a=hin_a-mdot_r*cp_r/mdot_a*(Tout_r-Tin_r);							//[J/kg]

		// Dry-analysis surface outlet temp
			Tout_s=(UA_o*Tout_a_dry+UA_i*Tin_r)/(UA_o+UA_i);						//[K]

		// Dry-analysis surface inlet temp
			Tin_s=(UA_o*Tin_a+UA_i*Tout_r)/(UA_o+UA_i);								//[K]

		// Dry-analysis outlet refrigerant temp
			Tout_r_dry=Tout_r;

		// Dry fraction
			f_dry=1.0;

		// Air outlet humidity ratio
			DWS->omega_out = omega_in;

		if (Tin_s<Tdp)
			isFullyWet=1;
		else
			isFullyWet=0;


		if (Tout_s<Tdp || isFullyWet==1)
		{
			/* There is some wetting, either the coil is fully wetted or partially wetted */

			// Loop to get the correct c_s 
			// Start with the inlet temp as the outlet temp
				//~ Tout_r=Tin_r;
				//~ Tout_r_guess=Tout_r;
			x1=Tin_r+1;
			x2=Tin_a-1;
			eps=1e-8;
			iter=1;
			while ((iter<=3 || change>eps) && iter<100)
			{
				if (iter==1){Tout_r=x1;}
				if (iter==2){Tout_r=x2;}
				if (iter>2) {Tout_r=x2;}
			//~ while (iter==1 || fabs(changeToutr)>0.001)
			//~ {
				Tout_r_start=Tout_r;
				// Saturated air enthalpy at the inlet water temperature
				// (Bounding outlet state of air stream)
				// Load other outputs into dummy values
					HumAir(Tin_r, pin_a, GIVEN_RH, 1.0, &Tdp_dummy, &omega_in, &h_s_w_i, &RH_dummy, &v_dummy);
					h_s_w_i*=1000.0;														//[J/kg]
				// Saturation specific heat at mean water temp
					c_s=cair_sat((Tin_r+Tout_r)/2.0)*1000;									//[J/kg-K]
				// Ratio of specific heats
					FinInputs.Air.cs_cp=c_s/cp_a;
				// Find new, effective fin efficiency since cs/cp is changed from wetting
					finFunc(&FinInputs);
				// Effective humid air mass flow ratio
					m_star=mdot_a/(mdot_r*(cp_r/c_s));										//[-]
				//HOWARDCHANGE
				//compute the new Ntu_owet
					Ntu_owet = eta_a*h_a*A_a/(mdot_a*cp_a);													//[-]
				// HOWARDCHANGE
					m_star = minVal(cp_r * mdot_r/c_s, mdot_a)/maxVal(cp_r * mdot_r/c_s, mdot_a);				//[-]
					mdot_min = minVal(cp_r * mdot_r/c_s, mdot_a);									//[kg/s]
				
				// Wet-analysis overall Ntu
					Ntu_wet=Ntu_o/(1+m_star*(Ntu_owet/Ntu_i));									//[-]
				// HOWARDCHANGE
					if(cp_r * mdot_r> c_s * mdot_a)
						Ntu_wet=Ntu_o/(1+m_star*(Ntu_owet/Ntu_i));
					else
						Ntu_wet=Ntu_i/(1+m_star*(Ntu_i/Ntu_owet));
					
				// Counterflow effectiveness for wet analysis
					epsilon_wet = (1 - exp(-Ntu_wet * (1 - m_star))) / 
						(1 - m_star * exp(-Ntu_wet * (1 - m_star)));						//[-]
				//HOWARDCHANGE
				// Wet-analysis heat transfer rate
					Q_wet = epsilon_wet*mdot_min*(hin_a-h_s_w_i);							//[W]
				// Air outlet enthalpy
					hout_a=hin_a-Q_wet/mdot_a;								//[J/kg]
				// Water outlet temp
					Tout_r = Tin_r+mdot_a/(mdot_r*cp_r)*(hin_a-hout_a);						//[K]
				// Water outlet saturated surface enthalpy (and others)
					HumAir(Tout_r, pin_a, GIVEN_RH, 1.0, &Tdp_dummy, &omega_dummy, &h_s_w_o, &RH_dummy, &v_dummy);
					h_s_w_o*=1000.0;														//[J/kg]
				// Wet-analysis surface inlet effective enthalpy
					//Tin_s = Tout_r+mdot_a/(mdot_r*cp_r)*(Ntu_wet/Ntu_i)*(hin_a-h_s_w_o);	//[K]
					//HOWARDCHANGE
					//Local UA* and c_s
					UA_star = 1/(cp_a/eta_a/h_a/A_a+cair_sat((Tin_a+Tout_r)/2.0)*1000/h_r/A_r);	//[kg/s]
					Tin_s = Tout_r + UA_star/h_r/A_r*(hin_a-h_s_w_o);							//[K]
				//HOWARDCHANGE
				// Wet-analysis saturation enthalpy
					h_s_s_e=hin_a+(hout_a-hin_a)/(1-exp(-Ntu_owet));							//[J/kg]
				// Surface effective temperature
					T_s_e=T_hss(h_s_s_e/1000.0,pin_a,Tin_r);								//[K]
				// Air outlet temp based on effective temp
					Tout_a=T_s_e + (Tin_a-T_s_e)*exp(-Ntu_o);								//[K]
				// Error between guess and recalculated value
					changeToutr=Tout_r-Tout_r_start;
			//~ Tout_r_guess=Tout_r;
					
				
					
				//HOWARDCHANGE
				if(iter>500){
					printf("Superheated region wet analysis T_outr convergence failed \n");
					DWS->Q=Q_dry;
					return;
				}
				if (iter==1)
				{
					y1=changeToutr;
				}
				if (iter>1)
				{
					y2=changeToutr;
					x3=x2-y2/(y2-y1)*(x2-x1);
					change=fabs(y2/(y2-y1)*(x2-x1));
					y1=y2; x1=x2; x2=x3;
				}
				printf("Fullwet iter %d Toutr %0.5f dT %g\n",iter,Tout_r,changeToutr);
				//Update loop counter
				iter++;
			}
			// Fully wetted outlet temperature
				Tout_r_wet=Tout_r;														//[K]
			// Dry fraction
				f_dry=0.0;
			
			if (Tin_s>Tdp && isFullyWet==0)
			{
				// Initial guess is the larger value of the outlet temps calculated 
				// by fully wet and fully dry analysis
				//~ if (Tout_r_wet>Tout_r_dry)
					//~ Tout_r=Tout_r_wet;
				//~ else
					//~ Tout_r=Tout_r_dry;

				change=999.0;
				iter = 1;
				/* Now do an iterative solver to find the fraction of the coil that is wetted */
				/* Discontinuity is found at T->Tin_a and the convergence is changed on f_dry */
				x1=0.0001;
				x2=0.9999;
				eps=1e-8;
				while ((iter<=3 || change>eps) && iter<100)
				{
					if (iter==1){f_dry=x1;}
					if (iter==2){f_dry=x2;}
					if (iter>2){f_dry=x2;}
					
					//HOWARDCHANGE
					K=Ntu_dry*(1.0-C_star);
					if((cp_a * mdot_a)<(cp_r * mdot_r)){
						expk = exp(-K*f_dry);
						Tout_r_guess = (Tdp + C_star*(Tin_a - Tdp)-expk*(1-K/Ntu_o)*Tin_a)/(1-expk*(1-K/Ntu_o));
					}
					else{
						expk = exp(-K*f_dry);
						Tout_r_guess = (expk*(Tin_a+(C_star-1)*Tdp)-C_star*(1+K/Ntu_o)*Tin_a)/(expk*C_star-C_star*(1+K/Ntu_o));
					}
					// Wet and dry effective effectivenesses
						epsilon_wet = (1 - exp(-(1-f_dry)*Ntu_wet * (1 - m_star))) / 
							(1 - m_star * exp(-(1-f_dry)*Ntu_wet * (1 - m_star)));
						epsilon_dry = (1 - exp(-f_dry*Ntu_dry * (1 - C_star))) / 
							(1 - C_star * exp(-f_dry*Ntu_dry * (1 - C_star)));
					// Temperature of "water" where condensation begins
						T_w_x=(Tin_r+(mdot_min)/(cp_r * mdot_r)*epsilon_wet*(hin_a-h_s_w_i-epsilon_dry*Cmin/mdot_a*Tin_a))/(1-(Cmin*mdot_min)/(cp_r * mdot_r * mdot_a)*epsilon_wet*epsilon_dry);
					//Temperature of air where condensation begins
							T_a_x = Tin_a - epsilon_dry*Cmin*(Tin_a - T_w_x)/mdot_a/cp_a;
					//Enthalpy of air where condensation begins
						h_a_x = hin_a - cp_a*(Tin_a - T_a_x);
					// New "water" temperature (stored temporarily to be able to build change
						//HOWARDCHANGE
						Tout_r=(Cmin)/(cp_r * mdot_r)*epsilon_dry*Tin_a+(1-(Cmin)/(cp_r * mdot_r)*epsilon_dry)*T_w_x;
						change=Tout_r-Tout_r_guess;
						//~ Tout_r=Tout_r_temp;
						//HOWARDCHANGE
						if(iter>500){
							printf("Superheated region wet analysis f_dry convergence failed \n");
							DWS->Q=Q_dry;
							return;
						}
						
					if (iter==1)
					{
						y1=change;
					}
					if (iter>1)
					{
						y2=change;
						x3=x2-y2/(y2-y1)*(x2-x1);
						change=fabs(y2/(y2-y1)*(x2-x1));
						y1=y2; x1=x2; x2=x3;
					}
					printf("Partwet iter %d Toutr %0.5f dT %g\n",iter,Tout_r_guess,Tout_r,change);
					//Update loop counter
					iter++;
				}
				// Wet-analysis saturation enthalpy
					h_s_s_e=h_a_x+(hout_a-h_a_x)/(1-exp(-(1-f_dry)*Ntu_owet));									//[J/kg]
				// Surface effective temperature
					T_s_e=T_hss(h_s_s_e/1000.0,pin_a,Tin_r);										//[K]
				// Air outlet temp based on effective surface temp
					Tout_a=T_s_e + (T_a_x-T_s_e)*exp(-(1-f_dry)*Ntu_o);
				// Heat transferred
					Q=mdot_r*cp_r*(Tout_r-Tin_r);
				// Dry-analysis air outlet enthalpy from energy balance
					hout_a=hin_a-Q/mdot_a;
			}
			else
			{
				Q=Q_wet;
			}
		}
		else
		{
			Tout_a=Tout_a_dry;
			Q=Q_dry;
		}
	}
	//printf("%d,%g\n",DWS->IsTwoPhase,DWS->f_dry);
	DWS->f_dry=f_dry;
	HumAir(Tout_a,101.325,GIVEN_ENTHALPY,hout_a/1000.0,&Tdp_dummy,&(DWS->omega_out),&h_dummy,&(DWS->RHout_a),&v_dummy);
	DWS->Tdbout_a=Tout_a;
	DWS->Q=Q;
	DWS->hout_a=hout_a;
	DWS->hin_a=hin_a;
	return;
}

static double TwoPhase_InnerLoop(double x_min)
{
	double h_fg,ID,G_r,Q_target;
	// Latent heat
		h_fg=(Props('H','T',Inputs.Tsat_r,'Q',1.0,Ref)-Props('H','T',Inputs.Tsat_r,'Q',0.0,Ref))*1000.; //[J/kg]
	// Target heat
		Q_target=Inputs.mdot_r*(1.0-x_min)*h_fg;

	/* This block calculates the average refrigerant heat transfer coefficient by
	/ integrating the local heat transfer coefficient between the
	/ inlet quality and a quality of 1.0 */
		//Inner diameter
			ID=Inputs.ID;												// [m]
		//Mass flux of refrigerant in circuit
			G_r = Inputs.mdot_r/((double)Inputs.Ncircuits) / (pi / 4.0 * (ID*ID)); 		// [kg/m^2-s]
		//Average Refrigerant heat transfer coefficient
			DWS2phase.h_r=ShahEvaporation_Average(Ref,G_r,ID,x_min,0.999,Inputs.Tsat_r,Q_target/DWS2phase.A_r);

	DryWetSegment(&DWS2phase);

	if (Outputs.ExistsSubcool==-1 && !strcmp(Inputs.Mode,"Backward"))
	{
		// First iteration, check the existence of subcooled region
		if (DWS2phase.Q>Q_target)
		{
			// If the amount transferred is greater than the latent heat, 
			// there must be subcooled region and the outlet of the 
			// two-phase region inlet is saturated liquid

			// Amount of heat needed to be transfered (target) is equal to latent heat
				Outputs.ExistsSubcool=1;
		}
		else
		{
			// No subcooled section
			Outputs.ExistsSubcool=0;
		}
	}
	return DWS2phase.Q-Q_target;
}
static double TwoPhase_Forward(double w_2phase)
{
	double G_r,x_min,ID,xv[30],rho_2phase[30],alpha[30],V_r,sum=0.0,
		v_g,v_f,dpdz_dummy,alpha_min,DP_accel,DP_frict,x1,x2,residual,rhog,rhof,S,
		C,rho_average,alpha_average;
	struct DWSVals DWS; //DryWetSegment
	int i;

	// Store temporary values to be passed to DryWetSegment
		DWS.A_a=FinInputs.Fins.A_a*w_2phase;
		DWS.cp_a=FinInputs.Fins.cp_a;
		DWS.eta_a=FinInputs.Fins.eta_a;
		DWS.mdot_a=FinInputs.Fins.mdot_a*w_2phase;
		DWS.pin_a=Inputs.pin_a;
		DWS.h_a=FinInputs.Fins.h_a;  //Heat transfer coefficient

	// Inputs on the air side to two phase region are outputs from superheated region
		//DWS.Tin_a=Inputs.Tdbout_superheat;
		//DWS.RHin_a=Inputs.RHout_superheat;
		DWS.Tin_a=Inputs.Tin_a;
		DWS.RHin_a=Inputs.RHin_a;

		DWS.Tin_r=Inputs.Tsat_r;
		DWS.A_r=Inputs.Ncircuits*pi*Inputs.ID*Inputs.Lcircuit*w_2phase;
		DWS.cp_r=1.0e15; // In the two-phase region the cp is infinite, use 1e15 as a big number;
		DWS.pin_r=Inputs.pout_r;
		DWS.mdot_r=Inputs.mdot_r;
		DWS.IsTwoPhase=1;

	// Copy DWS values to global structure to have data available in Dekker solver
		DWS2phase=DWS;
	
	x_min=Inputs.xin_r;
	residual=TwoPhase_InnerLoop(x_min);

	//// Allow it to check for the existence of the subcooled region, 
	////	use residual from TwoPhase_InnerLoop in outer Dekker solve
	//	residual=TwoPhase_InnerLoop(0.0);

	//// If the subcooled region doesn't exist, solve for the inlet quality, 
	////	otherwise you know the inlet state of the Two-phase portion is saturated liquid 
	//if (Outputs.ExistsSubcool==0)
	//{
	//	x_min=Dekker(TwoPhase_InnerLoop,0.0,0.9999,0.01);
	//	residual=0.0;
	//}
	//else
	//	x_min=0.0;
	//	// residual comes from above call: residual=TwoPhase_InnerLoop(0.0);

	// Copy structure back
	DWS=DWS2phase;

	ID=Inputs.ID;
	G_r=Inputs.mdot_r/((double)Inputs.Ncircuits) / (pi / 4.0 * (ID*ID)); 		// [kg/m^2-s]	

	V_r=Inputs.Ncircuits*Inputs.Lcircuit* pi*Inputs.ID*Inputs.ID/4.0*w_2phase;
	/*
	After finishing the two-phase part, 
	Calculations for refrigerant charge, with the assumption of homogeneous flow
	*/
	for (i=1;i<30;i++)
	{
		rhog=Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref);
		rhof=Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
		xv[i] = (i - 1) * (x_min - 0.0) / 29;
		S=pow(rhof/rhog,0.3333);
		alpha[i] = 1 / (1 + S*(1 - xv[i]) / xv[i] * rhog/rhof);
		rho_2phase[i] = alpha[i] * Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref) + (1 - alpha[i]) * Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
	}
	for(i=1;i<29;i++)
		sum += (rho_2phase[i] + rho_2phase[i + 1]) / 2 / 29;
	Outputs.Charge_2phase = sum * w_2phase * V_r;


	rhog=Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref);
	rhof=Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
	S=pow(rhof/rhog,0.3333);
	C=S*rhog/rhof;
	x1=x_min;
	x2=0.0;
	if (x1==0.0)
		alpha_average=1.0;
	else
		alpha_average=-(C*(log( ((x2-1.0)*C-x2)/((x1-1.0)*C-x1) )+x2-x1)-x2+x1)/(C*C-2*C+1)/(x2-x1);
	rho_average= alpha_average*rhog + (1-alpha_average)*rhof;
	Outputs.Charge_2phase = rho_average * w_2phase * V_r;


	// Find void fraction at inlet quality from Lockhart-Martinelli separated flow relation
		LockhartMartinelli(Ref, G_r, ID, x_min, Inputs.Tsat_r, &dpdz_dummy, &alpha_min);
	// Accelerational pressure drop component
		v_g=1./Props('D','T',Inputs.Tsat_r,'Q',1.0,Ref);
		v_f=1./Props('D','T',Inputs.Tsat_r,'Q',0.0,Ref);
		if (x_min==0.0)
			DP_accel=G_r*G_r*(v_f-v_g);
		else if (x_min==1.0)
			DP_accel=0.0;
		else
			DP_accel=G_r*G_r*(v_f-(x_min*x_min/alpha_min*v_g+(1-x_min)*(1-x_min)*v_f/(1-alpha_min)));
	// Frictional pressure drop component
		DP_frict=LMPressureGradientAvg(Ref,G_r,Inputs.ID,x_min,1.0,Inputs.Tsat_r)*Inputs.Lcircuit*w_2phase;

	Outputs.DP_2phase=-(DP_frict+DP_accel);
	
	Outputs.f_dry=DWS.f_dry;
	Outputs.Q_2phase=DWS.Q;
	Inputs.Tdbout_2phase=DWS.Tdbout_a;
	Inputs.RHout_2phase=DWS.RHout_a;
	Inputs.haout_2phase=DWS.hout_a;
	Outputs.h_2phase=DWS.h_r;
	Outputs.omega_tpout = DWS.omega_out;
	return residual;

}
static double TwoPhase(double w_2phase)
{
	double G_r,x_min,ID,xv[30],rho_2phase[30],alpha[30],V_r,sum=0.0,
		v_g,v_f,dpdz_dummy,alpha_min,DP_accel,DP_frict,x1,x2,residual,rhog,rhof,S,
		C,rho_average,alpha_average;
	struct DWSVals DWS; //DryWetSegment
	int i;

	// Store temporary values to be passed to DryWetSegment
		DWS.A_a=FinInputs.Fins.A_a*w_2phase;
		DWS.cp_a=FinInputs.Fins.cp_a;
		DWS.eta_a=FinInputs.Fins.eta_a;
		DWS.mdot_a=FinInputs.Fins.mdot_a*w_2phase;
		DWS.pin_a=Inputs.pin_a;
		DWS.h_a=FinInputs.Fins.h_a;  //Heat transfer coefficient

	// Inputs on the air side to two phase region are outputs from superheated region
		//DWS.Tin_a=Inputs.Tdbout_superheat;
		//DWS.RHin_a=Inputs.RHout_superheat;
		DWS.Tin_a=Inputs.Tin_a;
		DWS.RHin_a=Inputs.RHin_a;

		DWS.Tin_r=Inputs.Tsat_r;
		DWS.A_r=Inputs.Ncircuits*pi*Inputs.ID*Inputs.Lcircuit*w_2phase;
		DWS.cp_r=1.0e15; // In the two-phase region the cp is infinite, use 1e15 as a big number;
		DWS.pin_r=Inputs.pout_r;
		DWS.mdot_r=Inputs.mdot_r;
		DWS.IsTwoPhase=1;

	// Copy DWS values to global structure to have data available in Dekker solver
		DWS2phase=DWS;

	// Allow it to check for the existence of the subcooled region, 
	//	use residual from TwoPhase_InnerLoop in outer Dekker solve
		residual=TwoPhase_InnerLoop(0.0);

	// If the subcooled region doesn't exist, solve for the inlet quality, 
	//	otherwise you know the inlet state of the Two-phase portion is saturated liquid 
	if (Outputs.ExistsSubcool==0)
	{
		x_min=Dekker(TwoPhase_InnerLoop,0.0,0.9999,0.01);
		residual=0.0;
	}
	else
		x_min=0.0;
		// residual comes from above call: residual=TwoPhase_InnerLoop(0.0);

	// Copy structure back
		DWS=DWS2phase;

	ID=Inputs.ID;
	G_r=Inputs.mdot_r/((double)Inputs.Ncircuits) / (pi / 4.0 * (ID*ID)); 		// [kg/m^2-s]
			

	V_r=Inputs.Ncircuits*Inputs.Lcircuit* pi*Inputs.ID*Inputs.ID/4.0*w_2phase;
	/*
	After finishing the two-phase part, 
	Calculations for refrigerant charge, with the assumption of homogeneous flow
	*/
	for (i=1;i<30;i++)
	{
		rhog=Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref);
		rhof=Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
		xv[i] = (i - 1) * (x_min - 0.0) / 29;
		S=pow(rhof/rhog,0.3333);
		alpha[i] = 1 / (1 + S*(1 - xv[i]) / xv[i] * rhog/rhof);
		rho_2phase[i] = alpha[i] * Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref) + (1 - alpha[i]) * Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
	}
	for(i=1;i<29;i++)
		sum += (rho_2phase[i] + rho_2phase[i + 1]) / 2 / 29;
	Outputs.Charge_2phase = sum * w_2phase * V_r;


	rhog=Props('D', 'T', Inputs.Tsat_r, 'Q', 1, Ref);
	rhof=Props('D', 'T', Inputs.Tsat_r, 'Q', 0, Ref);
	S=pow(rhof/rhog,0.3333);
	C=S*rhog/rhof;
	x1=x_min;
	x2=0.0;
	if (x1==0.0)
		alpha_average=1.0;
	else
		alpha_average=-(C*(log( ((x2-1.0)*C-x2)/((x1-1.0)*C-x1) )+x2-x1)-x2+x1)/(C*C-2*C+1)/(x2-x1);
	rho_average= alpha_average*rhog + (1-alpha_average)*rhof;
	Outputs.Charge_2phase = rho_average * w_2phase * V_r;


	// Find void fraction at inlet quality from Lockhart-Martinelli separated flow relation
		LockhartMartinelli(Ref, G_r, ID, x_min, Inputs.Tsat_r, &dpdz_dummy, &alpha_min);
	// Accelerational pressure drop component
		v_g=1./Props('D','T',Inputs.Tsat_r,'Q',1.0,Ref);
		v_f=1./Props('D','T',Inputs.Tsat_r,'Q',0.0,Ref);
		if (x_min==0.0)
			DP_accel=G_r*G_r*(v_f-v_g);
		else if (x_min==1.0)
			DP_accel=0.0;
		else
			DP_accel=G_r*G_r*(v_f-(x_min*x_min/alpha_min*v_g+(1-x_min)*(1-x_min)*v_f/(1-alpha_min)));
	// Frictional pressure drop component
		DP_frict=LMPressureGradientAvg(Ref,G_r,Inputs.ID,x_min,1.0,Inputs.Tsat_r)*Inputs.Lcircuit*w_2phase;

	Outputs.DP_2phase=-(DP_frict+DP_accel);
	
	Outputs.f_dry=DWS.f_dry;
	Outputs.Q_2phase=DWS.Q;
	Inputs.Tdbout_2phase=DWS.Tdbout_a;
	Inputs.RHout_2phase=DWS.RHout_a;
	Inputs.haout_2phase=DWS.hout_a;
	Outputs.h_2phase=DWS.h_r;
	Outputs.omega_tpout = DWS.omega_out;
	return residual;
}

static double Superheat(double w_superheat)
{
	double Q_target,f_r,h_r,Re_r,V_r,rho_superheat,G_r,A_r,v_r,Dh_r,dpdz_r;
	struct DWSVals DWS; //DryWetSegment

	// Store temporary values to be passed to DryWetSegment
		DWS.A_a=FinInputs.Fins.A_a*w_superheat;
		DWS.cp_a=FinInputs.Fins.cp_a;
		DWS.h_a=FinInputs.Fins.h_a;
		DWS.Tin_a=Inputs.Tin_a;
		DWS.eta_a=FinInputs.Fins.eta_a;
		DWS.mdot_a=FinInputs.Fins.mdot_a*w_superheat;
		DWS.pin_a=Inputs.pin_a;
		DWS.RHin_a=Inputs.RHin_a;

	// Evaluate superheated friction factor and heat transfer
		f_h_1phase_Tube(Inputs.mdot_r/((double)Inputs.Ncircuits), Inputs.ID,	//[kg/s],[m]
			(Inputs.Tsat_r+Inputs.Tout_r)/2.0, Inputs.pout_r, Ref,				//[K],[kPa]
			"Single", &f_r, &h_r, &Re_r);										//[-],[W/m^2-K],[-]

		DWS.h_r=h_r;
		DWS.Tin_r=Inputs.Tsat_r;
		DWS.A_r=Inputs.Ncircuits*Inputs.Lcircuit*pi*Inputs.ID*w_superheat;
		DWS.cp_r=Props('C','T',(Inputs.Tout_r+Inputs.Tsat_r)/2.0,'P',Inputs.pout_r,Ref)*1000.; //[J/kg]
		DWS.pin_r=Inputs.pout_r;
		DWS.mdot_r=Inputs.mdot_r;

		DWS.IsTwoPhase=0;

		DryWetSegment(&DWS);

	// Heat needed to take the refrigerant from the saturation temp to the outlet temp
		Q_target=Inputs.mdot_r*DWS.cp_r*(Inputs.Tout_r-Inputs.Tsat_r);

	Inputs.hin_a=DWS.hin_a;
	Inputs.Tdbout_superheat=DWS.Tdbout_a;
	Inputs.RHout_superheat=DWS.RHout_a;
	Inputs.haout_superheat=DWS.hout_a;
	Outputs.Q_superheat=DWS.Q;
	Outputs.h_superheat=DWS.h_r;
	Outputs.Re_superheat=DWS.Re_r;
	Outputs.omega_shout = DWS.omega_out;

	V_r=Inputs.Ncircuits*Inputs.Lcircuit* pi*Inputs.ID*Inputs.ID/4.0*w_superheat;
	rho_superheat=Props('D','T',(Inputs.Tout_r+Inputs.Tsat_r)/2.0,'P',Inputs.pout_r,Ref);
	Outputs.Charge_superheat=rho_superheat*V_r;

	//Pressure drop calculations for superheated refrigerant
		Dh_r=Inputs.ID;																//[
		A_r=pi*Dh_r*Dh_r/4.0;
		G_r=Inputs.mdot_r/((double)Inputs.Ncircuits)/A_r;
		v_r=1/rho_superheat;
	//Pressure gradient using Darcy friction factor
		dpdz_r=-f_r*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
		Outputs.DP_superheat=dpdz_r*Inputs.Lcircuit*w_superheat;

	return DWS.Q-Q_target;
}

static void Superheat_Forward(double w_superheat)
{
	double Q_target,f_r,h_r,Re_r,V_r,rho_superheat,G_r,A_r,v_r,Dh_r,dpdz_r;
	struct DWSVals DWS; //DryWetSegment

	// Store temporary values to be passed to DryWetSegment
	DWS.A_a=FinInputs.Fins.A_a*w_superheat;
	DWS.cp_a=FinInputs.Fins.cp_a;
	DWS.h_a=FinInputs.Fins.h_a;
	DWS.Tin_a=Inputs.Tin_a;
	DWS.eta_a=FinInputs.Fins.eta_a;
	DWS.mdot_a=FinInputs.Fins.mdot_a*w_superheat;
	DWS.pin_a=Inputs.pin_a;
	DWS.RHin_a=Inputs.RHin_a;

	// Evaluate superheated friction factor and heat transfer
	f_h_1phase_Tube(Inputs.mdot_r/((double)Inputs.Ncircuits), Inputs.ID,	//[kg/s],[m]
		(Inputs.Tsat_r+3), Inputs.pout_r, Ref,				//[K],[kPa]
		"Single", &f_r, &h_r, &Re_r);										//[-],[W/m^2-K],[-]

	DWS.h_r=h_r;
	DWS.Tin_r=Inputs.Tsat_r;
	DWS.A_r=Inputs.Ncircuits*Inputs.Lcircuit*pi*Inputs.ID*w_superheat;
	DWS.cp_r=Props('C','T',Inputs.Tsat_r+3,'P',Inputs.pout_r,Ref)*1000.; //[J/kg]
	DWS.pin_r=Inputs.pout_r;
	DWS.mdot_r=Inputs.mdot_r;

	DWS.IsTwoPhase=0;

	//Call DryWetSegment with DWS structure
	DryWetSegment(&DWS);

	// Heat needed to take the refrigerant from the saturation temp to the outlet temp
	Inputs.Tout_r=Inputs.Tsat_r+DWS.Q/(Inputs.mdot_r*DWS.cp_r);
	Outputs.Tout_r=Inputs.Tout_r;

	Inputs.hin_a=DWS.hin_a;
	Inputs.Tdbout_superheat=DWS.Tdbout_a;
	Inputs.RHout_superheat=DWS.RHout_a;
	Inputs.haout_superheat=DWS.hout_a;
	Outputs.Q_superheat=DWS.Q;
	Outputs.h_superheat=DWS.h_r;
	Outputs.Re_superheat=DWS.Re_r;
	Outputs.omega_shout = DWS.omega_out;
	Outputs.w_superheat = w_superheat;

	V_r=Inputs.Ncircuits*Inputs.Lcircuit* pi*Inputs.ID*Inputs.ID/4.0*w_superheat;
	rho_superheat=Props('D','T',(Inputs.Tout_r+Inputs.Tsat_r)/2.0,'P',Inputs.pout_r,Ref);
	Outputs.Charge_superheat=rho_superheat*V_r;

	Outputs.DT_sh=Outputs.Tout_r-Tsat(Ref,DWS.pin_r,1.0,Inputs.Tsat_r);

	//Pressure drop calculations for superheated refrigerant
		Dh_r=Inputs.ID;																//[
		A_r=pi*Dh_r*Dh_r/4.0;
		G_r=Inputs.mdot_r/((double)Inputs.Ncircuits)/A_r;
		v_r=1/rho_superheat;
	//Pressure gradient using Darcy friction factor
		dpdz_r=-f_r*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
		Outputs.DP_superheat=dpdz_r*Inputs.Lcircuit*w_superheat;
	return;
}

static double Subcooled(double Tin_r)
{
	// This function is driven by Dekker solver in order to get the 
	double Q_target,f_r,h_r,Re_r,V_r,rho_subcool,G_r,A_r,v_r,Dh_r,dpdz_r;
	struct DWSVals DWS; //DryWetSegment

	// Store temporary values to be passed to DryWetSegment
		DWS.A_a=FinInputs.Fins.A_a*w_subcool;
		DWS.cp_a=FinInputs.Fins.cp_a;
		DWS.h_a=FinInputs.Fins.h_a;
		DWS.eta_a=FinInputs.Fins.eta_a;
		DWS.mdot_a=FinInputs.Fins.mdot_a;
		DWS.pin_a=Inputs.pin_a;

	// Inputs on the air side to two phase region are outputs from superheated region
		DWS.Tin_a=Inputs.Tdbout_2phase;
		DWS.RHin_a=Inputs.RHout_2phase;

	// Evaluate subcooled friction factor and heat transfer
		f_h_1phase_Tube(Inputs.mdot_r/((double)Inputs.Ncircuits), Inputs.ID,	//[kg/s],[m]
			(Inputs.Tsat_r+Tin_r)/2.0, Inputs.pout_r, Ref,				//[K],[kPa]
			"Single", &f_r, &h_r, &Re_r);										//[-],[W/m^2-K],[-]

		DWS.h_r=h_r;
		DWS.Tin_r=Tin_r;
		DWS.A_r=Inputs.Ncircuits*Inputs.Lcircuit*pi*Inputs.ID*w_subcool;
		DWS.cp_r=Props('C','T',(Tin_r+Inputs.Tsat_r)/2.0,'P',Inputs.pout_r,Ref)*1000.; //[J/kg]
		DWS.pin_r=Inputs.pout_r;
		DWS.mdot_r=Inputs.mdot_r;

		DWS.IsTwoPhase=0;

		DryWetSegment(&DWS);

	// Heat needed to take the refrigerant from the saturation temp to the outlet temp
		Q_target=Inputs.mdot_r*DWS.cp_r*(Inputs.Tsat_r-Tin_r);

	Inputs.hin_a=DWS.hin_a;
	Outputs.Q_subcool=DWS.Q;
	Outputs.h_subcool=DWS.h_r;
	Outputs.Re_subcool=DWS.Re_r;

	V_r=Inputs.Ncircuits*Inputs.Lcircuit* pi*Inputs.ID*Inputs.ID/4.0*w_subcool;
	rho_subcool=Props('D','T',(Tin_r+Inputs.Tsat_r)/2.0,'P',Inputs.pout_r,Ref);
	Outputs.Charge_subcool=rho_subcool*V_r;

	//Pressure drop calculations for superheated refrigerant
		Dh_r=Inputs.ID;																//[
		A_r=pi*Dh_r*Dh_r/4.0;
		G_r=Inputs.mdot_r/((double)Inputs.Ncircuits)/A_r;
		v_r=1/rho_subcool;
	//Pressure gradient using Darcy friction factor
		dpdz_r=-f_r*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
		Outputs.DP_subcool=dpdz_r*Inputs.Lcircuit*w_subcool;

	return DWS.Q-Q_target;
}

int Evaporator_Calculate(char *Ref_, struct FinHTCDPInputsVals *FinInputs_, struct EvaporatorInputVals *Inputs_, struct EvaporatorOutputVals *Outputs_)
{
	double w_superheat,xin_r,w_2phase;
	int finType,WAVY_LOUVERED_FINS=2,WAVY_FINS=1;
	extern int runFail;

	//Copy values from passed variables to temporary global variables
		Inputs=*Inputs_;
		FinInputs=*FinInputs_;
		Outputs=*Outputs_;
		Ref=Ref_;

	finType=WAVY_LOUVERED_FINS;

	//Initialize with undefined value
	Outputs.ExistsSubcool=-1;

	//Set the ratio cs/cp equal to unity to use dry condition
	FinInputs.Air.cs_cp=1.0;

	if (finType==WAVY_FINS)
		finFunc=WavyFins;
	else if (finType==WAVY_LOUVERED_FINS)
		finFunc=WavyLouveredFins;

	// Evaluate the air-side heat transfer and pressure drop
	finFunc(&FinInputs);

	if (Inputs.Mode && !strcmp(Inputs.Mode,"Forward"))
	{
		// Use Dekker method to solve for area fraction that is in two-phase section
		w_2phase=Dekker(TwoPhase_Forward,0.00001,0.999,0.01);
		Superheat_Forward(1-w_2phase);
	}
	else
	{
		// Use Dekker to solve for the section of the evaporator that is superheated
		w_superheat=Dekker(Superheat,0.00001,0.8,0.01);

		// Clear the wet Fin computation by recomputing the fin properties
		//Set the ratio cs/cp equal to unity to use dry condition
		FinInputs.Air.cs_cp=1.0;
		// Evaluate the air-side heat transfer and pressure drop
		finFunc(&FinInputs);

		// Use the remaining area for the two-phase region
		TwoPhase(1-w_superheat);

		// If using all the remaining area results in a Q greater than 
		// the latent heat at the saturation temp, there is a subcooling region

		if (Outputs.ExistsSubcool==0)
		{
			//Outputs.hout_a=Inputs.haout_2phase;
			Outputs.hout_a=Inputs.haout_2phase*(1-w_superheat) + Inputs.haout_superheat*w_superheat;

			Outputs.Q=Outputs.Q_superheat+Outputs.Q_2phase;
			Outputs.DP_subcool=0.0;
			Outputs.DP=Outputs.DP_superheat+Outputs.DP_2phase;
			//Outputs.SHR=FinInputs.Fins.cp_a*(Inputs.Tin_a-Inputs.Tdbout_2phase)/(Inputs.hin_a-Outputs.hout_a);
			Outputs.hin_r=Props('H','T',Inputs.Tsat_r,'Q',1.0,Ref)*1000.0-Outputs.Q_2phase/Inputs.mdot_r;
			xin_r=(Outputs.hin_r-Props('H','T',Inputs.Tsat_r,'Q',0,Ref)*1000)/
				(Props('H','T',Inputs.Tsat_r,'Q',1,Ref)*1000-Props('H','T',Inputs.Tsat_r,'Q',0,Ref)*1000);
			Outputs.Tin_r=Inputs.Tsat_r;
			Outputs.sin_r=Props('S','T',Inputs.Tsat_r,'Q',xin_r,Ref)*1000;
			Outputs.xin_r=xin_r;
			//Outputs.Tout_a=Inputs.Tdbout_2phase;
			
			Outputs.Tout_a=Inputs.Tdbout_2phase*(1-w_superheat) + Inputs.Tdbout_superheat*w_superheat;
			Outputs.omega_out = Outputs.omega_tpout*(1-w_superheat) + Outputs.omega_shout*w_superheat;
			Outputs.Tout_a=T_homega(Outputs.hout_a/1000.0, Outputs.omega_out, Inputs.pin_a, Outputs.Tout_a, 1);
			Outputs.SHR=FinInputs.Fins.cp_a*(Inputs.Tin_a-Outputs.Tout_a)/(Inputs.hin_a-Outputs.hout_a);

			Outputs.w_2phase=1-w_superheat;
			Outputs.w_subcool=0.0;
			Outputs.h_subcool=0.0;
			Outputs.Q_subcool=0.0;
			Outputs.Charge_subcool=0.0;
			
		}
		else
		{
			fprintf(stderr,"Error: Subcooling in evaporator not possible\n");
			strcpy(runFailString,"Error: Subcooling in evaporator not possible");
			return FUNC_FAILED;
		}
	}

	Outputs.Charge=Outputs.Charge_2phase+Outputs.Charge_superheat;
	Outputs.hout_r=Props('H','T',Inputs.Tout_r,'P',Inputs.pout_r,Ref)*1000.0; //[J/kg]
	Outputs.sout_r=Props('S','T',Inputs.Tout_r,'P',Inputs.pout_r,Ref)*1000.0; //[J/kg-K]
	
	
	//Copy values back to passed variables
	*Inputs_=Inputs;
	*FinInputs_=FinInputs;
	*Outputs_=Outputs;
	
	return 0;
}
