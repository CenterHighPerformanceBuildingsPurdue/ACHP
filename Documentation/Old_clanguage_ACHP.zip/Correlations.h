

#ifndef CORRELATIONS_H
#define CORRELATIONS_H

struct TubesVals
{
	int Ntubes_bank;
	int Nbank;
	double Ltube;
	double D;
	double Pl;
	double Pt;
};

struct FinsVals
{
	//Inputs
	double FPI;
	double Pd;
	double xf;
	double t;
	double k_fin;

	//Outputs
	double h_a;
	double A_a;
	double eta_a;
	double cp_a;
	double mdot_a;
	double f_a;
	double dP_a;
};

struct AirVals
{
	double Vdot_ha;
	double Tdb;
	double p;
	double RH;
	double cs_cp; // Ratio of saturated air specific heat to air specific heat
	double Tmean;
	double RHmean;
};

struct FinHTCDPInputsVals
{
	struct TubesVals Tubes;
	struct FinsVals Fins;
	struct AirVals Air;
};

double ShahEvaporation(char * Ref, double G, double D, double x, double T, double q_flux);
double ShahEvaporation_Average(char * Ref, double G, double D, double x_min, double x_max, double T, double q_flux);


double ShahCondensation(char * Ref, double G, double  D, double x, double T);
double ShahCondensation_Average(char *Ref, double G, double D, double x_min, double x_max, double T);

void f_h_1phase_Tube(double mdot, double OD, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re);
void f_h_1phase_Annulus(double mdot, double OD, double ID, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re);
void f_h_1phase_Channel(double mdot, double W, double H, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re, double *Dh);
void WavyFins(struct FinHTCDPInputsVals *Inputs);
void WavyLouveredFins(struct FinHTCDPInputsVals *Inputs);
void LockhartMartinelli(char *Ref, double G, double D, double x, double Tsat, double *dpdz, double *alpha);
double LMPressureGradientAvg(char *Ref, double G, double D, double x_min, double x_max, double T);

#endif