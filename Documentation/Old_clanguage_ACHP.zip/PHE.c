#include "Props/CoolProp.h"
#include "Correlations.h"
#include "PHE.h"
#include "stdio.h"

void CalculatePHE(struct PHEInputVals *Inputs, struct PHEOutputVals *Outputs)
{
	int Phase_hi,Phase_ho,Phase_ci,Phase_co;
	double A_HT, A_flow,f_h,hc_h,Re_h,f_c,hc_c,Re_c,epsilon,
		UA,NTU,Cmin,mdoth_channel,mdotc_channel,Dh_h,Dh_c,v_c,v_h,DP_c,
		DP_h,G_c,G_h;

	// First check if you could have phase change at constant pressure HT
	Phase_hi=Phase('T',Inputs->Tin_h,'P',Inputs->pin_h,Inputs->Ref_h);
	// TODO: fix artificial enforcing of outlet state
	Phase_ho=Phase('T',0.5*Inputs->Tin_c+0.5*Inputs->Tin_h,'P',Inputs->pin_h,Inputs->Ref_h);
	Phase_ci=Phase('T',Inputs->Tin_c,'P',Inputs->pin_c,Inputs->Ref_c);
	Phase_co=Phase('T',Inputs->Tin_h,'P',Inputs->pin_c,Inputs->Ref_c);

	// Both streams have this HT area [m^2]:
	A_HT=2.0*Inputs->W*Inputs->H*(Inputs->Nplates-2);
	
	// Assuming the flow area for both streams to be the same,
	// the flow cross-sectional area is
	A_flow=Inputs->spacing*Inputs->W;

	if (Phase_hi==Phase_ho && Phase_ci==Phase_co)
	{
		//Single phase throughout PHE
		printf("Single phase throughout PHE\n");

		// Mass flow per channel:
		mdoth_channel=Inputs->mdot_h/((double)((Inputs->Nplates-1)/2));
		mdotc_channel=Inputs->mdot_c/((double)((Inputs->Nplates-1)/2));

		// Phase HTC and friction factors:
		f_h_1phase_Channel(mdoth_channel,Inputs->W,Inputs->spacing,Inputs->Tin_h,
			Inputs->pin_h,Inputs->Ref_h,"Single",&f_h,&hc_h,&Re_h,&Dh_h);
		f_h_1phase_Channel(mdotc_channel,Inputs->W,Inputs->spacing,Inputs->Tin_c,
			Inputs->pin_c,Inputs->Ref_c,"Single",&f_c,&hc_c,&Re_c,&Dh_c);
		hc_h=1600;
		hc_c=400;
		//Effectiveness-NTU relationships for pure counterflow
		UA=1/(1/(hc_c*A_HT)+1/(hc_h*A_HT)); //[W/K];
		Cmin=Inputs->mdot_c*Props('C','T',Inputs->Tin_c,'P',Inputs->pin_c,Inputs->Ref_c)*1000; //[J/kg-K]
		//UA=450;
		NTU=UA/Cmin;
		epsilon=1-exp(-NTU);
		

		Outputs->Q = epsilon * Cmin * (Inputs->Tin_h -Inputs->Tin_c); //[W]

		//Pressure drop calculations
		v_h=1/Props('D','T',Inputs->Tin_h, 'P',Inputs->pin_h,Inputs->Ref_h);	//[m^3/kg]
		v_c=1/Props('D','T',Inputs->Tin_c, 'P',Inputs->pin_c,Inputs->Ref_c);	//[m^3/kg]
		G_h=mdoth_channel/A_flow;
		G_c=mdotc_channel/A_flow;
		DP_h=-f_h*v_h*G_h*G_h/(2*Dh_h)*Inputs->H;  	//[Pa]
		DP_c=-f_c*v_c*G_c*G_c/(2*Dh_c)*Inputs->H;  	//[Pa]
	}
	
	printf("%d\n",Inputs->Nplates);
}