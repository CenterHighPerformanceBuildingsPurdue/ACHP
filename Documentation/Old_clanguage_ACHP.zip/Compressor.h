#ifndef COMPRESSOR_H
#define COMPRESSOR_H

struct CompressorInputVals
{
	double M1,M2,M3,M4,M5,M6,M7,M8,M9,M10;
	double P1,P2,P3,P4,P5,P6,P7,P8,P9,P10;
	double Tsat_s,Tsat_d,DT_sh,fp;
	double Vdot_ratio;
};

struct CompressorOutputVals
{
	double h1;
	double h2;
	double power;
	double mdot;
	double Td;
	double s1;
	double s2;
};

int Compressor_Calculate(char * Ref, struct CompressorInputVals *Inputs, struct CompressorOutputVals *Outputs);

#endif