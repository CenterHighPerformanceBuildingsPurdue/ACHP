#ifndef PUMP_H
#define PUMP_H

struct PumpInputVals{
	double Efficiency;
	double Vdot;
	double pout;
};

#endif