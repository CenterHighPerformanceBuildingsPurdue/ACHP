#ifndef INDOORCOIL_H
#define INDOORCOIL_H

struct IndoorCoilInputVals
{
	double Tin_g;
	double mdot_g;
	double pin_g;

	double Vdot_a;
	double pin_a;
	double Tin_a;
	double RHin_a;

	// Geometric Parameters
	double OD; // Outer diameter of the outer annulus (at inside of outer wall)
	double ID; // Outer diameter of the outer annulus (at inside of outer wall)
	double Lcircuit; //Average Length of a single circuit
	int Ncircuits;
	double FanPower;
};
struct IndoorCoilOutputVals
{
	double f_dry;
	double Q;
	double h,Re;
	double Tout_g;
	double Tout_a;
	double hout_a;
	double hin_a;
	double SHR;
	double DP_g;
	
};

int IndoorCoil_Calculate(char *SecondaryRef_, struct FinHTCDPInputsVals *FinInputs_, struct IndoorCoilInputVals *Inputs_, struct IndoorCoilOutputVals *Outputs_);

#endif