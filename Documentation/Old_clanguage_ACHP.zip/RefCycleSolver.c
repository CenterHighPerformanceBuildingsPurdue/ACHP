#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#include "string.h"
#include <stdio.h>


#include "Props/PropErrorCodes.h"
#include "Props/PropMacros.h"
#include "Props/R290.h"
#include "Props/R134a.h"
#include "Props/R410A.h"

#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"

#include "Compressor.h"
#include "Condenser.h"
#include "IHX.h"
#include "Pump.h"
#include "RefCycleSolver.h"
#include "PythonEntry.h"

#include "MatInv.h"

void MeanTairCondenser(struct runVals *run, double *Tmean, double *RHmean)
{
	double Q_cond_guess,DELTAh_cond_guess,Tdp,W,h_ha,RH,v,mdot_air,cp_ha;

	// Estimate the outlet air state of the condenser in order to get the average air temperature and RH
	Q_cond_guess=run->CompressorOutputs.mdot*(run->CompressorOutputs.h2-run->CondenserOutputs.hin_r);

	// Inlet air conditions
	HumAir(run->CondFinInputs.Air.Tdb, 101.325, GIVEN_RH, run->CondFinInputs.Air.RH, &Tdp, &W, &h_ha, &RH, &v);

	// Humid air mass flow rate
	mdot_air=run->CondFinInputs.Air.Vdot_ha*(1+W)/v;

	// Calculate the delta h of the air to get outlet temp
	DELTAh_cond_guess=Q_cond_guess/mdot_air;

	// cp of humid air
	cp_ha = (1.006 + W * 1.86) * 1000;

	// Mean temp
	*Tmean = run->CondFinInputs.Air.Tdb+DELTAh_cond_guess/cp_ha/2.0;

	// Get the mean humidity
	HumAir(*Tmean, 101.325, GIVEN_HUMRAT, W, &Tdp, &W, &h_ha, RHmean, &v);
}

void MeanTairEvaporator(struct runVals *run, double *Tmean, double *RHmean)
{
	double Q_evap_guess,DELTAh_evap_guess,Tdp,W,h_ha,RH,v,mdot_air,cp_ha;

	// Estimate the outlet air state of the evaporator in order to get the average air temperature and RH
	Q_evap_guess=run->CompressorOutputs.mdot*(run->EvaporatorOutputs.hout_r-run->CondenserOutputs.hout_r);

	// Inlet air conditions
	HumAir(run->EvaporatorFinInputs.Air.Tdb, 101.325, GIVEN_RH, run->EvaporatorFinInputs.Air.RH, &Tdp, &W, &h_ha, &RH, &v);

	// Humid air mass flow rate
	mdot_air=run->EvaporatorFinInputs.Air.Vdot_ha*(1+W)/v;

	// Calculate the delta h of the air to get outlet temp
	DELTAh_evap_guess=Q_evap_guess/mdot_air;

	// cp of humid air
	cp_ha = (1.005 + W * 1.814) / (1 + W) * 1000;

	// Mean temp
	*Tmean = run->EvaporatorFinInputs.Air.Tdb-DELTAh_evap_guess/cp_ha/2.0;

	// Get the mean humidity
	HumAir(*Tmean, 101.325, GIVEN_HUMRAT, W, &Tdp, &W, &h_ha, RHmean, &v);
}

void saveOutputs(struct CycleOutputVals *Outputs, struct runVals *run)
{
	double DP;
	extern int runFail;
	extern char runFailString[1000];

	Outputs->Compressorhin=run->CompressorOutputs.h1;
	Outputs->Compressorhout=run->CompressorOutputs.h2;
	Outputs->CompressorPower=run->CompressorOutputs.power;
	Outputs->Compressormdot=run->CompressorOutputs.mdot;
	Outputs->CompressorTin=run->CompressorInputs.Tsat_s+run->CompressorInputs.DT_sh;
	Outputs->CompressorTout=run->CompressorOutputs.Td;
	Outputs->Compressorsin=run->CompressorOutputs.s1;
	Outputs->Compressorsout=run->CompressorOutputs.s2;
	Outputs->Compressorpin=Props('P','T',run->CompressorInputs.Tsat_s,'Q',1.0,run->Cycle.PrimaryRef);
	Outputs->Compressorpout=Props('P','T',run->CompressorInputs.Tsat_d,'Q',1.0,run->Cycle.PrimaryRef);


	Outputs->Condenserhin=run->CondenserOutputs.hin_r;
	Outputs->Condenserhout=run->CondenserOutputs.hout_r;
	Outputs->CondenserQ=run->CondenserOutputs.Q;
	Outputs->CondenserQ_superheat=run->CondenserOutputs.Q_superheat;
	Outputs->CondenserQ_2phase=run->CondenserOutputs.Q_2phase;
	Outputs->CondenserQ_subcool=run->CondenserOutputs.Q_subcool;
	Outputs->Condenserh_superheat=run->CondenserOutputs.h_superheat;
	Outputs->Condenserh_2phase=run->CondenserOutputs.h_2phase;
	Outputs->Condenserh_subcool=run->CondenserOutputs.h_subcool;
	Outputs->Condenserw_superheat=run->CondenserOutputs.w_superheat;
	Outputs->Condenserw_2phase=run->CondenserOutputs.w_2phase;
	Outputs->Condenserw_subcool=run->CondenserOutputs.w_subcool;
	Outputs->CondenserCharge_superheat=run->CondenserOutputs.Charge_superheat;
	Outputs->CondenserCharge_2phase=run->CondenserOutputs.Charge_2phase;
	Outputs->CondenserCharge_subcool=run->CondenserOutputs.Charge_subcool;
	Outputs->CondenserCharge=run->CondenserOutputs.Charge;
	Outputs->CondenserAirA_a=run->CondFinInputs.Fins.A_a;
	Outputs->CondenserAirh_a=run->CondFinInputs.Fins.h_a;
	Outputs->CondenserAireta_a=run->CondFinInputs.Fins.eta_a;
	Outputs->CondenserAirmdot_a=run->CondFinInputs.Fins.mdot_a;
	Outputs->CondenserAirdP_a=run->CondFinInputs.Fins.dP_a;
	Outputs->Condensersin=run->CondenserOutputs.sin;
	Outputs->Condensersout=run->CondenserOutputs.sout;
	Outputs->CondenserTin=run->CondenserOutputs.Tin_r;
	Outputs->CondenserTout=run->CondenserInputs.Tout_r;
	Outputs->Condenserpin=run->CondenserInputs.pout_r; // TODO: inlet pressure
	Outputs->Condenserpout=run->CondenserInputs.pout_r;
	Outputs->TsatCond=run->CondenserInputs.Tsat_r;
	Outputs->CondenserDP_r=run->CondenserOutputs.DP;
	Outputs->CondenserDP_r_superheat=run->CondenserOutputs.DP_superheat;
	Outputs->CondenserDP_r_2phase=run->CondenserOutputs.DP_2phase;
	Outputs->CondenserDP_r_subcool=run->CondenserOutputs.DP_subcool;


	Outputs->IHXxin_r=run->IHXOutputs.xin_r;
	Outputs->IHXhin_r=run->IHXOutputs.hin_r;
	Outputs->IHXhout_r=run->IHXOutputs.hout_r;
	Outputs->IHXsin_r=run->IHXOutputs.sin_r;
	Outputs->IHXsout_r=run->IHXOutputs.sout_r;
	Outputs->IHXTin_r=run->IHXOutputs.Tin_r;
	Outputs->IHXTout_r=run->IHXInputs.Tout_r;
	Outputs->IHXTin_g=run->IHXOutputs.Tin_g;
	Outputs->IHXTout_g=run->IHXOutputs.Tout_g;
	Outputs->IHXDP_g_superheat=run->IHXOutputs.DP_g_superheat;
	Outputs->IHXDP_g_2phase=run->IHXOutputs.DP_g_2phase;
	Outputs->IHXDP_g_subcool=run->IHXOutputs.DP_g_subcool;
	Outputs->IHXQ=run->IHXOutputs.Q;
	Outputs->IHXQ_superheat=run->IHXOutputs.Q_superheat;
	Outputs->IHXQ_2phase=run->IHXOutputs.Q_2phase;
	Outputs->IHXQ_subcool=run->IHXOutputs.Q_subcool;
	Outputs->IHXh_r_superheat=run->IHXOutputs.h_r_superheat;
	Outputs->IHXh_r_2phase=run->IHXOutputs.h_r_2phase;
	Outputs->IHXh_r_subcool=run->IHXOutputs.h_r_subcool;
	Outputs->IHXh_g_superheat=run->IHXOutputs.h_g_superheat;
	Outputs->IHXh_g_2phase=run->IHXOutputs.h_g_2phase;
	Outputs->IHXh_g_subcool=run->IHXOutputs.h_g_subcool;
	Outputs->IHXRe_g_superheat=run->IHXOutputs.Re_g_superheat;
	Outputs->IHXRe_g_2phase=run->IHXOutputs.Re_g_2phase;
	Outputs->IHXRe_g_subcool=run->IHXOutputs.Re_g_subcool;
	Outputs->IHXpin_r=run->IHXInputs.pout_r;
	Outputs->IHXpout_r=run->IHXInputs.pout_r;
	Outputs->IHXDP_r=run->IHXOutputs.DP_r;
	Outputs->IHXDP_r_superheat=run->IHXOutputs.DP_r_superheat;
	Outputs->IHXDP_r_2phase=run->IHXOutputs.DP_r_2phase;
	Outputs->IHXDP_r_subcool=run->IHXOutputs.DP_r_subcool;

	Outputs->IHXw_superheat=run->IHXOutputs.w_superheat;
	Outputs->IHXw_2phase=run->IHXOutputs.w_2phase;
	Outputs->IHXw_subcool=run->IHXOutputs.w_subcool;
	Outputs->IHXCharge_superheat=run->IHXOutputs.Charge_superheat;
	Outputs->IHXCharge_2phase=run->IHXOutputs.Charge_2phase;
	Outputs->IHXCharge_subcool=run->IHXOutputs.Charge_subcool;
	Outputs->IHXCharge=run->IHXOutputs.Charge;
	Outputs->IHXTin_g=run->IHXInputs.Tin_g;
	Outputs->IHXTout_g=run->IHXOutputs.Tout_g;

	
	Outputs->IndoorCoilQ=run->IndoorCoilOutputs.Q;
	Outputs->IndoorCoilSHR=run->IndoorCoilOutputs.SHR;
	Outputs->IndoorCoilh_g=run->IndoorCoilOutputs.h;
	Outputs->IndoorCoilRe_g=run->IndoorCoilOutputs.Re;
	Outputs->IndoorCoilDP_g=run->IndoorCoilOutputs.DP_g;
	Outputs->IndoorCoilTin_g=run->IndoorCoilInputs.Tin_g;
	Outputs->IndoorCoilTout_g=run->IndoorCoilOutputs.Tout_g;
	Outputs->IndoorCoilAirdP_a=run->IndoorCoilFinInputs.Fins.dP_a;
	Outputs->IndoorCoilAireta_a=run->IndoorCoilFinInputs.Fins.eta_a;
	Outputs->IndoorCoilAirh_a=run->IndoorCoilFinInputs.Fins.h_a;
	Outputs->IndoorCoilAirmdot_a=run->IndoorCoilFinInputs.Fins.mdot_a;
	Outputs->IndoorCoilAirA_a=run->IndoorCoilFinInputs.Fins.A_a;
	Outputs->IndoorCoilAirTout=run->IndoorCoilOutputs.Tout_a;
	Outputs->IndoorCoilAirf_dry=run->IndoorCoilOutputs.f_dry;

	Outputs->EvaporatorCharge=run->EvaporatorOutputs.Charge;
	Outputs->EvaporatorCharge_superheat=run->EvaporatorOutputs.Charge_superheat;
	Outputs->EvaporatorCharge_2phase=run->EvaporatorOutputs.Charge_2phase;
	Outputs->EvaporatorCharge_subcool=run->EvaporatorOutputs.Charge_subcool;
	Outputs->EvaporatorQ=run->EvaporatorOutputs.Q;
	Outputs->EvaporatorQ_superheat=run->EvaporatorOutputs.Q_superheat;
	Outputs->EvaporatorQ_2phase=run->EvaporatorOutputs.Q_2phase;
	Outputs->EvaporatorQ_subcool=run->EvaporatorOutputs.Q_subcool;
	Outputs->EvaporatorQ=run->EvaporatorOutputs.Q;
	Outputs->EvaporatorQ_superheat=run->EvaporatorOutputs.Q_superheat;
	Outputs->EvaporatorQ_2phase=run->EvaporatorOutputs.Q_2phase;
	Outputs->EvaporatorQ_subcool=run->EvaporatorOutputs.Q_subcool;
	Outputs->Evaporatorw_superheat=run->EvaporatorOutputs.w_superheat;
	Outputs->Evaporatorw_2phase=run->EvaporatorOutputs.w_2phase;
	Outputs->Evaporatorw_subcool=run->EvaporatorOutputs.w_subcool;
	Outputs->Evaporatorh_superheat=run->EvaporatorOutputs.h_superheat;
	Outputs->Evaporatorh_2phase=run->EvaporatorOutputs.h_2phase;
	Outputs->Evaporatorh_subcool=run->EvaporatorOutputs.h_subcool;
	Outputs->EvaporatorAirA_a=run->EvaporatorFinInputs.Fins.A_a;
	Outputs->EvaporatorAirdP_a=run->EvaporatorFinInputs.Fins.dP_a;
	Outputs->EvaporatorAireta_a=run->EvaporatorFinInputs.Fins.eta_a;
	Outputs->EvaporatorAirh_a=run->EvaporatorFinInputs.Fins.h_a;
	Outputs->EvaporatorAirmdot_a=run->EvaporatorFinInputs.Fins.mdot_a;
	Outputs->Evaporatorf_dry=run->EvaporatorOutputs.f_dry;
	Outputs->Evaporatorpin_r=run->EvaporatorInputs.pout_r; //TODO: fix me
	Outputs->Evaporatorpout_r=run->EvaporatorInputs.pout_r; 
	Outputs->Evaporatorhin_r=run->EvaporatorOutputs.hin_r;
	Outputs->Evaporatorxin_r=run->EvaporatorOutputs.xin_r;
	Outputs->Evaporatorhout_r=run->EvaporatorOutputs.hout_r;
	Outputs->EvaporatorTout_a=run->EvaporatorOutputs.Tout_a;
	Outputs->EvaporatorDP_r=run->EvaporatorOutputs.DP;
	Outputs->EvaporatorDP_r_2phase=run->EvaporatorOutputs.DP_2phase;
	Outputs->EvaporatorDP_r_superheat=run->EvaporatorOutputs.DP_superheat;
	Outputs->EvaporatorDP_r_subcool=run->EvaporatorOutputs.DP_subcool;



	Outputs->CompressorPower=run->CompressorOutputs.power;
	Outputs->CyclePower=run->CompressorOutputs.power+Outputs->PumpPower;

	Outputs->Evaporatorsin_r=run->EvaporatorOutputs.sin_r;
	Outputs->Evaporatorsout_r=run->EvaporatorOutputs.sout_r;
	Outputs->EvaporatorTin_r=run->EvaporatorOutputs.Tin_r;
	Outputs->EvaporatorTout_r=run->EvaporatorInputs.Tout_r;


	if (run->Cycle.CycleType==CYCLETYPE_SECONDARY)
	{
		Outputs->TsatEvap=run->IHXInputs.Tsat_r;
		DP=run->IHXOutputs.DP_g_2phase+run->IHXOutputs.DP_g_superheat+run->IndoorCoilOutputs.DP_g+run->LineSetReturnOutputs.DP+run->LineSetSupplyOutputs.DP;
		Outputs->PumpDP=DP;
		Outputs->PumpPower=fabs(run->IHXInputs.mdot_g/Props('D','T',run->IHXInputs.Tin_g,'P',200,run->Cycle.SecondaryRef)*DP/run->PumpInputs.Efficiency);
		Outputs->Pumpmdot=run->IHXInputs.mdot_g;
		Outputs->COP=(run->IndoorCoilOutputs.Q-run->IndoorCoilInputs.FanPower)/(run->CompressorOutputs.power+Outputs->PumpPower+run->IndoorCoilInputs.FanPower+run->CondenserInputs.FanPower);
		Outputs->IndoorCoilSHR=run->IndoorCoilOutputs.SHR;
		Outputs->CyclePower=(Outputs->CompressorPower+Outputs->PumpPower+run->CondenserInputs.FanPower+run->IndoorCoilInputs.FanPower);

		Outputs->EvaporatorCharge=0.0;
		Outputs->EvaporatorCharge_superheat=0.0;
		Outputs->EvaporatorCharge_2phase=0.0;
		Outputs->EvaporatorCharge_subcool=0.0;
		Outputs->EvaporatorQ=0.0;
		Outputs->EvaporatorQ_superheat=0.0;
		Outputs->EvaporatorQ_2phase=0.0;
		Outputs->EvaporatorQ_subcool=0.0;
		Outputs->EvaporatorQ=0.0;
		Outputs->EvaporatorQ_superheat=0.0;
		Outputs->EvaporatorQ_2phase=0.0;
		Outputs->EvaporatorQ_subcool=0.0;
		Outputs->Evaporatorw_superheat=0.0;
		Outputs->Evaporatorw_2phase=0.0;
		Outputs->Evaporatorw_subcool=0.0;
		Outputs->EvaporatorDP_r=0.0;
		Outputs->EvaporatorDP_r_superheat=0.0;
		Outputs->EvaporatorDP_r_2phase=0.0;
		Outputs->EvaporatorDP_r_subcool=0.0;
		Outputs->Evaporatorh_superheat=0.0;
		Outputs->Evaporatorh_2phase=0.0;
		Outputs->Evaporatorh_subcool=0.0;
		Outputs->EvaporatorTout_a=0.0;
		Outputs->EvaporatorAirA_a=0.0;
		Outputs->EvaporatorAirdP_a=0.0;
		Outputs->EvaporatorAirmdot_a=0.0;
		Outputs->EvaporatorAirh_a=0.0;
		Outputs->EvaporatorAireta_a=0.0;

		Outputs->CycleCapacity=Outputs->IndoorCoilQ;
		Outputs->CycleCOP=(Outputs->IndoorCoilQ) / (Outputs->CompressorPower+Outputs->PumpPower);
		Outputs->CycleCOPeff=(Outputs->IndoorCoilQ-run->IndoorCoilInputs.FanPower) / (Outputs->CompressorPower+Outputs->PumpPower+run->CondenserInputs.FanPower+run->IndoorCoilInputs.FanPower);
		Outputs->CycleSHR=Outputs->IndoorCoilSHR;
		Outputs->CycleCharge=run->CondenserOutputs.Charge+run->IHXOutputs.Charge;
	}
	else // DX system
	{
		Outputs->COP=(run->EvaporatorOutputs.Q-run->EvaporatorInputs.FanPower)/(run->CompressorOutputs.power);
		Outputs->TsatEvap=run->EvaporatorInputs.Tsat_r;
		Outputs->PumpDP=0.0;
		Outputs->PumpPower=0.0;
		Outputs->Pumpmdot=0.0;
		Outputs->EvaporatorSHR=run->EvaporatorOutputs.SHR;

		Outputs->IHXhin_r=0.0;
		Outputs->IHXhout_r=0.0;
		Outputs->IHXsin_r=0.0;
		Outputs->IHXsout_r=0.0;
		Outputs->IHXTin_r=0.0;
		Outputs->IHXTout_r=0.0;
		Outputs->IHXDP_g_superheat=0.0;
		Outputs->IHXDP_g_2phase=0.0;
		Outputs->IHXDP_g_subcool=0.0;
		Outputs->IHXDP_r_superheat=0.0;
		Outputs->IHXDP_r_2phase=0.0;
		Outputs->IHXDP_r_subcool=0.0;
		Outputs->IHXDP_r=0.0;

		Outputs->IHXQ=0.0;
		Outputs->IHXQ_superheat=0.0;
		Outputs->IHXQ_2phase=0.0;
		Outputs->IHXQ_subcool=0.0;
		Outputs->IHXh_r_superheat=0.0;
		Outputs->IHXh_r_2phase=0.0;
		Outputs->IHXh_r_subcool=0.0;
		Outputs->IHXh_g_superheat=0.0;
		Outputs->IHXh_g_2phase=0.0;
		Outputs->IHXh_g_subcool=0.0;
		Outputs->IHXRe_g_superheat=0.0;
		Outputs->IHXRe_g_2phase=0.0;
		Outputs->IHXRe_g_subcool=0.0;

		Outputs->IHXw_superheat=0.0;
		Outputs->IHXw_2phase=0.0;
		Outputs->IHXw_subcool=0.0;
		Outputs->IHXCharge_superheat=0.0;
		Outputs->IHXCharge_2phase=0.0;
		Outputs->IHXCharge_subcool=0.0;
		Outputs->IHXCharge=0.0;
		Outputs->IHXTin_g=0.0;
		Outputs->IHXTout_g=0.0;

		
		Outputs->IndoorCoilQ=0.0;
		Outputs->IndoorCoilSHR=0.0;
		Outputs->IndoorCoilh_g=0.0;
		Outputs->IndoorCoilRe_g=0.0;
		Outputs->IndoorCoilDP_g=0.0;
		Outputs->IndoorCoilTin_g=0.0;
		Outputs->IndoorCoilTout_g=0.0;
		Outputs->IndoorCoilAirdP_a=0.0;
		Outputs->IndoorCoilAireta_a=0.0;
		Outputs->IndoorCoilAirh_a=0.0;
		Outputs->IndoorCoilAirmdot_a=0.0;
		Outputs->IndoorCoilAirA_a=0.0;
		Outputs->IndoorCoilAirf_dry=0.0;

		Outputs->CycleCapacity=(Outputs->EvaporatorQ-run->EvaporatorInputs.FanPower);
		Outputs->CycleCOP=(Outputs->EvaporatorQ) / (Outputs->CompressorPower);
		Outputs->CycleCOPeff=(Outputs->EvaporatorQ-run->EvaporatorInputs.FanPower) / (Outputs->CompressorPower+run->CondenserInputs.FanPower+run->EvaporatorInputs.FanPower);
		Outputs->CycleSHR=Outputs->EvaporatorSHR;
		Outputs->CyclePower=(Outputs->CompressorPower+run->CondenserInputs.FanPower+run->EvaporatorInputs.FanPower);
		Outputs->CycleCharge=run->CondenserOutputs.Charge+run->EvaporatorOutputs.Charge+run->LineSetSupplyOutputs.Charge+run->LineSetReturnOutputs.Charge;
	}

	Outputs->LineSetSupplyTin=run->LineSetSupplyInputs.Tin;
	Outputs->LineSetSupplyTout=run->LineSetSupplyOutputs.Tout;
	Outputs->LineSetSupplyDP=run->LineSetSupplyOutputs.DP;
	Outputs->LineSetSupplyh=run->LineSetSupplyOutputs.h;
	Outputs->LineSetSupplyRe=run->LineSetSupplyOutputs.Re;
	Outputs->LineSetSupplyQ=run->LineSetSupplyOutputs.Q;
	Outputs->LineSetSupplyCharge=run->LineSetSupplyOutputs.Charge;

	Outputs->LineSetReturnTin=run->LineSetReturnInputs.Tin;
	Outputs->LineSetReturnTout=run->LineSetReturnOutputs.Tout;
	Outputs->LineSetReturnDP=run->LineSetReturnOutputs.DP;
	Outputs->LineSetReturnh=run->LineSetReturnOutputs.h;
	Outputs->LineSetReturnRe=run->LineSetReturnOutputs.Re;
	Outputs->LineSetReturnQ=run->LineSetReturnOutputs.Q;
	Outputs->LineSetReturnCharge=run->LineSetReturnOutputs.Charge;

	Outputs->Failed=runFail;
	Outputs->FailString=(char *)calloc(1001,sizeof(char));
	strcpy(Outputs->FailString,runFailString);
}

void PHPlot(char * Ref, struct runVals run)
{
	double Ps,Pd;
	FILE *fp;

	fp=fopen("../Ref.txt","w");
	fprintf(fp,"%s\n",Ref);
	fclose(fp);

	fp=fopen("../pts.txt","w");
	
	Pd=Props('P','T',run.CondenserInputs.Tsat_r,'Q',0,Ref);
	if (run.Cycle.CycleType==CYCLETYPE_SECONDARY)
	{
		Ps=Props('P','T',run.IHXInputs.Tsat_r,'Q',0,Ref);
		//IHX
		fprintf(fp,"%g,%g\n", run.IHXOutputs.hout_r,Ps);
		fprintf(fp,"%g,%g\n", run.IHXOutputs.hin_r,Ps);
	}
	else
	{
		Ps=Props('P','T',run.EvaporatorInputs.Tsat_r,'Q',0,Ref);
		//Evaporator
		fprintf(fp,"%g,%g\n", run.EvaporatorOutputs.hout_r,Ps);
		fprintf(fp,"%g,%g\n", run.EvaporatorOutputs.hin_r,Ps);
	}

	//Compressor
	fprintf(fp,"%g,%g\n", run.CompressorOutputs.h1,Ps);
	fprintf(fp,"%g,%g\n", run.CompressorOutputs.h2,Pd);
	//Condenser
	fprintf(fp,"%g,%g\n", run.CondenserOutputs.hin_r,Pd);
	fprintf(fp,"%g,%g\n", run.CondenserOutputs.hout_r,Pd);
	//TXV
	fprintf(fp,"%g,%g\n", run.CondenserOutputs.hout_r,Ps);
	fprintf(fp,"%g,%g\n", run.CondenserOutputs.hout_r,Pd);

	fclose(fp);

	system("cd /D D:\\My_Documents\\Code\\Emerson\\LumpedCycle\\LumpedCycle\\ && python BellPropTest_R290PH.py");
}
void MatInv_3(double A[3][3] , double B[3][3])
{
    double Det;
    //from http://www.dr-lex.be/random/matrix_inv.html

    // c is [col][row]

    Det = A[0][0] * (A[2][2] * A[1][1] - A[2][1] * A[1][2]) - A[1][0] * (A[2][2] * A[0][1] - A[2][1] * A[0][2]) + A[2][0] * (A[1][2] * A[0][1] - A[1][1] * A[0][2]);
    B[0][0] = (A[2][2] * A[1][1] - A[2][1] * A[1][2]) / Det;
    B[0][1] = -(A[2][2] * A[0][1] - A[2][1] * A[0][2]) / Det;
    B[0][2] = (A[1][2] * A[0][1] - A[1][1] * A[0][2]) / Det;
    B[1][0] = -(A[2][2] * A[1][0] - A[2][0] * A[1][2]) / Det;
    B[1][1] = (A[2][2] * A[0][0] - A[2][0] * A[0][2]) / Det;
    B[1][2] = -(A[1][2] * A[0][0] - A[1][0] * A[0][2]) / Det;
    B[2][0] = (A[2][1] * A[1][0] - A[2][0] * A[1][1]) / Det;
    B[2][1] = -(A[2][1] * A[0][0] - A[2][0] * A[0][1]) / Det;
    B[2][2] = (A[1][1] * A[0][0] - A[1][0] * A[0][1]) / Det;
}

void MatInv_2(double A[2][2] , double B[2][2])
{
	double Det;
	//Using Cramer's Rule to solve

	Det=A[0][0]*A[1][1]-A[1][0]*A[0][1];
	B[0][0]=1.0/Det*A[1][1];
	B[1][1]=1.0/Det*A[0][0];
	B[1][0]=-1.0/Det*A[1][0];
	B[0][1]=-1.0/Det*A[0][1];
}

int loadRunStruct(struct CycleInputVals *Inputs, struct runVals *run)
{
	double Tubes_per_circuit;

	//Sorted Alphabetically
	run->CondenserInputs.ID=Inputs->CondenserTubesID;
	Tubes_per_circuit=Inputs->CondenserTubesNtubes/Inputs->CondenserTubesNcircuit;
	run->CondenserInputs.Lcircuit=Inputs->CondenserTubesL*Tubes_per_circuit*Inputs->CondenserTubesNbank;
	run->CondenserInputs.Ncircuits=(int)(Inputs->CondenserTubesNcircuit);
	run->CondenserInputs.OD=Inputs->CondenserTubesOD;
	run->CondenserInputs.pin_a=Inputs->CondenserAirp;
	run->CondenserInputs.RHin_a=Inputs->CondenserAirRH;
	run->CondenserInputs.Tin_a=Inputs->CondenserAirTdb;
	run->CondenserInputs.Vdot_a=Inputs->CondenserAirVdot;
	run->CondenserInputs.FanPower=Inputs->CondenserFanPower;

	run->CondFinInputs.Air.p=Inputs->CondenserAirp;
	run->CondFinInputs.Air.RH=Inputs->CondenserAirRH;
	run->CondFinInputs.Air.Tdb=Inputs->CondenserAirTdb;
	run->CondFinInputs.Air.Vdot_ha=Inputs->CondenserAirVdot;

	run->CondFinInputs.Fins.FPI=Inputs->CondenserFinFPI;
	run->CondFinInputs.Fins.k_fin=Inputs->CondenserFink;
	run->CondFinInputs.Fins.Pd=Inputs->CondenserFinpd;
	run->CondFinInputs.Fins.t=Inputs->CondenserFint;
	run->CondFinInputs.Fins.xf=Inputs->CondenserFinxf;

	run->CondFinInputs.Tubes.D = Inputs->CondenserTubesOD;
    run->CondFinInputs.Tubes.Ltube = Inputs->CondenserTubesL;
    run->CondFinInputs.Tubes.Nbank = (int)(Inputs->CondenserTubesNbank);
	run->CondFinInputs.Tubes.Ntubes_bank = (int)Inputs->CondenserTubesNtubes;
	run->CondFinInputs.Tubes.Pl = Inputs->CondenserTubesPl;
    run->CondFinInputs.Tubes.Pt = Inputs->CondenserTubesPt;

	run->CompressorInputs.fp=Inputs->Compfp;
	run->CompressorInputs.Vdot_ratio=Inputs->CompVdot_ratio;
	


	run->CompressorInputs.M1=Inputs->CompM1;
	run->CompressorInputs.M2=Inputs->CompM2;
	run->CompressorInputs.M3=Inputs->CompM3;
	run->CompressorInputs.M4=Inputs->CompM4;
	run->CompressorInputs.M5=Inputs->CompM5;
	run->CompressorInputs.M6=Inputs->CompM6;
	run->CompressorInputs.M7=Inputs->CompM7;
	run->CompressorInputs.M8=Inputs->CompM8;
	run->CompressorInputs.M9=Inputs->CompM9;
	run->CompressorInputs.M10=Inputs->CompM10;

	run->CompressorInputs.P1=Inputs->CompP1;
	run->CompressorInputs.P2=Inputs->CompP2;
	run->CompressorInputs.P3=Inputs->CompP3;
	run->CompressorInputs.P4=Inputs->CompP4;
	run->CompressorInputs.P5=Inputs->CompP5;
	run->CompressorInputs.P6=Inputs->CompP6;
	run->CompressorInputs.P7=Inputs->CompP7;
	run->CompressorInputs.P8=Inputs->CompP8;
	run->CompressorInputs.P9=Inputs->CompP9;
	run->CompressorInputs.P10=Inputs->CompP10;

	if (!strcmp(Inputs->CycleType,"Secondary"))
	{

		run->IHXInputs.L = Inputs->IHXLength;
		run->IHXInputs.OD_o = Inputs->IHXAnnOD;
		run->IHXInputs.ID_o = Inputs->IHXAnnID;
		run->IHXInputs.OD_i = Inputs->IHXTubeID;
		run->IHXInputs.DT_sh = Inputs->IHXSuperheat;
		run->IHXInputs.N = Inputs->IHXN;

		run->IndoorCoilInputs.ID=Inputs->IndoorCoilTubesID;
		Tubes_per_circuit=Inputs->IndoorCoilTubesNtubes/Inputs->IndoorCoilTubesNcircuit;
		run->IndoorCoilInputs.Lcircuit=Inputs->IndoorCoilTubesL*Tubes_per_circuit*Inputs->IndoorCoilTubesNbank;
		run->IndoorCoilInputs.Ncircuits=(int)(Inputs->IndoorCoilTubesNcircuit);
		run->IndoorCoilInputs.OD=Inputs->IndoorCoilTubesOD;
		run->IndoorCoilInputs.pin_a=Inputs->IndoorCoilAirp;
		run->IndoorCoilInputs.RHin_a=Inputs->IndoorCoilAirRH;
		run->IndoorCoilInputs.Tin_a=Inputs->IndoorCoilAirTdb;
		run->IndoorCoilInputs.Vdot_a=Inputs->IndoorCoilAirVdot;
		run->IndoorCoilInputs.FanPower=Inputs->IndoorCoilFanPower;

		run->IndoorCoilFinInputs.Air.p=Inputs->IndoorCoilAirp;
		run->IndoorCoilFinInputs.Air.RH=Inputs->IndoorCoilAirRH;
		run->IndoorCoilFinInputs.Air.Tdb=Inputs->IndoorCoilAirTdb;
		run->IndoorCoilFinInputs.Air.Vdot_ha=Inputs->IndoorCoilAirVdot;

		run->IndoorCoilFinInputs.Fins.FPI=Inputs->IndoorCoilFinFPI;
		run->IndoorCoilFinInputs.Fins.k_fin=Inputs->IndoorCoilFink;
		run->IndoorCoilFinInputs.Fins.Pd=Inputs->IndoorCoilFinpd;
		run->IndoorCoilFinInputs.Fins.t=Inputs->IndoorCoilFint;
		run->IndoorCoilFinInputs.Fins.xf=Inputs->IndoorCoilFinxf;

		run->IndoorCoilFinInputs.Tubes.D=Inputs->IndoorCoilTubesOD;
		run->IndoorCoilFinInputs.Tubes.Ltube=Inputs->IndoorCoilTubesL;
		run->IndoorCoilFinInputs.Tubes.Nbank = (int)(Inputs->IndoorCoilTubesNbank);
		run->IndoorCoilFinInputs.Tubes.Ntubes_bank = (int)(Inputs->IndoorCoilTubesNtubes);
		run->IndoorCoilFinInputs.Tubes.Pl =Inputs->IndoorCoilTubesPl;
		run->IndoorCoilFinInputs.Tubes.Pt=Inputs->IndoorCoilTubesPt;

		run->PumpInputs.Vdot=Inputs->PumpVdot;
		run->PumpInputs.Efficiency=Inputs->PumpEff;
		run->PumpInputs.pout=Inputs->Pumppout;

		run->LineSetSupplyInputs.L=Inputs->LineSetL;
		run->LineSetSupplyInputs.OD=Inputs->LineSetOD_supply;
		run->LineSetSupplyInputs.ID=Inputs->LineSetID_supply;		
		run->LineSetSupplyInputs.k_tube =Inputs->LineSetTubek;
		run->LineSetSupplyInputs.t_insul =Inputs->LineSetInsult;
		run->LineSetSupplyInputs.k_insul =Inputs->LineSetInsulk;
		run->LineSetSupplyInputs.h_air =Inputs->LineSeth_air;
		run->LineSetSupplyInputs.T_air =Inputs->LineSetT_air;

		run->LineSetReturnInputs = run->LineSetSupplyInputs;
		run->LineSetReturnInputs.OD=Inputs->LineSetOD_return;
		run->LineSetReturnInputs.ID=Inputs->LineSetID_return;

	}
	else
	{
		run->EvaporatorInputs.ID=Inputs->EvaporatorTubesID;
		Tubes_per_circuit=Inputs->EvaporatorTubesNtubes/Inputs->EvaporatorTubesNcircuit;
		run->EvaporatorInputs.Lcircuit=Inputs->EvaporatorTubesL*Tubes_per_circuit*Inputs->EvaporatorTubesNbank;
		run->EvaporatorInputs.Ncircuits=(int)(Inputs->EvaporatorTubesNcircuit);
		run->EvaporatorInputs.OD=Inputs->EvaporatorTubesOD;
		run->EvaporatorInputs.pin_a=Inputs->EvaporatorAirp;
		run->EvaporatorInputs.RHin_a=Inputs->EvaporatorAirRH;
		run->EvaporatorInputs.Tin_a=Inputs->EvaporatorAirTdb;
		run->EvaporatorInputs.Vdot_a=Inputs->EvaporatorAirVdot;
		run->EvaporatorInputs.FanPower=Inputs->EvaporatorFanPower;

		run->EvaporatorFinInputs.Air.p=Inputs->EvaporatorAirp;
		run->EvaporatorFinInputs.Air.RH=Inputs->EvaporatorAirRH;
		run->EvaporatorFinInputs.Air.Tdb=Inputs->EvaporatorAirTdb;
		run->EvaporatorFinInputs.Air.Vdot_ha=Inputs->EvaporatorAirVdot;

		run->EvaporatorFinInputs.Fins.FPI=Inputs->EvaporatorFinFPI;
		run->EvaporatorFinInputs.Fins.k_fin=Inputs->EvaporatorFink;
		run->EvaporatorFinInputs.Fins.Pd=Inputs->EvaporatorFinpd;
		run->EvaporatorFinInputs.Fins.t=Inputs->EvaporatorFint;
		run->EvaporatorFinInputs.Fins.xf=Inputs->EvaporatorFinxf;

		run->EvaporatorFinInputs.Tubes.D=Inputs->EvaporatorTubesOD;
		run->EvaporatorFinInputs.Tubes.Ltube=Inputs->EvaporatorTubesL;
		run->EvaporatorFinInputs.Tubes.Nbank = (int)(Inputs->EvaporatorTubesNbank);
		run->EvaporatorFinInputs.Tubes.Ntubes_bank = (int)(Inputs->EvaporatorTubesNtubes);
		run->EvaporatorFinInputs.Tubes.Pl =Inputs->EvaporatorTubesPl;
		run->EvaporatorFinInputs.Tubes.Pt=Inputs->EvaporatorTubesPt;

		run->EvaporatorInputs.DT_sh=Inputs->EvaporatorDTsh;

		run->LineSetSupplyInputs.L=Inputs->LineSetL;
		run->LineSetSupplyInputs.OD=Inputs->LineSetOD_supply;
		run->LineSetSupplyInputs.ID=Inputs->LineSetID_supply;		
		run->LineSetSupplyInputs.k_tube =Inputs->LineSetTubek;
		run->LineSetSupplyInputs.t_insul =Inputs->LineSetInsult;
		run->LineSetSupplyInputs.k_insul =Inputs->LineSetInsulk;
		run->LineSetSupplyInputs.h_air =Inputs->LineSeth_air;
		run->LineSetSupplyInputs.T_air =Inputs->LineSetT_air;

		run->LineSetReturnInputs = run->LineSetSupplyInputs;
		run->LineSetReturnInputs.OD=Inputs->LineSetOD_return;
		run->LineSetReturnInputs.ID=Inputs->LineSetID_return;
	}

	strcpy(run->Cycle.PrimaryRef,Inputs->PrimaryRef);
	strcpy(run->Cycle.SecondaryRef,Inputs->SecondaryRef);
	strcpy(run->CondenserInputs.Mode,"Backward");  //TODO: update?
	strcpy(run->EvaporatorInputs.Mode,"Backward");  //TODO: update?
	run->Cycle.Qnominal=Inputs->CycleQnominal;

	if (!strcmp(Inputs->CycleType,"Secondary"))
	{
	//TODO: different inlet density?  Glycol quite incompressible, but temp sensitive
	run->IHXInputs.mdot_g=Props('D','T',run->IndoorCoilInputs.Tin_a-10.0,'P',Inputs->Pumppout,run->Cycle.SecondaryRef)*run->PumpInputs.Vdot;
	run->IHXInputs.pin_g=run->PumpInputs.pout;
	}

	run->Cycle.Charge=Inputs->CycleCharge;
	run->Cycle.DT_subcool=Inputs->DT_subcool;
	//Use one of the below values based on the imposed variable
	run->Cycle.ChargeImposed=Inputs->CycleCharge;
	run->Cycle.DTsubcoolImposed=Inputs->DT_subcool;
	
	strcpy(run->Cycle.ImposedVariable,Inputs->ImposedVariable);

	if (!strcmp(Inputs->CycleType,"Secondary"))
		run->Cycle.CycleType=CYCLETYPE_SECONDARY;
	else
		run->Cycle.CycleType=CYCLETYPE_DX;

	return 0;
}

int loadDefaults(struct runVals *run)
{
	run->CondFinInputs.Tubes.Ntubes_bank = 41;  //'Tubes per bank
	run->CondFinInputs.Tubes.Nbank = 1; //' Number of tube banks
    run->CondFinInputs.Tubes.Ltube = 2.286; //'[m]
    run->CondFinInputs.Tubes.D = 0.007; //'tube OD
    run->CondFinInputs.Tubes.Pl = 0.01905; //' Horizontal Spacing between banks (center to center)
    run->CondFinInputs.Tubes.Pt = 0.022225; //' vertical spacing between tubes in a bank (center to center)

    //''Fin parameters
    run->CondFinInputs.Fins.FPI = 25;					//[1/m]
    run->CondFinInputs.Fins.Pd = 0.001;					//[m]
    run->CondFinInputs.Fins.xf = 0.001;
    run->CondFinInputs.Fins.t = 0.00011;
    run->CondFinInputs.Fins.k_fin = 237;				//[W/m-K]

    //''Air inlet state
    run->CondFinInputs.Air.Vdot_ha = 1.7934;
    run->CondFinInputs.Air.Tdb = 308.15;				//'95 F to K
    run->CondFinInputs.Air.p = 101.325;
    run->CondFinInputs.Air.RH = 0.5;

	run->CondenserInputs.OD = 0.007;
    run->CondenserInputs.ID = 0.0063904;
    run->CondenserInputs.Ncircuits = 5;
    run->CondenserInputs.Lcircuit = 8.2 * 2.286;	//[m]
	run->CondenserInputs.FanPower=260;

    run->CondenserInputs.Vdot_a = run->CondFinInputs.Air.Vdot_ha;			//[m^3/s]
	run->CondenserInputs.Tin_a = run->CondFinInputs.Air.Tdb;			//[K]
    run->CondenserInputs.pin_a = run->CondFinInputs.Air.p ;			//[kPa]
    run->CondenserInputs.RHin_a = run->CondFinInputs.Air.RH ;				//fractional relative humidity [0 --> 1]

	////R134a coeffs
	//run->CompressorInputs.M1 = 7.845705988E+01;
	//run->CompressorInputs.M2 = 8.105620464E+00;
	//run->CompressorInputs.M3 = 3.590099771E+00;
	//run->CompressorInputs.M4 = -2.360000000E-02;
	//run->CompressorInputs.M5 = -3.130000000E-02;
	//run->CompressorInputs.M6 = -3.450000000E-02;
	//run->CompressorInputs.M7 = 4.580000000E-04;
	//run->CompressorInputs.M8 = 4.980000000E-04;
	//run->CompressorInputs.M9 = 3.230000000E-05;
	//run->CompressorInputs.M10 = 1.060000000E-04;
	//run->CompressorInputs.P1 = 5.634903564E+02;
	//run->CompressorInputs.P2 = -8.502641320E-01;
	//run->CompressorInputs.P3 = 1.587519932E+01;
	//run->CompressorInputs.P4 = 1.860758960E-01;
	//run->CompressorInputs.P5 = -3.718422000E-02;
	//run->CompressorInputs.P6 = -5.676081000E-02;
	//run->CompressorInputs.P7 = -4.967350000E-06;
	//run->CompressorInputs.P8 = -1.735431000E-03;
	//run->CompressorInputs.P9 = 5.947520000E-04;
	//run->CompressorInputs.P10 = 5.986630000E-04;

	run->CompressorInputs.fp=0.15;
	run->CompressorInputs.Vdot_ratio=1.0;

	run->IHXInputs.OD_o = 0.05;					//[m]
    run->IHXInputs.ID_o = 0.03415;					//[m]
    run->IHXInputs.OD_i = 0.0278;					//[m]
    run->IHXInputs.L = 50;							//[m]
	run->IHXInputs.DT_sh = 1/9.*5.;					//[K]
	run->IHXInputs.mdot_g = 0.3;					//[kg/s]
    run->IHXInputs.pin_g = 200;						//[kPa]
	run->IHXInputs.N = 1;							//[-]

	// Will be solved for eventually
    //run->IHXInputs.Tin_g = F2K(46) + 1.47; //'282.40   '[K] 
    //'inlet temp of indoor coil plus temp rise on indoor coil (neglecting pump for now (its small))

    //''Fin parameters
    run->IndoorCoilFinInputs.Fins.FPI = 14.5;					//[1/m]
    run->IndoorCoilFinInputs.Fins.Pd = 0.001;					//[m]
    run->IndoorCoilFinInputs.Fins.xf = 0.001;
    run->IndoorCoilFinInputs.Fins.t = 0.00011;
    run->IndoorCoilFinInputs.Fins.k_fin = 237;				//[W/m-K]

    //''Air inlet state
    run->IndoorCoilFinInputs.Air.Vdot_ha = 0.56319;
    run->IndoorCoilFinInputs.Air.Tdb = 295;//297.039;				//'75 F to K
    run->IndoorCoilFinInputs.Air.p = 101.325;
    run->IndoorCoilFinInputs.Air.RH = 0.4;

	run->IndoorCoilInputs.OD = 0.009525;
    run->IndoorCoilInputs.ID = 0.0089154;
    run->IndoorCoilInputs.Ncircuits = 4;
    run->IndoorCoilInputs.Lcircuit = 32/4.0*5.* 0.452;	//[m]
	run->IndoorCoilInputs.FanPower=438;

    run->IndoorCoilInputs.Vdot_a = run->IndoorCoilFinInputs.Air.Vdot_ha;			//[m^3/s]
	run->IndoorCoilInputs.Tin_a = run->IndoorCoilFinInputs.Air.Tdb;			//[K]
    run->IndoorCoilInputs.pin_a = run->IndoorCoilFinInputs.Air.p ;			//[kPa]
    run->IndoorCoilInputs.RHin_a = run->IndoorCoilFinInputs.Air.RH;				//fractional relative humidity [0 --> 1]

	run->IndoorCoilFinInputs.Tubes.Ntubes_bank = 32;  //'Tubes per bank
	run->IndoorCoilFinInputs.Tubes.Nbank = 5; //' Number of tube banks
    run->IndoorCoilFinInputs.Tubes.Ltube = 0.452; //'[m]
    run->IndoorCoilFinInputs.Tubes.D = 0.009525; //'tube OD
    run->IndoorCoilFinInputs.Tubes.Pl = 0.0219964; //' Horizontal Spacing between banks (center to center)
    run->IndoorCoilFinInputs.Tubes.Pt = 0.0254; //' vertical spacing between tubes in a bank (center to center)

    //''Fin parameters
    run->EvaporatorFinInputs.Fins.FPI = 14.5;			//[1/m]
    run->EvaporatorFinInputs.Fins.Pd = 0.001;			//[m]
    run->EvaporatorFinInputs.Fins.xf = 0.001;
    run->EvaporatorFinInputs.Fins.t = 0.00011;
    run->EvaporatorFinInputs.Fins.k_fin = 237;			//[W/m-K]

    //''Air inlet state
    run->EvaporatorFinInputs.Air.Vdot_ha = 0.5663;
    run->EvaporatorFinInputs.Air.Tdb = 299;			//'75 F to K
    run->EvaporatorFinInputs.Air.p = 101.325;
    run->EvaporatorFinInputs.Air.RH = 0.5;

	run->EvaporatorInputs.OD = 0.009525;
    run->EvaporatorInputs.ID = 0.0089154;
    run->EvaporatorInputs.Ncircuits = 6;
    run->EvaporatorInputs.Lcircuit = 32./6.*3.* 0.452;		//[m]
	run->EvaporatorInputs.FanPower=438;

    run->EvaporatorInputs.Vdot_a = run->EvaporatorFinInputs.Air.Vdot_ha;				//[m^3/s]
	run->EvaporatorInputs.Tin_a =  run->EvaporatorFinInputs.Air.Tdb;				//[K]
    run->EvaporatorInputs.pin_a = run->EvaporatorFinInputs.Air.p ;				//[kPa]
    run->EvaporatorInputs.RHin_a = run->EvaporatorFinInputs.Air.RH ;				//fractional relative humidity [0 --> 1]
	run->EvaporatorInputs.DT_sh=7/9.0*5.0;	// Outlet superheat

	run->EvaporatorFinInputs.Tubes.Ntubes_bank = 32;	//'Tubes per bank
	run->EvaporatorFinInputs.Tubes.Nbank = 3;			//' Number of tube banks
    run->EvaporatorFinInputs.Tubes.Ltube = 0.452;		//'[m]
    run->EvaporatorFinInputs.Tubes.D = 0.009525;		//'tube OD
    run->EvaporatorFinInputs.Tubes.Pl = 0.0219964;		//' Horizontal Spacing between banks (center to center)
    run->EvaporatorFinInputs.Tubes.Pt = 0.0254;			//' vertical spacing between tubes in a bank (center to center)


	run->LineSetSupplyInputs.L=5;
	run->LineSetSupplyInputs.OD=0.009525;
	run->LineSetSupplyInputs.ID=0.007986;
	run->LineSetSupplyInputs.k_tube=400;
	run->LineSetSupplyInputs.k_insul=0.036;
	run->LineSetSupplyInputs.t_insul=0.02;
	run->LineSetSupplyInputs.h_air=6.;
	run->LineSetSupplyInputs.T_air=297.;

	//run->LineSetSupplyInputs.L=5;
	//run->LineSetSupplyInputs.OD=0.04826;
	//run->LineSetSupplyInputs.ID=0.04089;
	//run->LineSetSupplyInputs.k_tube=0.19;
	//run->LineSetSupplyInputs.k_insul=0.036;
	//run->LineSetSupplyInputs.t_insul=0.02;
	//run->LineSetSupplyInputs.h_air=6.;
	//run->LineSetSupplyInputs.T_air=297.;

	run->LineSetReturnInputs=run->LineSetSupplyInputs;

	run->PumpInputs.Efficiency = 0.5;					//[-]
	run->PumpInputs.pout = 200;							//[kPa]
	run->PumpInputs.Vdot = 0.0003;						//[m^3/s]

	//strcpy(run->Cycle.PrimaryRef,"R290");
	strcpy(run->Cycle.PrimaryRef,"R410A");

	if (!strcmp(run->Cycle.PrimaryRef,"R290"))
	{
		run->Cycle.CycleType=CYCLETYPE_SECONDARY;
		// R290 Coefficients
		run->CompressorInputs.P1 = 280.6815683;
		run->CompressorInputs.P2 = -81.89665598;
		run->CompressorInputs.P3 = 44.78234097;
		run->CompressorInputs.P4 = 2.076283422;
		run->CompressorInputs.P5 = 0.206102738;
		run->CompressorInputs.P6 = -0.36128051;
		run->CompressorInputs.P7 = -0.015962071;
		run->CompressorInputs.P8 = -0.002293473;
		run->CompressorInputs.P9 = -0.000758934;
		run->CompressorInputs.P10 = 0.001701369;
		run->CompressorInputs.M1 = 30.25660922;
		run->CompressorInputs.M2 = -0.568382876;
		run->CompressorInputs.M3 = 2.831710808;
		run->CompressorInputs.M4 = 0.103625357;
		run->CompressorInputs.M5 = 0.015111817;
		run->CompressorInputs.M6 = -0.022000643;
		run->CompressorInputs.M7 = -0.000851757;
		run->CompressorInputs.M8 = 1.79561E-05;
		run->CompressorInputs.M9 = -6.2467E-05;
		run->CompressorInputs.M10 = 4.07877E-05;
	}
	else
	{
		run->Cycle.CycleType=CYCLETYPE_DX;
		////R410A Coefficients
		run->CompressorInputs.M1 = 217.3163127955650000000;
		run->CompressorInputs.M2 = 5.0944920280714000000;
		run->CompressorInputs.M3 = -0.5931703107259660000;
		run->CompressorInputs.M4 = 0.0438472185695222000;
		run->CompressorInputs.M5 = -0.0213612480651532000;
		run->CompressorInputs.M6 = 0.0103550295384247000;
		run->CompressorInputs.M7 = 0.0000790074273817491;
		run->CompressorInputs.M8 = -0.0000572935058370481;
		run->CompressorInputs.M9 = 0.0001787844556867980;
		run->CompressorInputs.M10 = -0.0000807570278359242;

		run->CompressorInputs.P1 = -561.361570450869000000;
		run->CompressorInputs.P2 = -15.626018405985900000;
		run->CompressorInputs.P3 = 46.925066850075200000;
		run->CompressorInputs.P4 = -0.217949551935511000;
		run->CompressorInputs.P5 = 0.435062615855337000;
		run->CompressorInputs.P6 = -0.442400826395089000;
		run->CompressorInputs.P7 = 0.000224569383648887;
		run->CompressorInputs.P8 = 0.002373368116047150;
		run->CompressorInputs.P9 = -0.003323436626948550;
		run->CompressorInputs.P10 = 0.002499919018080690;
	}

	//strcpy(run->Cycle.PrimaryRef,"REFPROP-R290");

	strcpy(run->Cycle.SecondaryRef,"NH3/H2O-10%");
	//strcpy(run->Cycle.SecondaryRef,"Water");
	//strcpy(run->Cycle.SecondaryRef,"EG-20%");
	strcpy(run->Cycle.ImposedVariable,"Subcooling");
	//strcpy(run->Cycle.ImposedVariable,"Charge");
	run->Cycle.DT_subcool=7.0;//12/9.0*5.0;

	run->Cycle.Charge=3.1;
	run->Cycle.ChargeImposed=3.1;
	run->Cycle.Qnominal=10500;

	/*strcpy(run->Cycle.PrimaryRef,"REFPROP-R290");
	PrintSaturationTable("R32SatTable.csv", run->Cycle.PrimaryRef, 250 , 320);
	strcpy(run->Cycle.PrimaryRef,"R410A");*/

	return 0;
}

void TestEvaporator(struct runVals *run)
{
	run->EvaporatorInputs.mdot_r=0.0666;
	run->EvaporatorInputs.Tsat_r=280.18;
	run->EvaporatorInputs.Tout_r=290.0738;
	run->EvaporatorInputs.pout_r=Props('P','T',run->EvaporatorInputs.Tsat_r,'Q',1.0,"R410A");
	
	run->EvaporatorFinInputs.Air.RHmean=0.8;
	run->EvaporatorFinInputs.Air.Tmean=290;
	run->EvaporatorInputs.RHin_a=0.5;
	run->EvaporatorFinInputs.Air.RH=0.5;
	Evaporator_Calculate("R410A",&(run->EvaporatorFinInputs),&(run->EvaporatorInputs),&(run->EvaporatorOutputs));
}

void TestCondenser()
{
	FILE *fp;
	double Tm,pinch,DT_subcool;
	struct runVals *run,runP;
	run=&runP;

	fp=fopen("Cond.csv","w");

	run->CondFinInputs.Tubes.Ntubes_bank = 41;  //'Tubes per bank
	run->CondFinInputs.Tubes.Nbank = 1; //' Number of tube banks
    run->CondFinInputs.Tubes.Ltube = 2.286; //'[m]
    run->CondFinInputs.Tubes.D = 0.007; //'tube OD
    run->CondFinInputs.Tubes.Pl = 0.01905; //' Horizontal Spacing between banks (center to center)
    run->CondFinInputs.Tubes.Pt = 0.022225; //' vertical spacing between tubes in a bank (center to center)
    run->CondFinInputs.Fins.FPI = 25;					//[1/m]
    run->CondFinInputs.Fins.Pd = 0.001;					//[m]
    run->CondFinInputs.Fins.xf = 0.001;
    run->CondFinInputs.Fins.t = 0.00011;
    run->CondFinInputs.Fins.k_fin = 237;				//[W/m-K]
    run->CondFinInputs.Air.Vdot_ha = 1.7934;
    run->CondFinInputs.Air.Tdb = 308.15;				//'95 F to K
    run->CondFinInputs.Air.p = 101.325;
    run->CondFinInputs.Air.RH = 0.5;
	run->CondFinInputs.Air.RHmean=0.41;
	run->CondFinInputs.Air.Tmean=311.15;
	run->CondenserInputs.OD = 0.007;
    run->CondenserInputs.ID = 0.0063904;
    run->CondenserInputs.Ncircuits = 5;
    run->CondenserInputs.Lcircuit = 8.2 * 2.286;	//[m]
    run->CondenserInputs.Vdot_a = 1.7934;			//[m^3/s]
	run->CondenserInputs.Tin_a = 308.15;			//[K]
    run->CondenserInputs.pin_a = 101.325 ;			//[kPa]
    run->CondenserInputs.RHin_a = 0.5 ;				//fractional relative humidity [0 --> 1]

	/*run->CondenserInputs.mdot_r=0.0666;
	run->CondenserInputs.pout_r=3352.9;
	run->CondenserInputs.Tout_r=308.238;
	run->CondenserInputs.Tsat_r=327.02;
	Condenser_Calculate("R410A",&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs));
	Tm=(run->CondenserInputs.Tout_r+run->CondenserInputs.Tsat_r)/2.0;*/
	for (pinch=0.001;pinch<0.3;pinch+=0.01)
	{
	DT_subcool=15.0;
	run->CondenserInputs.mdot_r=0.0666;
	run->CondenserInputs.Tsat_r=308.15+pinch+DT_subcool;

	run->CondenserInputs.pout_r=Props('P','T',run->CondenserInputs.Tsat_r,'Q',0,"R410A");
	run->CondenserInputs.Tout_r=308.15+pinch;

	Condenser_Calculate("R410A",&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs));

	fprintf(fp,"%g,%g,%g,%g,%g,%g\n",pinch,run->CondenserOutputs.hin_r,run->CondenserOutputs.w_subcool,run->CondenserOutputs.w_2phase,run->CondenserOutputs.w_superheat,run->CondenserOutputs.xin_r);
	Tm=(run->CondenserInputs.Tout_r+run->CondenserInputs.Tsat_r)/2.0;
	}

	fclose(fp);
	/*printf("rho: %g\n",Props('D','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));
	printf("rho_s: %g\n",Props('D','T',Tm,'Q',0.0,"R410A"));
	printf("cp: %g\n",Props('C','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));
	printf("cv: %g\n",Props('O','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));
	printf("h: %g\n",Props('H','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));
	printf("k: %g\n",Props('L','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));
	printf("mu: %g\n",Props('V','T',Tm,'P',run->CondenserInputs.pout_r,"R410A"));*/
	

	/*
	Total Heat Load	14214.98357	W
	Sensible Heat Load	14214.98357	W
	Latent Heat Load	0	W
	Sensible Heat Ratio	1	
			
	Charge/Condensate		
	Refrigerant Charge	2.107594	kg
	Condensate	0	kg/s
			
	Flow Rates		
	Total Refrigerant Flow Rate	0.06659	kg/s
	Air Flow Rate	1.7934	m�/s
	Standard Air Flow Rate	1.67262	m�/s
			
	Pressure Drops		
	Air Side Pressure Drop	0.237714	Pa
	Refrigerant Side Pressure Drop	26822.18046	Pa
			
	Temperatures		
	Average Air Outlet Temperature	315.130254	K
	Average Air Outlet Wetbulb Temperature	300.939544	K
	Average Air Outlet RH	34.31826753	%
	Average Refrigerant Outlet Temperature	308.239337	K
	Average Refrigerant Saturation Delta	-18.78198	K
			
	Heat Transfer		
	Primary Heat Transfer Area	1.837987	m�
	Secondary Heat Transfer Area	103.370565	m�
	Total Heat Transfer Area	105.208553	m�
	Coil Face Area	2.08306	m�
	Average Fin Effectiveness	0.87645	
	Average Air Side HTC	42.038562	W/m� K
	Average Refrigerant Side HTC	2529.043906	W/m� K
	Average Refrigerant Liquid HTC	1519.475465	W/m� K
	Average Refrigerant Two-phase HTC	5043.876538	W/m� K
	Average Refrigerant Vapor HTC	1294.348764	W/m� K
			
	Refrigerant Phase Distribution		
	Liquid - % Coil Length	60.976	
	Two Phase - % Coil Length	29.268	
	Vapor - % Coil Length	9.756	

	*/

	
	//run->CondenserInputs.mdot_r=0.040609;
	//run->CondenserInputs.pout_r=1885.0;
	//run->CondenserInputs.Tout_r=308.2613;
	//run->CondenserInputs.Tsat_r=333.261;
	//Condenser_Calculate("R290",&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs));
	//Tm=(run->CondenserInputs.Tout_r+run->CondenserInputs.Tsat_r)/2.0;
	//printf("rho: %g\n",Props('D','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));
	//printf("rho_s: %g\n",Props('D','T',Tm,'Q',0.0,"R290"));
	//printf("cp: %g\n",Props('C','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));
	//printf("cv: %g\n",Props('O','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));
	//printf("h: %g\n",Props('H','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));
	//printf("k: %g\n",Props('L','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));
	//printf("mu: %g\n",Props('V','T',Tm,'P',run->CondenserInputs.pout_r,"R290"));

	/*
	*** Coil Designer output ***
	Total Heat Load	14050.74129	W
	Sensible Heat Load	14050.74129	W
	Latent Heat Load	0	W
	Sensible Heat Ratio	1	
			
	Charge/Condensate		
	Refrigerant Charge	0.93479	kg
	Condensate	0	kg/s
			
	Flow Rates		
	Total Refrigerant Flow Rate	0.040609	kg/s
	Air Flow Rate	1.7934	m�/s
	Standard Air Flow Rate	1.67262	m�/s
			
	Pressure Drops		
	Air Side Pressure Drop	0.239362	Pa
	Refrigerant Side Pressure Drop	34952.10011	Pa
			
	Temperatures		
	Average Air Outlet Temperature	315.049603	K
	Average Air Outlet Wetbulb Temperature	300.921098	K
	Average Air Outlet RH	34.46408356	%
	Average Refrigerant Outlet Temperature	308.26129	K
	Average Refrigerant Saturation Delta	-18.456558	K
			
	Heat Transfer		
	Primary Heat Transfer Area	1.829264	m�
	Secondary Heat Transfer Area	103.370565	m�
	Total Heat Transfer Area	105.199829	m�
	Coil Face Area	2.08306	m�
	Average Fin Effectiveness	0.88045	
	Average Air Side HTC	42.024461	W/m� K
	Average Refrigerant Side HTC	2634.796253	W/m� K
	Average Refrigerant Liquid HTC	1350.071259	W/m� K
	Average Refrigerant Two-phase HTC	4646.208707	W/m� K
	Average Refrigerant Vapor HTC	1285.596875	W/m� K
			
	Refrigerant Phase Distribution		
	Liquid - % Coil Length	58.537	
	Two Phase - % Coil Length	39.024	
	Vapor - % Coil Length	2.439	

	*/


	/*run->CondenserInputs.mdot_r=0.07;
	run->CondenserInputs.pout_r=1216.61892;
	run->CondenserInputs.Tout_r=311.625;
	run->CondenserInputs.Tsat_r=320;
	Condenser_Calculate("R134a",&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs));
	*/

	printf("done - key to exit");
	getchar();
	exit(EXIT_SUCCESS);
}
void TestIndoorCoil()
{
	struct runVals *run, runVal;
	

	//Tested against experimental data of Zhao
	int i;
	double Tai[]={26.8,26.72,26.75,26.71,26.92,26.91,26.01,27.4,26.83,26.66}; //[C]
	double RHi[]={0.29,0.24,0.24,0.22,0.22,0.76,0.72,0.81,0.61,0.63};
	double Vdoti[]={0.3855,0.5653,0.744,0.9347,1.125,0.3965,0.5704,0.7639,0.9334,1.137};
	double Twi[]={3.55,4.11,4.38,3.57,3.6,3.38,3.45,4.53,3.93,4.29};
	double mdot_w[]={0.47,0.467,0.5,0.481,0.5,0.45,0.458,0.473,0.5,0.481};
	double Tao[]={6.27,8.59,9.08,10.40,11.78,9.25,11.72,16.33,14.41,15.92};
	double RHo[]={0.88,0.72,0.73,0.59,0.57,0.94,0.92,0.95,0.96,0.95};



	run=&runVal;

	run->IndoorCoilFinInputs.Tubes.Ntubes_bank = 16;  //'Tubes per bank
	run->IndoorCoilFinInputs.Tubes.Nbank = 8; //' Number of tube banks
    run->IndoorCoilFinInputs.Tubes.Ltube = 0.6096; //'[m]
    run->IndoorCoilFinInputs.Tubes.D = 0.0127; //'tube OD
    run->IndoorCoilFinInputs.Tubes.Pl = 0.033; //' Horizontal Spacing between banks (center to center)
    run->IndoorCoilFinInputs.Tubes.Pt = 0.0381; //' vertical spacing between tubes in a bank (center to center)

    //''Fin parameters
    run->IndoorCoilFinInputs.Fins.FPI = 8;					//[1/m]
    run->IndoorCoilFinInputs.Fins.Pd = 0.001;					//[m]
    run->IndoorCoilFinInputs.Fins.xf = 0.001;
    run->IndoorCoilFinInputs.Fins.t = 0.0002;
    run->IndoorCoilFinInputs.Fins.k_fin = 237;				//[W/m-K]

	run->IndoorCoilInputs.OD = 0.0127;
    run->IndoorCoilInputs.ID = 0.0119;
    run->IndoorCoilInputs.Ncircuits = 8;
    run->IndoorCoilInputs.Lcircuit = 8.0*0.6096;	//[m]

	
	for (i=0;i<10;i++)
	{
		run->IndoorCoilInputs.mdot_g=mdot_w[i];
		run->IndoorCoilInputs.Tin_a=Tai[i]+273.15;
		run->IndoorCoilInputs.RHin_a=RHi[i];
		run->IndoorCoilInputs.Vdot_a=Vdoti[i];
		run->IndoorCoilInputs.Tin_g=Twi[i]+273.15;	
		run->IndoorCoilInputs.pin_a = 101.325 ;			//[kPa]
		

		//''Air inlet state
		run->IndoorCoilFinInputs.Air.Vdot_ha = Vdoti[i];
		run->IndoorCoilFinInputs.Air.Tmean = (Tai[i]+Tao[i])/2.0+273.15;				//'95 F to K
		run->IndoorCoilFinInputs.Air.Tdb = Tai[i]+273.15;				//'95 F to K
		run->IndoorCoilFinInputs.Air.p = 101.325;
		run->IndoorCoilFinInputs.Air.RHmean = (RHi[i]+RHo[i])/2.0;
		run->IndoorCoilFinInputs.Air.RH = RHi[i];

		IndoorCoil_Calculate("Water", &(run->IndoorCoilFinInputs), &(run->IndoorCoilInputs), &(run->IndoorCoilOutputs));

		printf("%g\t%g\t%g\n",run->IndoorCoilOutputs.Q,run->IndoorCoilOutputs.f_dry,run->IndoorCoilOutputs.SHR); 
	}

	getchar();


}
/*printf("A=[");
				for (i=0;i<=2;i++)
				{
					if (i>0) printf(",");
					printf("[%g,%g,%g]",J[0][i],J[1][i],J[2][i]);
				}
				printf("]");*/

				
				//migs(J,3,invJ,indices);
				/*
				printf("invJ=[");
				for (i=0;i<=2;i++)
				{
					if (i>0) printf(",");
					printf("[%g,%g,%g]",invJ[0][i],invJ[1][i],invJ[2][i]);
				}
				printf("]");

				printf("\n\n");*/

void LoadValues(int runType, struct CycleInputVals *Inputs, struct runVals *run)
{
	extern int runFail;
	extern char runFailString[1000];
	// Load values from the structs into the a base run struct

	// Depending on how the values are coming in, either load defaults or
	// what is passed in from Python

	if (runType==0) //Values passed from Python
	{
		loadRunStruct(Inputs, &run[0]);
		/*outputCondenserInputs(&run[0]);
		outputIndoorCoilInputs(&run[0]);
		outputIHXInputs(&run[0]);
		outputCycleInputs(&run[0]);*/
	}
	else if (runType==1) //Values pulled from default values
	{
		loadDefaults(&run[0]);
		/*outputCondenserInputs(&run[0]);
		outputIndoorCoilInputs(&run[0]);
		outputIHXInputs(&run[0]);
		outputCycleInputs(&run[0]);*/
	}
	runFail=0;
	strcpy(runFailString," ");
	
}

int SecondarySolver_ChargeImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs)
{
	double Ts_cond, DT_subcool, Ts_IHX,omega,Cond_pinch,IHX_pinch;
	double x[3],xp[3],dx[3],r3[4][3],J3[3][3],invJ3[3][3],v[3],w_corrector;
	struct runVals run[4];
	int i;
	double x1=0,x2=0,x3=0,y1=0,y2=0,eps=0.01,f=999;
	int iterInner=1;

	LoadValues(runType,Inputs,&(run[0]));	


	/* 
	   First run glycol loop to find the glycol inlet temp 
	   which satisfies the glycol loop energy balance since we have 
	   imposed temps for IHX through problem formulation and IHX 
	   pinch temp guess
	*/
	IHX_pinch=0.2;
	Cond_pinch=2.5;

	////Copy the values from the base to the other run structs
	run[1]=run[0];
	run[2]=run[0];
	run[3]=run[0];

	////Copy of inputs
	//	runInit=run[0];

	////Inputs & Guesses
	//	DT_subcool=5.0;
	//	Ts_cond=run[0].CondenserInputs.Tin_a+DT_subcool+Cond_pinch;	
	//	DT_sh=run[0].IHXInputs.DT_sh;

	////Main loop to solve for glycol inlet temp
	//x1=runInit.IndoorCoilInputs.Tin_a-5;
	//x2=runInit.IndoorCoilInputs.Tin_a-20;
	//while ((iterInitGlycol<=3 || fabs(f)>eps) && iterInner<100)
	//{
	//	if (iterInitGlycol==1){runInit.IHXInputs.Tin_g=x1; }
	//	if (iterInitGlycol==2){runInit.IHXInputs.Tin_g=x2; }
	//	if (iterInitGlycol>2) {runInit.IHXInputs.Tin_g=x2;}

	//		Ts_IHX=runInit.IHXInputs.Tin_g-runInit.IHXInputs.DT_sh-IHX_pinch;

	//		Compressor_Calculate("R290",Ts_IHX,Ts_cond,DT_sh,1.0,&(runInit.CompOutputs));

	//		//Internal heat exchanger
	//		runInit.IHXInputs.mdot_r = runInit.CompOutputs.mdot;							//[kg/s]
	//		runInit.IHXInputs.Tout_r = Ts_IHX+DT_sh;									//[K]
	//		runInit.IHXInputs.Tsat_r = Ts_IHX;											//[K]
	//		runInit.IHXInputs.pout_r = Props('P','T',Ts_IHX,'Q',1,"R290");				//[kPa]
	//		IHX_Calculate("R290",&(runInit.IHXInputs),&(runInit.IHXOutputs));

	//		//Indoor Glycol Coil
	//		runInit.IndoorCoilInputs.mdot_g=runInit.IHXInputs.mdot_g;
	//		runInit.IndoorCoilInputs.Tin_g=runInit.IHXOutputs.Tout_g;
	//		runInit.IndoorCoilInputs.pin_g=runInit.IHXInputs.pin_g; //TODO: fix this
	//		IndoorCoil_Calculate("Water", &(runInit.IndoorCoilFinInputs), &(runInit.IndoorCoilInputs), &(runInit.IndoorCoilOutputs));

	//		f=runInit.IndoorCoilOutputs.Q-runInit.IHXOutputs.Q;
	//		printf("%g,%g\n",runInit.IHXInputs.Tin_g,f);

	//	if (iterInitGlycol==1){y1=f;}
	//	if (iterInitGlycol>1)
	//	{
	//		y2=f;
	//		x3=x2-y2/(y2-y1)*(x2-x1);
	//		y1=y2; x1=x2; x2=x3;
	//	}
	//	iterInitGlycol++;
	//}

	//
	///* 
	//   Next, using the glycol temp calculated above, find the 
	//   amount of subcooling which will satisfy the imposed charge 
	//   level.
	//*/

	////Main loop to solve for initial subcooling guess
	//x1=1;
	//x2=30;
	//while ((iterInitSubcool<=3 || fabs(f)>eps) && iterInitSubcool<100)
	//{
	//	if (iterInitSubcool==1){DT_subcool=x1; }
	//	if (iterInitSubcool==2){DT_subcool=x2; }
	//	if (iterInitSubcool>2) {DT_subcool=x2;}

	//	DT_sh=runInit.IHXInputs.DT_sh;
	//	Ts_cond=runInit.CondenserInputs.Tin_a+DT_subcool+Cond_pinch;
	//	Ts_IHX=runInit.IHXInputs.Tin_g-runInit.IHXInputs.DT_sh-IHX_pinch;
	//				
	//	x[0]=Ts_cond;
	//	x[1]=DT_subcool;
	//	x[2]=Ts_IHX;
	//	Cycle_Calculate(&runInit,x[0],x[1],x[2],r[0]);
	//	printf("%g,%g\n",DT_subcool,runInit.IHXOutputs.Charge+runInit.CondenserOutputs.Charge-runInit.Cycle.Charge);
	//	f=runInit.IHXOutputs.Charge+runInit.CondenserOutputs.Charge-runInit.Cycle.Charge;

	//	if (iterInitSubcool==1){y1=f;}
	//	if (iterInitSubcool>1)
	//	{
	//		y2=f;
	//		x3=x2-y2/(y2-y1)*(x2-x1);
	//		y1=y2; x1=x2; x2=x3;
	//	}
	//	iterInitSubcool++;
	//}

	//////Copy the values from the base to the other run structs
	//	run[0]=runInit;
	//	run[1]=runInit;
	//	run[2]=runInit;
	//	run[3]=runInit;


	dx[0]=0.5;
	/* go the opposite direction to build derivative for subcooling and IHX saturation temp
	to avoid making the outlet temp out of range when building derivative
	*/
	dx[1]=-0.5; 
	dx[2]=-0.5; 
	r3[0][0]=999; r3[0][1]=999; r3[0][2]=999;

	x1=285;
	x2=290;
	DT_subcool=5;
	while ((iterInner<=3 || fabs(f)>eps) && iterInner<100)
	{	
		
		if (iterInner==1){run[0].IHXInputs.Tin_g=x1; }
		if (iterInner==2){run[0].IHXInputs.Tin_g=x2; }
		if (iterInner>2) {run[0].IHXInputs.Tin_g=x2;}

			run[1].IHXInputs.Tin_g=run[0].IHXInputs.Tin_g;
			run[2].IHXInputs.Tin_g=run[0].IHXInputs.Tin_g;
			run[3].IHXInputs.Tin_g=run[0].IHXInputs.Tin_g;

			Ts_IHX=run[0].IHXInputs.Tin_g-run[0].IHXInputs.DT_sh-0.2;
			
			// Initialize the loop with the refrigerant cycle
			if (iterInner==1)
			{	
				Ts_cond=run[0].CondenserInputs.Tin_a+DT_subcool+2.5;
				
				x[0]=Ts_cond;
				x[1]=DT_subcool;
				x[2]=Ts_IHX;
			}
			else
			{
				x[2]=Ts_IHX;
			}

			r3[0][0]=99999; //Make it go back into the inner loop
			while ( fabs(r3[0][0])>1000 || fabs(r3[0][1])>1000 || fabs(r3[0][2])>0.06 )
			{
				/*
				Run the model 4 times to get the values needed to build Jacobian matrix
				with numerical partial derivatives 
				*/
				
				Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[0],x[0]      ,x[1]      ,x[2]			,r3[0]);
				Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[1],x[0]+dx[0],x[1]      ,x[2]			,r3[1]);
				Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[2],x[0]      ,x[1]+dx[1],x[2]			,r3[2]);
				Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[3],x[0]      ,x[1]      ,x[2]+dx[2]	,r3[3]);
				

				// Build the Jacobian matrix by the column
				for (i=0;i<=2;i++)
				{
				    //[c][r]      [ c ][r]
					J3[i][0] = (r3[i+1][0]-r3[0][0])/dx[i];
					J3[i][1] = (r3[i+1][1]-r3[0][1])/dx[i];
					J3[i][2] = (r3[i+1][2]-r3[0][2])/dx[i];
				}
				
				MatInv_3(J3,invJ3);
				
				v[0] = -(invJ3[0][0]*r3[0][0] + invJ3[1][0]*r3[0][1] + invJ3[2][0]*r3[0][2]);
				v[1] = -(invJ3[0][1]*r3[0][0] + invJ3[1][1]*r3[0][1] + invJ3[2][1]*r3[0][2]);
				v[2] = -(invJ3[0][2]*r3[0][0] + invJ3[1][2]*r3[0][1] + invJ3[2][2]*r3[0][2]);
			
				////PHPlot(run[0]);
				//h_fg=(Props('H','T',Ts_cond,'Q',1.0,run[0].Cycle.PrimaryRef)-Props('H','T',Ts_cond,'Q',0.0,run[0].Cycle.PrimaryRef))*1000;
				//omega_opt=0.0;
				//r_best=9999999;
				////Do a crude line search to find the new guess
				//for (omega=0.0;omega<1;omega+=0.05)
				//{				
				//// Predicted solution based on a full step
				//	xp[0] = x[0] + omega * v[0];
				//	xp[1] = x[1] + omega * v[1];
				//	xp[2] = x[2] + omega * v[2];

				//	if (!((xp[0]-xp[1]<run[0].CondenserInputs.Tin_a) || xp[2]+run[0].IHXInputs.DT_sh>run[0].IHXInputs.Tin_g))
				//	{
				//		Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[0],xp[0]      ,xp[1]      ,xp[2]			,r3[0]);		
				//		r_eff=sqrt(r3[0][0]*r3[0][0]/h_fg/h_fg+r3[0][1]*r3[0][1]/h_fg/h_fg+(r3[0][2]/run[0].Cycle.Charge)*(r3[0][2]/run[0].Cycle.Charge));
				//		if (r_eff<r_best)
				//		{
				//			// Keep this omega value
				//				omega_opt=omega;
				//			// Update the new best residual
				//				r_best=r_eff;
				//		}
				//		printf("Cond w: %g,%g,%g\n",run[0].CondenserOutputs.w_subcool,run[0].CondenserOutputs.w_2phase,run[0].CondenserOutputs.w_superheat);
				//		printf("%g::%g\t%g\t%g\t%g\n\n",omega,r3[0][0],r3[0][1],r3[0][2],r_eff);
				//	}
				//}
				//printf("omega_opt: %g\n",omega_opt);
				////Update with new good value

				omega=0.8;
				xp[0] = x[0] + omega * v[0];
				xp[1] = x[1] + omega * v[1];
				xp[2] = x[2] + omega * v[2];

				// Check whether guesses are all ok.
				/* 
				   The outlet temp of condenser should be above the air inlet temp 
				   and the refrigerant inlet temp should be below the glycol inlet temp 

				   If either condition is not met, use a partial step.  Keep making
				   the step smaller until is is ok
				*/
				while (Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[0],xp[0],DT_subcool,xp[1],r3[0])!=0)
				{
					// Run is bad, update with a fractional step
					/* 
					w_corrector in the range (0,1], must be greater than 0.0 , can be up or equal to 1.0
					*/
					w_corrector=0.1; 
					xp[0]=(1.0-w_corrector)*x[0]+w_corrector*xp[0];
					xp[1]=(1.0-w_corrector)*x[1]+w_corrector*xp[1];
					xp[2]=(1.0-w_corrector)*x[2]+w_corrector*xp[2];
				}
				// New step is now ok, update with a full step
				x[0]=xp[0];
				x[1]=xp[1];
				x[2]=xp[2];
				
				//Update the storage of the guessed pinch temperature in IHX
				IHX_pinch=run[0].IHXInputs.Tin_g-run[0].IHXInputs.DT_sh-x[2];

				printf("%g\t%g\t%g\t%g\n",x[0],x[1],x[2],run[0].IHXInputs.Tin_g);
				printf("%g\t%g\t%g\n\n",r3[0][0],r3[0][1],r3[0][2]);
			}

			//Cycle_Calculate(&run[0], x[0], x[1], x[2], r[0]);
			f=run[0].IndoorCoilOutputs.Q-run[0].IHXOutputs.Q;

		if (iterInner==1){y1=f;}
		if (iterInner>1)
		{
			y2=f;
			//Preliminary next step
			x3=x2-y2/(y2-y1)*(x2-x1);
			y1=y2; x1=x2; x2=x3;
		}
		iterInner++;

		printf("T_gly: %g err glycol:%g \n",run[0].IHXInputs.Tin_g,run[0].IndoorCoilOutputs.Q-run[0].IHXOutputs.Q);
		/*Tin_g_IHX+=0.2;*/
	}

	saveOutputs(Outputs,&(run[0]));

	printf("Capacity: %g W\n",run[0].IHXOutputs.Q);
	printf("COP: %g\n",Outputs->COP);
	printf("SHR: %g\n",run[0].IndoorCoilOutputs.SHR);

	//PHPlot(run[0].Cycle.PrimaryRef, run[0]);
	return 0;
}
void DXSolver_ChargeImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs)
{
	double x1,x2,x3,y1,y2,f;
	int iter;

	// Use a secant solve to find the imposed charge by varying subcooling
	/*Inputs->ImposedVariable=malloc(200*sizeof(char));
	strcpy(Inputs->ImposedVariable,"Charge");*/

	x1=1.0; // just slightly subcooled
	//x2=Props('B','T',0.0,'P',0.0,"R410A")-Inputs->CondAirTdb-5; // subcooling amount to get condensing temp to within 5 K of critical temp
	x2=25.0; // very subcooled
	if (x2+Inputs->CondenserAirTdb+5>Tcrit(Inputs->PrimaryRef))
		x2=Tcrit(Inputs->PrimaryRef)-Inputs->CondenserAirTdb-5;
	iter=1;
	while ((iter<=3 || fabs(f)>0.001) && iter<100)
	{	
		if (iter==1){Inputs->DT_subcool=x1;}
		if (iter>1) {Inputs->DT_subcool=x2;}

			DXSolver_SubcoolImposed(runType, Inputs, Outputs);
			f=Outputs->CycleCharge-Outputs->CycleChargeTarget;
			/*printf("DTsubcooling: %0.2f Error: %0.4f Charge %0.3f Target: %0.2f \n Conden: %0.3f Evap: %0.3f Sup: %0.3f Ret: %0.3f\n",Inputs->DT_subcool,f,Outputs->CycleCharge,Outputs->CycleChargeTarget,Outputs->CondenserCharge,Outputs->EvaporatorCharge,Outputs->LineSetSupplyCharge,Outputs->LineSetReturnCharge);
			fgets(dummyString, sizeof dummyString, stdin);*/

		if (iter==1){y1=f;}
		if (iter>1){
			y2=f; 
			x3=x2-y2/(y2-y1)*(x2-x1); 
			y1=y2; x1=x2; x2=x3; 
		}
		iter++;
	}
	//free(Inputs->ImposedVariable);
}

void DXSolver_SubcoolImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs)
{
	struct runVals run[3];
	double x[2],xp[2],xc[2],dx[2],v[2],r[3][3],J[2][2],invJ[2][2],DT_subcool,omega,w_corrector;
	extern int runFail;
	extern char runFailString[1000];

	r[0][0]=99999999.;//Make it go back into the inner loop

	// Load, but intercept the subcooling 
	// to allow the outer solver for charge to drive it
	DT_subcool=Inputs->DT_subcool;
	LoadValues(runType,Inputs,&run[0]);

	printf("%s %g %g\n",run->Cycle.ImposedVariable,run->Cycle.ChargeImposed,run->Cycle.DTsubcoolImposed);
	if (!strcmp(run->Cycle.ImposedVariable,"Charge"))
	{
		// Reload the intercepted subcooling
		run[0].Cycle.DT_subcool=DT_subcool;
		Outputs->CycleChargeTarget=run[0].Cycle.ChargeImposed;
	}

	x[0]=run[0].CondenserInputs.Tin_a+run[0].Cycle.DT_subcool+3;
	x[1]=run[0].EvaporatorInputs.Tin_a-run[0].EvaporatorInputs.DT_sh-5;

	dx[0]=0.05;
	dx[1]=-0.05;
	DT_subcool=run[0].Cycle.DT_subcool;

	run[1]=run[0];
	run[2]=run[0];
	printf("Initial temps: %g\t%g\n",x[0],x[1]);
	while ( fabs(r[0][0])>100 || fabs(r[0][1])>100 )
	{
		/*
		Run the model 3 times to get the values needed to build Jacobian matrix
		with numerical partial derivatives 
		*/
		Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[0],x[0],			DT_subcool,x[1],		r[0]);
		Cycle_Calculate(run[1].Cycle.PrimaryRef,run[1].Cycle.SecondaryRef,&run[1],x[0]+dx[0],	DT_subcool,x[1],		r[1]);
		Cycle_Calculate(run[2].Cycle.PrimaryRef,run[2].Cycle.SecondaryRef,&run[2],x[0],			DT_subcool,x[1]+dx[1],	r[2]);

		// Build the Jacobian matrix by the column
		J[0][0] = (r[1][0]-r[0][0])/dx[0];
		J[0][1] = (r[1][1]-r[0][1])/dx[0];
		J[1][0] = (r[2][0]-r[0][0])/dx[1];
		J[1][1] = (r[2][1]-r[0][1])/dx[1];

		// Invert the Jacobian matrix
		MatInv_2(J,invJ);

		// Solve for the step vector
		v[0] = -(invJ[0][0]*r[0][0] + invJ[1][0]*r[0][1]);
		v[1] = -(invJ[0][1]*r[0][0] + invJ[1][1]*r[0][1]);
	
		omega=1.0;
		// Predicted solution based on a full damped step
		xp[0] = x[0] + omega * v[0];
		xp[1] = x[1] + omega * v[1];


		// Take full step, then run the cycle model
		// If any of the components fail (most likely the evaporator), take a smaller step
		// Keep making the steps smaller and smaller until the cycle no longer fails
		w_corrector=1;
		// Save a copy of the predicted value
		xc[0]=xp[0];
		xc[1]=xp[1];
		while (Cycle_Calculate(run[0].Cycle.PrimaryRef,run[0].Cycle.SecondaryRef,&run[0],xp[0],DT_subcool,xp[1],r[0])!=0)
		{
			// Run is bad, update with a fractional step
			/* 
			w_corrector in the range (0,1], must be greater than 0.0 , can be up or equal to 1.0
			*/
			fprintf(stderr,"%s\n",runFailString);
			fprintf(stderr,"Making a correction to step size, w is %g\n",w_corrector);
			w_corrector=0.5*w_corrector; 
			xp[0]=(1.0-w_corrector)*x[0]+w_corrector*xc[0];
			xp[1]=(1.0-w_corrector)*x[1]+w_corrector*xc[1];
		}
		runFail=0;
		strcpy(runFailString,"");

		// New step is now ok, update step
		x[0]=xp[0];
		x[1]=xp[1];

		printf("%g\t%g\n",x[0],x[1]);
		printf("%12.2f%12.2f\n\n",r[0][0],r[0][1]);
	}
	
	saveOutputs(Outputs,&(run[0]));

	// Free the memory of the Failure string, but only if program called from C, not Python
	if (runType==1)
		free(Outputs->FailString);

	if (strcmp(run->Cycle.ImposedVariable,"Charge"))
	{
		printf("Capacity: %g W\n",(run[0].EvaporatorOutputs.Q-run[0].EvaporatorInputs.FanPower));
		printf("COP: %g\n",Outputs->CycleCOP);
		printf("COP (w/ both fan): %g\n",Outputs->CycleCOPeff);
		printf("SHR: %g\n",Outputs->EvaporatorSHR);	
	}
	//PHPlot(run[0].Cycle.PrimaryRef,run[0]);
	return;
}


int SecondarySolver_SubcoolImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs)
{
	double Ts_cond, DT_subcool, Ts_IHX,omega,Cond_pinch,IHX_pinch,T_freeze,T_max;
	double x[2],xp[2],dx[2],v[2],r[3][3],J[2][2],invJ[2][2],w_corrector,DP,PumpPower;
	struct runVals run;
	int iter=0;
	double x1=0,x2=0,x3=0,y1=0,y2=0,eps=0.01,f=999;
	int iterInner=1,iterGlycol=1;
	extern int runFail;
	extern char runFailString[1000];

	LoadValues(runType,Inputs,&run);	

	/* 
	   First run glycol loop to find the glycol inlet temp 
	   which satisfies the glycol loop energy balance since we have 
	   imposed temps for IHX through problem formulation and IHX 
	   pinch temp guess
	*/
	IHX_pinch=0.1;
	Cond_pinch=0.1;
	
	dx[0]=0.1;
	/* go the opposite direction to build derivative for IHX saturation temp
	to avoid making the outlet temp out of range when building derivative
	*/
	dx[1]=-0.1; 
	r[0][0]=99999.; r[0][1]=99999.;

	// -----------------------------------------------------------------
	//   Estimation of glycol inlet temperature from nominal capacity
	// -----------------------------------------------------------------

	/* In this block, solve for a very good estimation of 
	the glycol temp using the nominal capacity 
	
	A Secant solver is employed since the objective function is 
	close to linear and can be readily handled with a secant solver
	*/

	T_freeze=Props('F','T',283,'P',0.0,run.Cycle.SecondaryRef);
	T_max=Props('M','T',283,'P',0.0,run.Cycle.SecondaryRef);
	printf("Temp range: [%g,%g] K\n",T_freeze,T_max);
	x1=T_freeze+0.1; // small step to get away from freezing temp
	x2=T_max-0.1; // small step to get away from max temp
	iterGlycol=1;
	while ((iterGlycol<=3 || fabs(f)>1) && iterInner<100)
	{	
		if (iterGlycol==1){run.IndoorCoilInputs.Tin_g=x1;}
		if (iterGlycol>1) {run.IndoorCoilInputs.Tin_g=x2;}

		run.IndoorCoilInputs.mdot_g=1000*run.PumpInputs.Vdot; // Assuming the density is close to 1000 kg/m^3 for initial estimate
		run.IndoorCoilInputs.pin_g=200; 
		run.IndoorCoilFinInputs.Air.Tmean=run.IndoorCoilInputs.Tin_a;
		run.IndoorCoilFinInputs.Air.RHmean=run.IndoorCoilInputs.RHin_a;
		IndoorCoil_Calculate(run.Cycle.SecondaryRef, &(run.IndoorCoilFinInputs), &(run.IndoorCoilInputs), &(run.IndoorCoilOutputs));
		f=run.IndoorCoilOutputs.Q-run.Cycle.Qnominal;
		
		if (iterGlycol==1){y1=f;}
		if (iterGlycol>1){
			y2=f; 
			x3=x2-y2/(y2-y1)*(x2-x1); 

			// If neither the max nor freeze temperature can achieve the nominal capacity
			if (iterGlycol==2 && y2<0 && y1<0)
			{
				fprintf(stderr,"Error: no glycol temp can achieve nominal capacity\n");
				runFail=1;
				strcpy(runFailString,"Error: no glycol temp can achieve nominal capacity");
				saveOutputs(Outputs,&(run));
				return FUNC_FAILED;
			}
			y1=y2; x1=x2; x2=x3; 
		}
		iterGlycol++;

		printf("T_gly: %g err glycol:%g \n",run.IndoorCoilInputs.Tin_g,f);
	}

	// -----------------------------------------------------------------
	//                Solver for the combined Secondary system
	// -----------------------------------------------------------------

	if (run.IndoorCoilOutputs.Tout_g > Props('M','T',283,'P',101.3,run.Cycle.SecondaryRef))
	{
		fprintf(stderr,"Error: IHX inlet temperature above fluid correlation max temp\n");
		runFail=1;
		strcpy(runFailString,"Error: IHX inlet temperature above fluid correlation max temp");
		saveOutputs(Outputs,&(run));
		return FUNC_FAILED;
	}
	// Update guess for IHX inlet temp by adding the Delta T from the IndoorCoil
	x1=run.IndoorCoilOutputs.Tout_g;
	x2=x1+0.1;

	DT_subcool=run.Cycle.DT_subcool;
	while ((iterInner<=3 || fabs(f)>eps) && iterInner<100)
	{	
		
		if (iterInner==1){run.IHXInputs.Tin_g=x1; }
		if (iterInner==2){run.IHXInputs.Tin_g=x2; }
		if (iterInner>2) {run.IHXInputs.Tin_g=x2;}

			

			// Initialize the loop with the refrigerant cycle
			if (iterInner==1)
			{	
				Ts_cond=run.CondenserInputs.Tin_a+DT_subcool+Cond_pinch;
				Ts_IHX=run.IHXInputs.Tin_g-run.IHXInputs.DT_sh-IHX_pinch;
				
				x[0]=Ts_cond;
				x[1]=Ts_IHX;
			}
			else
			{
				Ts_cond=run.CondenserInputs.Tin_a+DT_subcool+Cond_pinch;
				Ts_IHX=run.IHXInputs.Tin_g-run.IHXInputs.DT_sh-IHX_pinch;
				x[0]=Ts_cond;
				x[1]=Ts_IHX;
			}

			r[0][0]=99999999.;//Make it go back into the inner loop
			iter=1;
			while ( fabs(r[0][0])>1 || fabs(r[0][1])>1 )
			{
				/*
				Run the model 3 times to get the values needed to build Jacobian matrix
				with numerical partial derivatives 
				*/
				if (Cycle_Calculate(run.Cycle.PrimaryRef,run.Cycle.SecondaryRef,&run,x[0],			DT_subcool,x[1],		r[0])!=0){break;};
				if (Cycle_Calculate(run.Cycle.PrimaryRef,run.Cycle.SecondaryRef,&run,x[0]+dx[0],	DT_subcool,x[1],		r[1])!=0){break;};
				if (Cycle_Calculate(run.Cycle.PrimaryRef,run.Cycle.SecondaryRef,&run,x[0],			DT_subcool,x[1]+dx[1],	r[2])!=0){break;};

				// Build the Jacobian matrix by the column
				J[0][0] = (r[1][0]-r[0][0])/dx[0];
				J[0][1] = (r[1][1]-r[0][1])/dx[0];
				J[1][0] = (r[2][0]-r[0][0])/dx[1];
				J[1][1] = (r[2][1]-r[0][1])/dx[1];

				// Invert the Jacobian matrix
				MatInv_2(J,invJ);

				// Solve for the step vector
				v[0] = -(invJ[0][0]*r[0][0] + invJ[1][0]*r[0][1]);
				v[1] = -(invJ[0][1]*r[0][0] + invJ[1][1]*r[0][1]);
			
				if (iter<20)
					omega=1.0;
				else if (iter<30)
					omega=0.5;
				else
					omega=0.1;

				// Predicted solution based on a full damped step
				xp[0] = x[0] + omega * v[0];
				xp[1] = x[1] + omega * v[1];

				

				// Check whether guesses are all ok.
				/* 
				   The outlet temp of condenser should be above the air inlet temp 
				   and the refrigerant inlet temp should be below the glycol inlet temp 

				   If either condition is not met, use a partial step.  Keep making
				   the step smaller until is is ok
				*/
				while ((xp[0]-DT_subcool<run.CondenserInputs.Tin_a) || xp[1]+run.IHXInputs.DT_sh>run.IHXInputs.Tin_g)
				{
					// Run is bad, update with a fractional step
					/* 
					w_corrector in the range (0,1], must be greater than 0.0 , can be up or equal to 1.0
					*/
					w_corrector=0.1; 
					xp[0]=(1.0-w_corrector)*x[0]+w_corrector*xp[0];
					xp[1]=(1.0-w_corrector)*x[1]+w_corrector*xp[1];
				}
				// New step is now ok, update step
				x[0]=xp[0];
				x[1]=xp[1];

				printf("%g\t%g\t%g\n",x[0],x[1],run.IHXInputs.Tin_g);
				printf("%g\t%g\n\n",r[0][0],r[0][1]);
				iter++;
			}
			if (runFail==1)
				break;

			//Update the storage of the guessed pinch temperature in IHX and condenser
				IHX_pinch=run.IHXInputs.Tin_g-run.IHXInputs.DT_sh-x[1];
				Cond_pinch=x[0]-run.CondenserInputs.Tin_a-DT_subcool;

				DP=run.IHXOutputs.DP_g_2phase+run.IHXOutputs.DP_g_superheat+run.IndoorCoilOutputs.DP_g+run.LineSetReturnOutputs.DP+run.LineSetSupplyOutputs.DP;
				PumpPower=fabs(run.IHXInputs.mdot_g/Props('D','T',run.IHXInputs.Tin_g,'P',200,run.Cycle.SecondaryRef)*DP/run.PumpInputs.Efficiency);
				f=run.IndoorCoilOutputs.Q-run.IHXOutputs.Q+run.LineSetSupplyOutputs.Q+run.LineSetReturnOutputs.Q+PumpPower;

		if (iterInner==1){y1=f;}
		if (iterInner>1)
		{
			y2=f;
			//Preliminary next step
			x3=x2-y2/(y2-y1)*(x2-x1);
			y1=y2; x1=x2; x2=x3;
		}
		iterInner++;

		printf("T_gly: %g err glycol:%g \n",run.IHXInputs.Tin_g,f);
	}

	saveOutputs(Outputs,&(run));

	// Free the memory of the Failure string, but only if program called from C, not Python
	if (runType==1)
		free(Outputs->FailString);

	printf("Capacity: %g W\n",run.IHXOutputs.Q);
	printf("COP: %g\n",Outputs->COP);
	printf("SHR: %g\n",run.IndoorCoilOutputs.SHR);
	printf("Charge: %g\n",Outputs->CycleCharge);

	return 0;
}

void outputCondenserInputs(struct runVals *run)
{
	printf("CondenserInputs.ID %g\n",run->CondenserInputs.ID);
	printf("CondenserInputs.Lcircuit %g\n",run->CondenserInputs.Lcircuit);
	printf("CondenserInputs.Ncircuits %d\n",run->CondenserInputs.Ncircuits);
	printf("CondenserInputs.OD %g\n",run->CondenserInputs.OD);
	printf("CondenserInputs.pin_a %g\n",run->CondenserInputs.pin_a);
	printf("CondenserInputs.RHin_a %g\n",run->CondenserInputs.RHin_a);
	printf("CondenserInputs.Tin_a %g\n",run->CondenserInputs.Tin_a);
	printf("CondenserInputs.Vdot_a %g\n",run->CondenserInputs.Vdot_a);

	//// Load parameters from the 
	printf("CondFinInputs.Tubes.Ntubes_bank :%d\n",run->CondFinInputs.Tubes.Ntubes_bank);
	printf("CondFinInputs.Tubes.Nbank :%d\n",run->CondFinInputs.Tubes.Nbank);
	printf("CondFinInputs.Tubes.Ltube :%g\n",run->CondFinInputs.Tubes.Ltube);
	printf("CondFinInputs.Tubes.D :%g\n",run->CondFinInputs.Tubes.D);
	printf("CondFinInputs.Tubes.Pl :%g\n",run->CondFinInputs.Tubes.Pl);
	printf("CondFinInputs.Tubes.Pt :%g\n",run->CondFinInputs.Tubes.Pt);

	printf("CondFinInputs.Fins.FPI :%g\n",run->CondFinInputs.Fins.FPI);
	printf("CondFinInputs.Fins.Pd :%g\n",run->CondFinInputs.Fins.Pd);
	printf("CondFinInputs.Fins.xf :%g\n",run->CondFinInputs.Fins.xf);
	printf("CondFinInputs.Fins.t :%g\n",run->CondFinInputs.Fins.t);
	printf("CondFinInputs.Fins.k_fin :%g\n",run->CondFinInputs.Fins.k_fin);

	printf("CondFinInputs.Air.Vdot_ha :%g\n",run->CondFinInputs.Air.Vdot_ha);
	printf("CondFinInputs.Air.Tdb :%g\n",run->CondFinInputs.Air.Tdb);
	printf("CondFinInputs.Air.p :%g\n",run->CondFinInputs.Air.p);
	printf("CondFinInputs.Air.RH :%g\n",run->CondFinInputs.Air.RH);
}

void outputIndoorCoilInputs(struct runVals *run)
{
	
	printf("IndoorCoilInputs.ID %g\n",run->IndoorCoilInputs.ID);
	printf("IndoorCoilInputs.Lcircuit %g\n",run->IndoorCoilInputs.Lcircuit);
	printf("IndoorCoilInputs.Ncircuits %d\n",run->IndoorCoilInputs.Ncircuits);
	printf("IndoorCoilInputs.OD %g\n",run->IndoorCoilInputs.OD);
	printf("IndoorCoilInputs.pin_a %g\n",run->IndoorCoilInputs.pin_a);
	printf("IndoorCoilInputs.RHin_a %g\n",run->IndoorCoilInputs.RHin_a);
	printf("IndoorCoilInputs.Tin_a %g\n",run->IndoorCoilInputs.Tin_a);
	printf("IndoorCoilInputs.Vdot_a %g\n",run->IndoorCoilInputs.Vdot_a);

	printf("IndoorCoilFinInputs.Air.p %g\n",run->IndoorCoilFinInputs.Air.p);
	printf("IndoorCoilFinInputs.Air.RH %g\n",run->IndoorCoilFinInputs.Air.RH);
	printf("IndoorCoilFinInputs.Air.Tdb %g\n",run->IndoorCoilFinInputs.Air.Tdb);
	printf("IndoorCoilFinInputs.Air.Vdot_ha %g\n",run->IndoorCoilFinInputs.Air.Vdot_ha);

	printf("IndoorCoilFinInputs.Fins.FPI %g\n",run->IndoorCoilFinInputs.Fins.FPI);
	printf("IndoorCoilFinInputs.Fins.k_fin %g\n",run->IndoorCoilFinInputs.Fins.k_fin);
	printf("IndoorCoilFinInputs.Fins.Pd %g\n",run->IndoorCoilFinInputs.Fins.Pd);
	printf("IndoorCoilFinInputs.Fins.t %g\n",run->IndoorCoilFinInputs.Fins.t);
	printf("IndoorCoilFinInputs.Fins.xf %g\n",run->IndoorCoilFinInputs.Fins.xf);

	printf("IndoorCoilFinInputs.Tubes.D %g\n",run->IndoorCoilFinInputs.Tubes.D);
    printf("IndoorCoilFinInputs.Tubes.Nbank %d\n",run->IndoorCoilFinInputs.Tubes.Nbank);
	printf("IndoorCoilFinInputs.Tubes.Ntubes_bank %d\n",run->IndoorCoilFinInputs.Tubes.Ntubes_bank);
	printf("IndoorCoilFinInputs.Tubes.Pl %g\n",run->IndoorCoilFinInputs.Tubes.Pl);
    printf("IndoorCoilFinInputs.Tubes.Pt %g\n",run->IndoorCoilFinInputs.Tubes.Pt);
}

void outputCycleInputs(struct runVals *run)
{
    printf("Cycle.Charge %g\n",run->Cycle.Charge);
}
void outputIHXInputs(struct runVals *run)
{
	printf("IHXInputs.OD_o %g\n",run->IHXInputs.OD_o);
	printf("IHXInputs.ID_o %g\n",run->IHXInputs.ID_o);
	printf("IHXInputs.OD_i %g\n",run->IHXInputs.OD_i);
	printf("IHXInputs.L %g\n",run->IHXInputs.L);
	printf("IHXInputs.DT_sh %g\n",run->IHXInputs.DT_sh);
	printf("IHXInputs.mdot_g %g\n",run->IHXInputs.mdot_g);
	printf("IHXInputs.pin_g %g\n",run->IHXInputs.pin_g);
}


int Cycle_Calculate(char *PrimaryRef, char *SecondaryRef, struct runVals *run,double Ts_cond, double DT_subcool, double Ts_IHX, double *r )
{
	double DT_sh;

	double Ts_IHX_DP, Ts_cond_DP, Ps_cond, Ps_IHX;

	if (run->Cycle.CycleType==CYCLETYPE_SECONDARY)
	{
		DT_sh=run->IHXInputs.DT_sh;
		run->CompressorInputs.Tsat_d=Ts_cond;
		run->CompressorInputs.Tsat_s=Ts_IHX;
		run->CompressorInputs.DT_sh=DT_sh;
		if (Compressor_Calculate(PrimaryRef,&(run->CompressorInputs),&(run->CompressorOutputs))!=0){return FUNC_FAILED;}
		

		run->CondenserInputs.mdot_r = run->CompressorOutputs.mdot;					//[kg/s]
		run->CondenserInputs.pout_r = Props('P','T',Ts_cond,'Q',0.0,PrimaryRef);		//[kPa]
		run->CondenserInputs.Tsat_r = Ts_cond;									//[K]
		run->CondenserInputs.Tout_r = Ts_cond-DT_subcool;						//[K]
		run->CondenserOutputs.hin_r = Props('H','T',Ts_cond-DT_subcool,'P',run->CondenserInputs.pout_r,PrimaryRef)*1000.0;
		
		// Get mean air conditions
		MeanTairCondenser(run,&(run->CondFinInputs.Air.Tmean),&(run->CondFinInputs.Air.RHmean));

		if (Condenser_Calculate(PrimaryRef,&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs))!=0){return FUNC_FAILED;};

		run->IHXInputs.mdot_r = run->CompressorOutputs.mdot;							//[kg/s]
		run->IHXInputs.Tout_r = Ts_IHX+DT_sh;					//[K]
		run->IHXInputs.Tsat_r = Ts_IHX;											//[K]

		/*Assuming the pressure drop through the superheated section is zero, 
		the outlet pressure will be the refrigerant saturation temperature*/
		run->IHXInputs.pout_r = Props('P','T',Ts_IHX,'Q',1.0,PrimaryRef);				//[kPa]
		
		if (IHX_Calculate(PrimaryRef,SecondaryRef,&(run->IHXInputs),&(run->IHXOutputs))!=0){return FUNC_FAILED;};

		run->LineSetSupplyInputs.mdot=run->IHXInputs.mdot_g;
		run->LineSetSupplyInputs.Tin=run->IHXOutputs.Tout_g;
		run->LineSetSupplyInputs.pin=run->IHXInputs.pin_g;

		if (LineSet_Calculate(SecondaryRef, &(run->LineSetSupplyInputs),&(run->LineSetSupplyOutputs))!=0){return FUNC_FAILED;};

		run->IndoorCoilInputs.mdot_g=run->IHXInputs.mdot_g;
		run->IndoorCoilInputs.Tin_g=run->LineSetSupplyOutputs.Tout;
		run->IndoorCoilInputs.pin_g=run->IHXInputs.pin_g; //TODO: fix this
		run->IndoorCoilFinInputs.Air.Tmean=run->IndoorCoilInputs.Tin_a;
		run->IndoorCoilFinInputs.Air.RHmean=run->IndoorCoilInputs.RHin_a;
		if (IndoorCoil_Calculate(SecondaryRef, &(run->IndoorCoilFinInputs), &(run->IndoorCoilInputs), &(run->IndoorCoilOutputs))!=0){return FUNC_FAILED;};

		run->LineSetReturnInputs.mdot=run->IHXInputs.mdot_g;
		run->LineSetReturnInputs.Tin=run->IndoorCoilOutputs.Tout_g;
		run->LineSetReturnInputs.pin=run->IHXInputs.pin_g; //TODO: fix this

		if (LineSet_Calculate(SecondaryRef, &(run->LineSetReturnInputs),&(run->LineSetReturnOutputs))!=0){return FUNC_FAILED;};

		r[0]=run->CondenserOutputs.hin_r-run->CompressorOutputs.h2;
		r[1]=run->IHXOutputs.hin_r-run->CondenserOutputs.hout_r;
		r[2]=run->IHXOutputs.Charge+run->CondenserOutputs.Charge-run->Cycle.Charge;
	}
	else if (run->Cycle.CycleType==CYCLETYPE_DX)
	{
		DT_sh=run->EvaporatorInputs.DT_sh;

		////// Code to add pressure lift from the low and high side pressure drops
		//////  Mass flow rate changes less than 1.0%

		//////Ps_cond=Props('P','T',Ts_cond,'Q',1.0,PrimaryRef);
		//////Ps_IHX=Props('P','T',Ts_IHX,'Q',1.0,PrimaryRef);

		//////Ts_cond_DP=Tsat(PrimaryRef,Ps_cond+74,1.0,Ts_cond);
		//////Ts_IHX_DP=Tsat(PrimaryRef,Ps_IHX-10,1.0,Ts_IHX);

		//////run->CompressorInputs.Tsat_d=Ts_cond_DP;
		//////run->CompressorInputs.Tsat_s=Ts_IHX_DP;
		//////run->CompressorInputs.DT_sh=20./9.*5.;
		//////run->CompressorInputs.Vdot_ratio=1.0;
		//////Compressor_Calculate(PrimaryRef,&(run->CompressorInputs),&(run->CompressorOutputs));

		//First do a preliminary compressor solve to find the nominal mass flow rate
		run->CompressorInputs.Tsat_d=Ts_cond;
		run->CompressorInputs.Tsat_s=Ts_IHX;
		run->CompressorInputs.DT_sh=20./9.*5.;
		if (Compressor_Calculate(PrimaryRef,&(run->CompressorInputs),&(run->CompressorOutputs))!=0){return FUNC_FAILED;};
		//printf("Comp ok\n");

		//Then use that mass flow rate to solve the return line set (evaporator to compressor)
		run->LineSetReturnInputs.mdot=run->CompressorOutputs.mdot;
		run->LineSetReturnInputs.Tin=Ts_IHX+DT_sh;
		run->LineSetReturnInputs.pin=Props('P','T',Ts_IHX,'Q',1.0,PrimaryRef); 
		if (LineSet_Calculate(PrimaryRef, &(run->LineSetReturnInputs),&(run->LineSetReturnOutputs))!=0){return FUNC_FAILED;};
		//printf("LineSet ok\n");
	
		//Then solve the compressor again with the new "correct" inlet temperature
		run->CompressorInputs.DT_sh=DT_sh+run->LineSetReturnOutputs.Tout-run->LineSetReturnInputs.Tin;
		if (Compressor_Calculate(PrimaryRef,&(run->CompressorInputs),&(run->CompressorOutputs))!=0){return FUNC_FAILED;};
		//printf("Comp ok\n");

		//Solve the condenser backwards
		run->CondenserInputs.mdot_r = run->CompressorOutputs.mdot;					//[kg/s]
		run->CondenserInputs.pout_r = Props('P','T',Ts_cond,'Q',0.0,PrimaryRef);		//[kPa]
		run->CondenserInputs.Tsat_r = Ts_cond;									//[K]
		run->CondenserInputs.Tout_r = Ts_cond-DT_subcool;						//[K]
		run->CondenserOutputs.hin_r = Props('H','T',Ts_cond-DT_subcool,'P',run->CondenserInputs.pout_r,PrimaryRef)*1000.0;

		// Get mean air conditions in condenser
			MeanTairCondenser(run,&(run->CondFinInputs.Air.Tmean),&(run->CondFinInputs.Air.RHmean));

		if (Condenser_Calculate(PrimaryRef,&(run->CondFinInputs),&(run->CondenserInputs),&(run->CondenserOutputs))!=0){return FUNC_FAILED;};
		//printf("Condenser ok\n");

		//Solve the line-set forwards which brings liquid from condenser to evaporator/TXV 
		run->LineSetSupplyInputs.mdot=run->CondenserInputs.mdot_r;
		run->LineSetSupplyInputs.Tin=run->CondenserInputs.Tout_r;
		run->LineSetSupplyInputs.pin=run->CondenserInputs.pout_r;
		if (LineSet_Calculate(PrimaryRef, &(run->LineSetSupplyInputs),&(run->LineSetSupplyOutputs))!=0){return FUNC_FAILED;};
		//printf("LineSet ok\n");

		/*Assuming the pressure drop through the superheated section is zero, 
		the outlet pressure will be the refrigerant saturation temperature*/
		run->EvaporatorInputs.pout_r = Props('P','T',Ts_IHX,'Q',1.0,PrimaryRef);				//[kPa]
		run->EvaporatorInputs.mdot_r = run->CompressorOutputs.mdot;							//[kg/s]
		run->EvaporatorInputs.Tout_r = Ts_IHX+DT_sh;						//[K]
		run->EvaporatorInputs.Tsat_r = Ts_IHX;											//[K]
		run->EvaporatorOutputs.hout_r = Props('H','T',Ts_IHX+DT_sh,'P',run->EvaporatorInputs.pout_r,PrimaryRef)*1000.0;
		MeanTairEvaporator(run,&(run->EvaporatorFinInputs.Air.Tmean),&(run->EvaporatorFinInputs.Air.RHmean));
		if (Evaporator_Calculate(PrimaryRef,&(run->EvaporatorFinInputs), &(run->EvaporatorInputs), &(run->EvaporatorOutputs))!=0){return FUNC_FAILED;};
		//printf("Evap ok\n");

		r[0]=run->CondenserOutputs.hin_r-run->CompressorOutputs.h2;
		r[1]=run->EvaporatorOutputs.hin_r-run->LineSetSupplyOutputs.hout;
		r[2]=run->EvaporatorOutputs.Charge+run->CondenserOutputs.Charge-run->Cycle.Charge;

		return 0;
	}
	else
	{
		printf("Not valid cycle type");
		getchar();
		exit(EXIT_FAILURE);
	}

	//printf("%g,%g,%g\n",r[0],r[1],r[2]);

	
	return 0;
}