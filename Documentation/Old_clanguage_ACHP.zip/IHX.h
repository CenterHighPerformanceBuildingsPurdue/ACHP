#ifndef IHX_H
#define IHX_H

    struct IHXInputVals
	{
		double Tsat_r;
		double Tout_r;
        double Tin_r;
		double Tinter_g_sh_2p;
		double Tinter_g_sc_2p;
		double pout_r;
        double mdot_r;
        double xin_r;
		double hout_r;

        double mdot_g;
        double pin_g;
        double Tin_g;
		double mdot_IHX_g;
		double mdot_IHX_r;

        double OD_o; //' Outer diameter of the outer annulus (at inside of outer wall)
        double ID_o;
        double OD_i;
        double L;
        double Q_2phase;

		double DT_sh;

		double G_g;
		double G_r;
		double Dh_g;
		double Dh_r;
		double A_g;
		double A_r;
		double V_g;
		double V_r;

		double FPdelta;
		double FPW;
		double FPN_g;
		double FPN_r;
		double FPL;

		double eps_dT;
		int N;
	};

    struct IHXOutputVals
	{
        double Q;
        double Charge;
        double Tout_g;
        double Tout_r;

		double Q_superheat;
        double Q_2phase;
		double Q_subcool;

		double Charge_superheat;
        double Charge_2phase;
		double Charge_subcool;

		double w_superheat;
		double w_2phase;
		double w_subcool;

		double DP_g_superheat;
		double DP_g_2phase;
		double DP_g_subcool;

		double DP_r;
		double DP_r_superheat;
		double DP_r_2phase;
		double DP_r_subcool;


		double h_r_superheat;
		double h_r_2phase;
		double h_r_subcool;

		double h_g_superheat;
		double h_g_2phase;
		double h_g_subcool;

		double Re_g_superheat;
		double Re_g_2phase;
		double Re_g_subcool;
		double Re_r_superheat;
		double Re_r_2phase;
		double Re_r_subcool;


        double hout_r;
		double hin_r;
		double sin_r;
		double sout_r;
		double xin_r;
		double Tin_r;
		double Tin_g;
		int Exists_subcool;
	};

	int IHX_Calculate(char * PrimaryRef_, char * SecondaryRef_,struct IHXInputVals *Inputs_, struct IHXOutputVals *Outputs_);

#endif