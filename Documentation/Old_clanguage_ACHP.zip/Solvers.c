#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#include <stdio.h>
#include "math.h"
#include "Solvers.h"

static void swap(double *x, double *y)
{
    double temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

double Dekker(double(*fptr)(double),double x_min, double x_max, double eps)
{
	double a_k,b_k,f_ak,f_bk,f_bkn1,error, 
		b_kn1,b_kp1,s,m,a_kp1,f_akp1,f_bkp1,x;

	int iter=1;

	// Loop for the solver method
    while ((iter <= 1 || fabs(error) > eps) && iter < 100)
	{
		// Start with the maximum value
        if (iter == 1)
		{
            a_k = x_max;
            x = a_k;
		}
		// End with the minimum value
        if (iter == 2)
		{
            b_k = x_min;
            x = b_k;
		}
        if (iter > 2)
            x = b_k;

		// Evaluate residual
        error = fptr(x);

		// First time through, store the outputs
        if(iter == 1)
		{
            f_ak = error;
            b_kn1 = a_k;
            f_bkn1 = error;
		}
        if (iter > 1)
		{
            f_bk = error;
			//Secant solution
            s = b_k - (b_k - b_kn1) / (f_bk - f_bkn1) * f_bk;
			//Midpoint solution
            m = (a_k + b_k) / 2.0;

            if (s > b_k && s < m)
			{
                //Use the secant solution
                b_kp1 = s;
			}
            else
			{
				//Use the midpoint solution
                b_kp1 = m;
			}

            //See if the signs of iterate and contrapoint are the same
            f_bkp1 = fptr(b_kp1);

            if (f_ak / fabs(f_ak) != f_bkp1 / fabs(f_bkp1))
			{
                // If a and b have opposite signs, 
				//  keep the same contrapoint
                a_kp1 = a_k;
                f_akp1 = f_ak;
			}
            else
			{
                //Otherwise, keep the iterate
                a_kp1 = b_k;
                f_akp1 = f_bk;
			}

            if (fabs(f_akp1) < fabs(f_bkp1))
			{
                //a_k+1 is a better guess than b_k+1, so swap a and b values
				swap(&a_kp1, &b_kp1);
                swap(&f_akp1, &f_bkp1);
			}

            //Update variables
            //Old values
            b_kn1 = b_k;
            f_bkn1 = f_bk;
            //values at this iterate
            b_k = b_kp1;
            a_k = a_kp1;
            f_ak = f_akp1;
            f_bk = f_bkp1;
		}
        iter++;
		if (iter>90 && fabs(error)>eps)
		{
			printf("Dekker has failed\n");
		}
	}
	fptr(b_k);
	return b_k;
}