#ifndef PHE_H
#define PHE_H

	struct PHEInputVals
	{
		double pin_h;      //Inlet pressure of hot stream [kPa]
		double Tin_h;      //Inlet temp of hot stream [K]
		double hin_h;      //Inlet enthalpy of hot stream [J/kg]
		char *Ref_h;       //Refrigerant of hot stream [""]
		double mdot_h;     //Mass flow rate of hot stream [kg/s]

		double pin_c;      //Inlet pressure of cold stream [kPa]
		double Tin_c;      //Inlet temp of cold stream [K]
		double hin_c;      //Inlet enthalpy of cold stream [J/kg]
		char *Ref_c;       //Refrigerant of cold stream [""]
		double mdot_c;     //Mass flow rate of cold stream [kg/s]

		// Geometric parameters (see below):
		int Nplates;       // Number of plates [#]
		double spacing;    // Plate spacing [m]
		double W;          // Width of one plate [m]
		double H;          // Height of one plate [m]


		//         ------------
		//        /    W     / spacing
		//       ------------
        //       | O      O |
		//       |          |
		//       |          | 
		//       |          | H
		//       |          |
		//       |          |
		//       | O      O |
		//       ------------
		
	};

	struct PHEOutputVals
	{
		double Q;          //Heat transferred;
	};

	// FUNCTION PROTOTYPES
	void CalculatePHE(struct PHEInputVals *Inputs, struct PHEOutputVals *Outputs);
#endif PHE_H