#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>
#include <stdio.h>
#include "string.h"

#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"
#include "Solvers.h"
#include "RefCycleSolver.h"

#include "Condenser.h"

char *Ref;
struct FinHTCDPInputsVals FinInputs;
struct CondenserInputVals Inputs;
struct CondenserOutputVals Outputs;

static double Subcooled();
static double TwoPhase(double w_2phase);
static void Superheat(double w_superheat);

static double Superheat_Forward();
static double TwoPhase_Forward();
static double Subcooled_Forward(double w_subcool);

 static void swap(double *x, double *y)
 {
        double temp;
        temp = *x;
        *x = *y;
        *y = temp;
 }

static double minVal(double x1, double x2)
{
	if (x1<x2)
		return x1;
	else
		return x2;
}

static double maxVal(double x1, double x2)
{
	if (x1>x2)
		return x1;
	else
		return x2;
}

int Condenser_Calculate(char *Ref_, struct FinHTCDPInputsVals *FinInputs_, struct CondenserInputVals *Inputs_, struct CondenserOutputVals *Outputs_)
{
	double w_subcool,w_2phase,w_superheat;

	//Copy values from passed variables to temporary global variables
	Inputs=*Inputs_;
	FinInputs=*FinInputs_;
	Outputs=*Outputs_;
	Ref=Ref_;

	// Check that outlet ref temp is above inlet air temp (otherwise heat would go the other way)
	// if it is backwards solving mode
	if (Inputs.Tout_r < Inputs.Tin_a && strcmp(Inputs.Mode,"Forward"))
	{
		runFail=1;
		fprintf(stderr,"Condenser outlet Ref. temperature below inlet air temperature\n");
		strcpy(runFailString,"Condenser outlet Ref. temperature below inlet air temperature");
		return FUNC_FAILED;
	}

	Outputs.hout_r=Props('H','T',Inputs.Tout_r,'P',Inputs.pout_r,Ref)*1000;
	Outputs.Exists_superheat=-1;
	Outputs.Exists_2phase=-1;

	// Evaluate the air-side heat transfer and pressure drop
		FinInputs.Air.cs_cp=1.0;
		WavyLouveredFins(&FinInputs);
		//WavyFins(&FinInputs);

	if (!strcmp(Inputs.Mode,"Forward"))
	{
		// Condenser is being solved forwards with superheated, subcooled and two-phase sections
		w_superheat=Superheat_Forward();
		w_2phase=TwoPhase_Forward();
		w_subcool=Subcooled_Forward(1-w_superheat-w_2phase);
	}
	else
	{
		// Condenser is being solved backwards
		// First try to use all the area in the subcooled region, 
		// see if there is enough area to get to the saturation temperature
		w_subcool=Subcooled();

		if (Outputs.Exists_2phase==1)
		{
			// Try to use the remaining length for the 2phase region.
			w_2phase=TwoPhase(1-w_subcool);

			// If you can get all the refrigerant to condense, use Dekker to solve
			// for the amount of length that is two-phase. 
			if (Outputs.Exists_superheat)
			{
				// Solve the superheated section
				Superheat(1-w_subcool-w_2phase);
				Outputs.w_superheat=1-w_subcool-w_2phase;
			}
			else
			{
				Outputs.w_2phase=1-w_subcool;
				// Solve for the inlet quality with fraction of length equal to 1-w_subcool;
				Dekker(TwoPhase,0.0,1.0,0.1);
				w_2phase=1-w_subcool;
				Outputs.Tin_r=Inputs.Tsat_r;
				Outputs.hin_r=Props('H','T',Inputs.Tsat_r,'Q',0,Ref)*1000-Outputs.Q_2phase/(Inputs.mdot_r); //Find two-phase enthalpy at inlet
				Outputs.Charge_superheat=0.0;
				Outputs.Q_superheat=0.0;
				Outputs.w_superheat=0.0;
				Outputs.h_superheat=0.0;
				Outputs.Re_superheat=0.0;
				Outputs.DP_superheat=0.0;
			}
		}
		else
		{
			w_subcool=1.0;
			w_2phase=0.0;

			Outputs.Q_2phase=0.0;
			Outputs.DP_2phase=0.0;
			Outputs.Charge_2phase=0.0;
			Outputs.h_2phase=0.0;
			Outputs.w_2phase=0.0;

			Outputs.Q_superheat=0.0;
			Outputs.Charge_superheat=0.0;
			Outputs.w_superheat=0.0;
			Outputs.Re_superheat=0.0;
			Outputs.h_superheat=0.0;
			Outputs.DP_superheat=0.0;
		}
	}

	//Combine together
	Outputs.Charge=Outputs.Charge_subcool+Outputs.Charge_2phase+Outputs.Charge_superheat;
	Outputs.Q=Outputs.Q_subcool+Outputs.Q_2phase+Outputs.Q_superheat;
	Outputs.DP=Outputs.DP_subcool+Outputs.DP_2phase+Outputs.DP_superheat;
	Outputs.hout_r=Props('H','T',Inputs.Tout_r,'P',Inputs.pout_r,Ref)*1000; //Find enthalpy at outlet
	Outputs.w_subcool=w_subcool;
	Outputs.w_2phase=w_2phase;

	Outputs.sout=Props('S','T',Inputs.Tout_r,'P',Inputs.pout_r,Ref)*1000;
	Outputs.sin=Props('S','T',Outputs.Tin_r,'P',Inputs.pout_r,Ref)*1000;

	//Copy values back to passed variables
	*Inputs_=Inputs;
	*FinInputs_=FinInputs;
	*Outputs_=Outputs;
	return 0;
}
static double Subcooled()
{
	double mdot_r,Vdot_a,Tin_a,Tout_r,pin_a,pout_r,Tsat_r,h_a,A_a,eta_a,cp_a,mdot_a,f_a,dP_a,OD,ID,Lcircuit,Ncircuits,
		V_r,A_a_subcool,mdot_a_subcool,A_r_subcool,f_r_subcool,h_r_subcool,cp_r,
		epsilon_subcool,Q_subcool,charge_subcool,rho_subcool,Re_r_subcool,
		Dh_r,A_r,G_r,v_r,dpdz_r,h_fg,Tin_r,UA_overall,A_r_wetted,w_subcool;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
	Tout_r =	Inputs.Tout_r;
    pin_a =		Inputs.pin_a;
    pout_r =	Inputs.pout_r;
    Tsat_r =	Inputs.Tsat_r;

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;

	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;

	// ************************************************************************************
	//									SUBCOOLED PART 
	// ************************************************************************************

	// Based on the the construction of the cycle model there is guaranteed to be a 
	// two-phase portion of the heat exchanger
	A_r_wetted = pi * ID * Ncircuits * Lcircuit;

	// Friction factor and HTC in the refrigerant portions.
	// Average fluid temps are used for the calculation of properties 
	// Average temp of refrigerant is average of sat. temp and outlet temp
	// Secondary fluid is air over the fins

	f_h_1phase_Tube(mdot_r / Ncircuits, ID, (Tout_r+Tsat_r)/2, pout_r, Ref, 
		"Single", &f_r_subcool, &h_r_subcool, &Re_r_subcool);
	
    cp_r = Props('C', 'T', (Tsat_r+Tout_r)/2.0, 'P', pout_r, Ref)*1000;						//[J/kg-K]

	// Cross-flow in the subcooled region.
	UA_overall = 1. / (1. / (eta_a * h_a * A_a) + 1. / (h_r_subcool * A_r_wetted) );
	epsilon_subcool=(Tout_r-Tsat_r)/(Tin_a-Tsat_r);
	w_subcool=-log(1-epsilon_subcool)*mdot_r*cp_r/((1-exp(-UA_overall/(mdot_a*cp_a)))*mdot_a*cp_a);

	// Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	// Heat is removed here from the refrigerant since it is condensing
	Q_subcool = mdot_r*cp_r*(Tout_r-Tsat_r);
	rho_subcool=Props('D', 'T', (Tsat_r + Tout_r) / 2, 'P', pout_r, Ref);
	charge_subcool = w_subcool * V_r * rho_subcool;

	//Pressure drop calculations for subcooled refrigerant
	Dh_r=ID;																//[
	A_r=pi*Dh_r*Dh_r/4.0;
	G_r=mdot_r/((double)Ncircuits)/A_r;
	v_r=1/rho_subcool;
	//Pressure gradient using Darcy friction factor
	dpdz_r=-f_r_subcool*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
	Outputs.DP_subcool=dpdz_r*Lcircuit*w_subcool;

	// See if the two-phase region exists. If the heat transferred is 
	// less than that required to bring to saturation temp, set the flag 
	// in the output structure to alert the external solver

	if (Outputs.Exists_2phase==-1) // If not defined yet
	{
		// If there is not enough heat transferred with the full area used for subcooled region
		if (w_subcool>1.0)
			Outputs.Exists_2phase=0; // There is no two-phase region
		else
			Outputs.Exists_2phase=1;//There is a two-phase (and maybe superheated) region
	}
	
	// Latent heat needed for quality calc
	h_fg=(Props('H','T',Tsat_r,'Q',1.0,Ref)-Props('H','T',Tsat_r,'Q',0.0,Ref))*1000;
	Tin_r=Tout_r-Q_subcool/(mdot_r*cp_r);
	Outputs.xin_r=cp_r*(Tin_r-Tsat_r)/h_fg; //TODO: fix me
	Outputs.Charge_subcool=charge_subcool;
	Outputs.Q_subcool=Q_subcool;
	Outputs.h_subcool=h_r_subcool;
	Outputs.Re_subcool=Re_r_subcool;
	Outputs.hin_r=Outputs.hout_r-Q_subcool/mdot_r;

	return w_subcool;
}

static double TwoPhase(double InputVal)
{
	// ************************************************************************************
	//									TWO PHASE PART 
	// ************************************************************************************

	/*
	There is guaranteed to be at least some two-phase portion, 
	but there may not be sufficient Delta T to bring the inlet of the condenser
	into the superheated region
	*/

	double mdot_r,Vdot_a,Tin_a,pin_a,pout_r,Tsat_r,OD,ID,Lcircuit,V_r,h_a,A_a,eta_a,cp_a,mdot_a,
		h_fg,G_r,h_r_2phase,epsilon_2phase,
		Q_2phase,f_a,dP_a,OutputValue,
		x1=0,x2=0,xin_r,w_2phase,v_g,v_f,UA_overall,A_r_wetted,
		DP_accel,alpha_in,dpdz_dummy,DP_frict,rhog,rhof,S,alpha_average,rho_average,C;
	int Ncircuits;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
    pin_a =		Inputs.pin_a;
    pout_r =	Inputs.pout_r;
    Tsat_r =	Inputs.Tsat_r;

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;

	if (Outputs.Exists_superheat==-1 || Outputs.Exists_superheat==1)
	{
		// You are trying the first time to figure out 
		// whether the inlet state of two-phase region 
		// is saturated vapor or has some quality
		xin_r=1.0;
		w_2phase=InputVal;
	}
	else if (Outputs.Exists_superheat==0)
	{
		// You know you have two-phase at the inlet, now solve 
		// for the inlet quality for known area fraction
		w_2phase=Outputs.w_2phase;
		xin_r=InputVal;
	}
	// Total refrigerant side volume
	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;
	// Latent heat at given saturation temp
	// TODO: fix for refrigerants with glide
	h_fg = (Props('H','T',Tsat_r,'Q',1,Ref)-Props('H','T',Tsat_r,'Q',0,Ref))*1000; // [J/kg] 
	// Wetted area on refrigerant side
	A_r_wetted = pi * ID * Ncircuits * Lcircuit;
	// Refrigerant mass flux
	G_r = mdot_r / (Ncircuits * pi  * (ID*ID) / 4.0);

	// This block calculates the average refrigerant heat transfer coefficient by
	// integrating the local heat transfer coefficient between 
	// a quality of 0.0 and the inlet quality
	h_r_2phase=ShahCondensation_Average(Ref,G_r, ID, 0.0,xin_r,Tsat_r);

	//On the first call of this function, all the 
	//remaining area is used for the two-phase region, and 
	//it is assumed that if using all the area and and an inlet
	//quality of 1.0 gives more HT than needed to get to a quality of
	//1.0, there must be a superheated portion
	// 
	//If you have already been here and you know there is a superheated region, jump
	//out of the interior solver and jump back to the Dekker solve
	//for the two-phase fraction 
	if (Outputs.Exists_superheat==-1)
	{
		// The area fraction is being calculated on the first iteration
		UA_overall = 1 / (1 / (eta_a * h_a * A_a) + 1 / (h_r_2phase * A_r_wetted));
		epsilon_2phase=(1-exp(-UA_overall/(mdot_a*cp_a)));
		w_2phase=-mdot_r*h_fg/(mdot_a*cp_a*(Tin_a-Tsat_r)*epsilon_2phase);
		if (w_2phase<InputVal) 
		{
			/*
			Some area is available for superheated region
			and solver is used to find area needed for 
			two-phase refgion - you are done
			*/
			Outputs.Exists_superheat=1;
			OutputValue=w_2phase;
		}
		else
		{
			Outputs.Exists_superheat=0;
			OutputValue=0;
		}
	}
	else if (Outputs.Exists_superheat==0)
	{
		// The inlet quality is being calculated
		UA_overall = 1 / (1 / (eta_a * h_a * A_a) + 1 / (h_r_2phase * A_r_wetted));
		epsilon_2phase=(1-exp(-UA_overall/(mdot_a*cp_a)));
		OutputValue=epsilon_2phase*w_2phase*cp_a*mdot_a*(Tin_a-Tsat_r)+xin_r*mdot_r*h_fg;
	}
	 
	//Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	//Heat is removed here from the refrigerant since it is condensing
	Q_2phase = epsilon_2phase *cp_a* mdot_a * w_2phase * (Tin_a-Tsat_r);
	
	// Find void fraction at inlet quality from Lockhart-Martinelli separated flow relation
	LockhartMartinelli(Ref, G_r, ID, xin_r, Tsat_r, &dpdz_dummy, &alpha_in);
	// Accelerational pressure drop component
	v_g=1./Props('D','T',Tsat_r,'Q',1.0,Ref);
	v_f=1./Props('D','T',Tsat_r,'Q',0.0,Ref);
	if (xin_r==0.0)
		DP_accel=G_r*G_r*(v_f-v_g);
	else if (xin_r==1.0)
		DP_accel=0.0;
	else
		DP_accel=G_r*G_r*((xin_r*xin_r/alpha_in*v_g+(1-xin_r)*(1-xin_r)*v_f/(1-alpha_in))-v_g);
	// Frictional pressure drop component
	DP_frict=LMPressureGradientAvg(Ref,G_r,ID,0.0,xin_r,Tsat_r)*Lcircuit*w_2phase;
			
	// Total pressure drop is the sum of accelerational and frictional components (neglecting gravitational effects)
	Outputs.DP_2phase=-(DP_frict+DP_accel);

	rhog=Props('D', 'T', Tsat_r, 'Q', 1, Ref);
	rhof=Props('D', 'T', Tsat_r, 'Q', 0, Ref);
	S=pow(rhof/rhog,0.3333);
	C=S*rhog/rhof;
	x1=xin_r;
	x2=0.0;
	if (x1==0.0)
		alpha_average=1.0;
	else
		/* 
		Obtained by taking the average of void fraction between inlet and outlet qualities
		*/
		alpha_average=-(C*(log( ((x2-1.0)*C-x2)/((x1-1.0)*C-x1) )+x2-x1)-x2+x1)/(C*C-2*C+1)/(x2-x1);
	rho_average= alpha_average*rhog + (1-alpha_average)*rhof;
	Outputs.Charge_2phase = rho_average * w_2phase * V_r;
	Outputs.Q_2phase=Q_2phase;
	Outputs.h_2phase=h_r_2phase;
	Outputs.xin_r=xin_r;
	Outputs.w_2phase=w_2phase;
	return OutputValue;
}

static void Superheat(double w_superheat)
{

	// ************************************************************************************
	//									SUPERHEATED PART 
	// ************************************************************************************

	// May or may not exist depending on the saturation temp of Condenser

	double mdot_r,Vdot_a,Tin_a,pin_a,pout_r,Tsat_r,OD,ID,Lcircuit,V_r,h_a,A_a,eta_a,cp_a,mdot_a,
		A_a_superheat,mdot_a_superheat,A_r_superheat,f_r_superheat, h_r_superheat,UA_overall,
		Cr,NTU,Q_superheat,cp_r,Tin_r,f_a,dP_a,epsilon_r,epsilon_superheat,hsat_r,UA_superheat,
		Re_r_superheat,Dh_r,G_r,v_r,dpdz_r,A_r,A_r_wetted,A,PSI,Cmin,
		rho_superheat,h_fg,Tcric, h_cric,Ntu_r;
	int Ncircuits;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
    pin_a =		Inputs.pin_a;
    Tsat_r =	Inputs.Tsat_r;
	pout_r =	Props('P','T',Tsat_r,'Q',1.0,Ref);

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;

	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;

	A_a_superheat = A_a * w_superheat;
	mdot_a_superheat = mdot_a * w_superheat;
	A_r_superheat = pi * ID * Ncircuits * Lcircuit * w_superheat;
	A_r_wetted = pi * ID * Ncircuits * Lcircuit ;
	
	Tin_r=Tsat_r+30;
	// Average fluid temps are used for the calculation of properties 
	// Average temp of refrigerant is average of sat. temp and outlet temp		
	// Secondary fluid is air over the fins
	f_h_1phase_Tube(mdot_r / Ncircuits, ID, (Tsat_r+Tin_r)/2.0, pout_r, Ref, "Single", &f_r_superheat, &h_r_superheat, &Re_r_superheat);
	cp_r = Props('C', 'T', (Tsat_r+Tin_r)/2, 'P', pout_r, Ref)*1000; //[J/kg-K]

	// Cross-flow in the superheated region.  
	// Using effectiveness-Ntu relationships for cross flow with non-zero Cr.
	UA_overall = 1 / (1 / (eta_a * h_a * A_a) + 1 / (h_r_superheat * A_r_wetted));
	NTU=UA_overall/(mdot_a*cp_a);
	Cr = (cp_a*mdot_a*w_superheat)/(cp_r*mdot_r);
	A=-Cr*(1-exp(-NTU));
	PSI=1-exp(A);
	Tin_r=(PSI*Tin_a-Tsat_r)/(PSI-1);

	////Test if the Tin_r is above the critical temperature and if it is, recompute using
	////the average specific heat capacity bewteen the critical temperature and the saturation
	////temperature
	//Tcric = Tcrit(Ref);
	//if(Tin_r>Tcric)
	//{
	//	UA_superheat = UA_overall*w_superheat;
	//	hsat_r = Props('H', 'T', Tsat_r, 'P', pout_r, Ref)*1000; //[J/kg]
	//	h_cric = Props('H','T',Tcric,'P', pout_r, Ref)*1000;  //[J/kg]
	//	cp_r = (h_cric - hsat_r)/(Tcric - Tsat_r); //[J/kg-K]
	//	Ntu_r = h_r_superheat * A_r_superheat/mdot_r/cp_r;
	//	epsilon_r = 1. - exp(-Ntu_r);
	//	Cr = cp_r*mdot_r / (cp_a*mdot_a_superheat);
	//	//HOWARDCHANGE
	//	if(Cr<1)
	//	{
	//		NTU = UA_superheat / (mdot_r*cp_r);
	//		Cmin = mdot_r*cp_r;
	//		epsilon_superheat = 1. - exp(-1. / Cr * (1. - exp(-Cr * NTU)));
	//	}
	//	else
	//	{
	//		Cr = 1/Cr;
	//		NTU = UA_superheat / (cp_a*mdot_a_superheat);
	//		Cmin = mdot_a_superheat*cp_a;
	//		epsilon_superheat = 1 / Cr * (1 - exp(-Cr * (1 - exp(-NTU))));
	//	}
	//	Tin_r = (mdot_r*cp_r*Tsat_r - epsilon_superheat*Cmin*Tin_a)/(mdot_r*cp_r - epsilon_superheat*Cmin);
	//};
	
	// Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	// Heat is removed here from the refrigerant since it is being cooled
	Q_superheat = mdot_r * cp_r * (Tsat_r-Tin_r);

	rho_superheat=Props('D', 'T', (Tin_r + Tsat_r) / 2, 'P', pout_r, Ref);
	//Pressure drop calculations for superheated refrigerant
	Dh_r=ID;																//[
	A_r=pi*Dh_r*Dh_r/4.0;
	G_r=mdot_r/((double)Ncircuits)/A_r;
	v_r=1/rho_superheat;
	//Pressure gradient using Darcy friction factor
	dpdz_r=-f_r_superheat*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
	Outputs.DP_superheat=dpdz_r*Lcircuit*w_superheat;

	// Latent heat needed for quality calc
	h_fg=(Props('H','T',Tsat_r,'Q',1.0,Ref)-Props('H','T',Tsat_r,'Q',0.0,Ref))*1000;

	Outputs.Q_superheat=Q_superheat;
	Outputs.Charge_superheat = w_superheat * V_r * rho_superheat;
	Outputs.Tin_r=Tin_r;
	Outputs.hin_r=Props('H','T',Tin_r,'P',pout_r,Ref)*1000;
	Outputs.h_superheat=h_r_superheat;
	Outputs.Re_superheat=Re_r_superheat;
	Outputs.xin_r=1.0+cp_r*(Tin_r-Tsat_r)/h_fg;
	Outputs.w_superheat=w_superheat;
}

static double Superheat_Forward()
{

	// ************************************************************************************
	//									SUPERHEATED PART 
	// ************************************************************************************

	double mdot_r,Vdot_a,Tin_a,pin_a,pout_r,Tsat_r,OD,ID,Lcircuit,V_r,h_a,A_a,eta_a,cp_a,mdot_a,
		A_a_superheat,mdot_a_superheat,A_r_superheat,f_r_superheat, h_r_superheat,UA_overall,
		Cr,NTU,Q_superheat,cp_r,Tin_r,f_a,dP_a,epsilon_r,epsilon_superheat,hsat_r,UA_superheat,
		Re_r_superheat,Dh_r,G_r,v_r,dpdz_r,A_r,A_r_wetted,A,PSI,Cmin,w_superheat,
		rho_superheat,h_fg,Tcric, h_cric,Ntu_r;
	int Ncircuits;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
    pin_a =		Inputs.pin_a;
    Tsat_r =	Inputs.Tsat_r;
	Tin_r =     Inputs.Tin_r;
	pout_r =	Props('P','T',Tsat_r,'Q',1.0,Ref);

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;

	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;
	A_r_wetted = pi * ID * Ncircuits * Lcircuit ;
	
	// Average fluid temps are used for the calculation of properties 
	// Average temp of refrigerant is average of sat. temp and outlet temp		
	// Secondary fluid is air over the fins
	f_h_1phase_Tube(mdot_r / Ncircuits, ID, (Tsat_r+Tin_r)/2.0, pout_r, Ref, "Single", &f_r_superheat, &h_r_superheat, &Re_r_superheat);
	cp_r = Props('C', 'T', (Tsat_r+Tin_r)/2, 'P', pout_r, Ref)*1000; //[J/kg-K]

	// Cross-flow in the superheated region.  
	// Using effectiveness-Ntu relationships for cross flow with non-zero Cr.
	UA_overall = 1. / (1. / (eta_a * h_a * A_a) + 1. / (h_r_superheat * A_r_wetted) );
	epsilon_superheat=(Tsat_r-Tin_r)/(Tin_a-Tin_r);
	w_superheat=-log(1-epsilon_superheat)*mdot_r*cp_r/((1-exp(-UA_overall/(mdot_a*cp_a)))*mdot_a*cp_a);

	////Test if the Tin_r is above the critical temperature and if it is, recompute using
	////the average specific heat capacity bewteen the critical temperature and the saturation
	////temperature
	//Tcric = Tcrit(Ref);
	//if(Tin_r>Tcric)
	//{
	//	UA_superheat = UA_overall*w_superheat;
	//	hsat_r = Props('H', 'T', Tsat_r, 'P', pout_r, Ref)*1000; //[J/kg]
	//	h_cric = Props('H','T',Tcric,'P', pout_r, Ref)*1000;  //[J/kg]
	//	cp_r = (h_cric - hsat_r)/(Tcric - Tsat_r); //[J/kg-K]
	//	Ntu_r = h_r_superheat * A_r_superheat/mdot_r/cp_r;
	//	epsilon_r = 1. - exp(-Ntu_r);
	//	Cr = cp_r*mdot_r / (cp_a*mdot_a_superheat);
	//	//HOWARDCHANGE
	//	if(Cr<1)
	//	{
	//		NTU = UA_superheat / (mdot_r*cp_r);
	//		Cmin = mdot_r*cp_r;
	//		epsilon_superheat = 1. - exp(-1. / Cr * (1. - exp(-Cr * NTU)));
	//	}
	//	else
	//	{
	//		Cr = 1/Cr;
	//		NTU = UA_superheat / (cp_a*mdot_a_superheat);
	//		Cmin = mdot_a_superheat*cp_a;
	//		epsilon_superheat = 1 / Cr * (1 - exp(-Cr * (1 - exp(-NTU))));
	//	}
	//	Tin_r = (mdot_r*cp_r*Tsat_r - epsilon_superheat*Cmin*Tin_a)/(mdot_r*cp_r - epsilon_superheat*Cmin);
	//};
	
	// Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	// Heat is removed here from the refrigerant since it is being cooled
	Q_superheat = mdot_r * cp_r * (Tsat_r-Tin_r);

	rho_superheat=Props('D', 'T', (Tin_r + Tsat_r) / 2, 'P', pout_r, Ref);
	//Pressure drop calculations for superheated refrigerant
	Dh_r=ID;																//[
	A_r=pi*Dh_r*Dh_r/4.0;
	G_r=mdot_r/((double)Ncircuits)/A_r;
	v_r=1/rho_superheat;
	//Pressure gradient using Darcy friction factor
	dpdz_r=-f_r_superheat*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
	Outputs.DP_superheat=dpdz_r*Lcircuit*w_superheat;

	// Latent heat needed for pseudo-quality calc
	h_fg=(Props('H','T',Tsat_r,'Q',1.0,Ref)-Props('H','T',Tsat_r,'Q',0.0,Ref))*1000;

	Outputs.Q_superheat=Q_superheat;
	Outputs.Charge_superheat = w_superheat * V_r * rho_superheat;
	Outputs.Tin_r=Tin_r;
	Outputs.hin_r=Props('H','T',Tin_r,'P',pout_r,Ref)*1000;
	Outputs.h_superheat=h_r_superheat;
	Outputs.Re_superheat=Re_r_superheat;
	Outputs.xin_r=1.0+cp_r*(Tin_r-Tsat_r)/h_fg;
	Outputs.w_superheat=w_superheat;
	return w_superheat;
}

static double TwoPhase_Forward(double InputVal)
{
	// ************************************************************************************
	//									TWO PHASE PART (FORWARD SOLVE)
	// ************************************************************************************

	// Assumed that there is a full two-phase region from quality of 1 to quality of 0.

	double mdot_r,Vdot_a,Tin_a,pin_a,pout_r,Tsat_r,OD,ID,Lcircuit,V_r,h_a,A_a,eta_a,cp_a,mdot_a,
		h_fg,G_r,h_r_2phase,epsilon_2phase,
		Q_2phase,f_a,dP_a,OutputValue,
		x1=0,x2=0,xin_r,w_2phase,v_g,v_f,UA_overall,A_r_wetted,
		DP_accel,alpha_in,dpdz_dummy,DP_frict,rhog,rhof,S,alpha_average,rho_average,C;
	int Ncircuits;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
    pin_a =		Inputs.pin_a;
    pout_r =	Inputs.pout_r;
    Tsat_r =	Inputs.Tsat_r;

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;
	xin_r = 1.0;
	
	// Total refrigerant side volume
	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;
	// Latent heat at given saturation temp
	// TODO: fix for refrigerants with glide
	h_fg = (Props('H','T',Tsat_r,'Q',1,Ref)-Props('H','T',Tsat_r,'Q',0,Ref))*1000; // [J/kg] 
	// Wetted area on refrigerant side
	A_r_wetted = pi * ID * Ncircuits * Lcircuit;
	// Refrigerant mass flux
	G_r = mdot_r / (Ncircuits * pi  * (ID*ID) / 4.0);

	// This block calculates the average refrigerant heat transfer coefficient by
	// integrating the local heat transfer coefficient between 
	// a quality of 0.0 and the inlet quality
	h_r_2phase=ShahCondensation_Average(Ref,G_r, ID, 0.0,xin_r,Tsat_r);

	UA_overall = 1 / (1 / (eta_a * h_a * A_a) + 1 / (h_r_2phase * A_r_wetted));
	epsilon_2phase=(1-exp(-UA_overall/(mdot_a*cp_a)));
	w_2phase=-mdot_r*h_fg/(mdot_a*cp_a*(Tin_a-Tsat_r)*epsilon_2phase);
	 
	//Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	//Heat is removed here from the refrigerant since it is condensing
	Q_2phase = epsilon_2phase *cp_a* mdot_a * w_2phase * (Tin_a-Tsat_r);
	
	// Find void fraction at inlet quality from Lockhart-Martinelli separated flow relation
	LockhartMartinelli(Ref, G_r, ID, xin_r, Tsat_r, &dpdz_dummy, &alpha_in);
	// Accelerational pressure drop component
	v_g=1./Props('D','T',Tsat_r,'Q',1.0,Ref);
	v_f=1./Props('D','T',Tsat_r,'Q',0.0,Ref);
	if (xin_r==0.0)
		DP_accel=G_r*G_r*(v_f-v_g);
	else if (xin_r==1.0)
		DP_accel=0.0;
	else
		DP_accel=G_r*G_r*((xin_r*xin_r/alpha_in*v_g+(1-xin_r)*(1-xin_r)*v_f/(1-alpha_in))-v_g);
	// Frictional pressure drop component
	DP_frict=LMPressureGradientAvg(Ref,G_r,ID,0.0,xin_r,Tsat_r)*Lcircuit*w_2phase;
			
	// Total pressure drop is the sum of accelerational and frictional components (neglecting gravitational effects)
	Outputs.DP_2phase=-(DP_frict+DP_accel);

	rhog=Props('D', 'T', Tsat_r, 'Q', 1, Ref);
	rhof=Props('D', 'T', Tsat_r, 'Q', 0, Ref);
	S=pow(rhof/rhog,0.3333);
	C=S*rhog/rhof;
	x1=xin_r;
	x2=0.0;
	if (x1==0.0)
		alpha_average=1.0;
	else
		/* 
		Obtained by taking the average of void fraction between inlet and outlet qualities
		*/
		alpha_average=-(C*(log( ((x2-1.0)*C-x2)/((x1-1.0)*C-x1) )+x2-x1)-x2+x1)/(C*C-2*C+1)/(x2-x1);
	rho_average= alpha_average*rhog + (1-alpha_average)*rhof;
	Outputs.Charge_2phase = rho_average * w_2phase * V_r;
	Outputs.Q_2phase=Q_2phase;
	Outputs.h_2phase=h_r_2phase;
	Outputs.xin_r=xin_r;
	Outputs.w_2phase=w_2phase;
	return w_2phase;
}

static double Subcooled_Forward(double w_subcool)
{
	double mdot_r,Vdot_a,Tin_a,Tout_r,pin_a,pout_r,Tsat_r,h_a,A_a,eta_a,cp_a,mdot_a,f_a,dP_a,OD,ID,Lcircuit,Ncircuits,
		V_r,A_a_subcool,mdot_a_subcool,A_r_subcool,f_r_subcool,h_r_subcool,cp_r,
		epsilon_subcool,Q_subcool,charge_subcool,rho_subcool,Re_r_subcool,
		Dh_r,A_r,G_r,v_r,dpdz_r,h_fg,Tin_r,UA_overall,A_r_wetted,Cmin,Cmax,Cr,NTU,UA_subcool;

	mdot_r =	Inputs.mdot_r;
    Vdot_a =	Inputs.Vdot_a;
    Tin_a =		Inputs.Tin_a;
    pin_a =		Inputs.pin_a;
    pout_r =	Inputs.pout_r;
    Tsat_r =	Inputs.Tsat_r;

    OD =		Inputs.OD;
    ID =		Inputs.ID;
    Lcircuit =	Inputs.Lcircuit;
    Ncircuits = Inputs.Ncircuits;

	h_a =		FinInputs.Fins.h_a;
	cp_a =		FinInputs.Fins.cp_a;
	A_a =		FinInputs.Fins.A_a;
	eta_a =		FinInputs.Fins.eta_a;
	mdot_a =	FinInputs.Fins.mdot_a;
	f_a =		FinInputs.Fins.f_a;
	dP_a =		FinInputs.Fins.dP_a;

	V_r = pi * ID*ID / 4.0 * Lcircuit * Ncircuits;

	// ************************************************************************************
	//									SUBCOOLED PART 
	// ************************************************************************************

	// Based on the the construction of the cycle model there is guaranteed to be a 
	// two-phase portion of the heat exchanger
	A_a_subcool = A_a * w_subcool;
    mdot_a_subcool = mdot_a * w_subcool;
	A_r_wetted = pi * ID * Ncircuits * Lcircuit;
    A_r_subcool =  A_r_wetted * w_subcool;

	// Friction factor and HTC in the refrigerant portions.
	// Average fluid temps are used for the calculation of properties 
	// Average temp of refrigerant is average of sat. temp and outlet temp
	// Secondary fluid is air over the fins

	f_h_1phase_Tube(mdot_r / Ncircuits, ID, Tsat_r-1, pout_r, Ref, 
		"Single", &f_r_subcool, &h_r_subcool, &Re_r_subcool);
	
    cp_r = Props('C', 'T', Tsat_r-1, 'P', pout_r, Ref)*1000;						//[J/kg-K]

	// Cross-flow in the subcooled region.
	UA_subcool = w_subcool / (1. / (eta_a * h_a * A_a) + 1. / (h_r_subcool * A_r_wetted) );
	Cmin=minVal(mdot_a*cp_a*w_subcool,mdot_r*cp_r);
	Cmax=maxVal(mdot_a*cp_a*w_subcool,mdot_r*cp_r);
	Cr=Cmin/Cmax;
	NTU=UA_subcool/Cmin;
	
	if(mdot_a*cp_a*w_subcool>mdot_r*cp_r)
	{
		epsilon_subcool = 1. - exp(-1. / Cr * (1. - exp(-Cr * NTU)));
	}
	else
	{
		epsilon_subcool = 1 / Cr * (1 - exp(-Cr * (1 - exp(-NTU))));
	}
	// Positive Q is heat input to the refrigerant, negative Q is heat output from refrigerant. 
	// Heat is removed here from the refrigerant since it is condensing
	Q_subcool=-epsilon_subcool*Cmin*(Tsat_r-Tin_a);
	Tout_r=Q_subcool/(mdot_r*cp_r)+Tsat_r;
	Inputs.Tout_r=Tout_r;
	Outputs.Tout_r=Tout_r;
	Outputs.DT_sc=-Q_subcool/(mdot_r*cp_r);
	
	rho_subcool=Props('D', 'T', (Tsat_r + Tout_r) / 2, 'P', pout_r, Ref);
	charge_subcool = w_subcool * V_r * rho_subcool;

	//Pressure drop calculations for subcooled refrigerant
	Dh_r=ID;																//[
	A_r=pi*Dh_r*Dh_r/4.0;
	G_r=mdot_r/((double)Ncircuits)/A_r;
	v_r=1/rho_subcool;
	//Pressure gradient using Darcy friction factor
	dpdz_r=-f_r_subcool*v_r*G_r*G_r/(2*Dh_r);  //Pressure gradient
	Outputs.DP_subcool=dpdz_r*Lcircuit*w_subcool;

	// See if the two-phase region exists. If the heat transferred is 
	// less than that required to bring to saturation temp, set the flag 
	// in the output structure to alert the external solver

	//if (Outputs.Exists_2phase==-1) // If not defined yet
	//{
	//	// If there is not enough heat transferred with the full area used for subcooled region
	//	if (w_subcool>1.0)
	//		Outputs.Exists_2phase=0; // There is no two-phase region
	//	else
	//		Outputs.Exists_2phase=1;//There is a two-phase (and maybe superheated) region
	//}
	
	
	// Latent heat needed for quality calc
	h_fg=(Props('H','T',Tsat_r,'Q',1.0,Ref)-Props('H','T',Tsat_r,'Q',0.0,Ref))*1000;
	Tin_r=Tout_r-Q_subcool/(mdot_r*cp_r);
	Outputs.xin_r=cp_r*(Tin_r-Tsat_r)/h_fg; //TODO: fix me
	Outputs.Charge_subcool=charge_subcool;
	Outputs.Q_subcool=Q_subcool;
	Outputs.h_subcool=h_r_subcool;
	Outputs.Re_subcool=Re_r_subcool;
	Outputs.hin_r=Outputs.hout_r-Q_subcool/mdot_r;

	return w_subcool;
}