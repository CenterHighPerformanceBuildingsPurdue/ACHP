
#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#include "string.h"
#include <stdio.h>

#include "PythonEntry.h"
#include "Props/CoolProp.h"
#include "RefCycleSolver.h"

//int SetFluids (const char * PrimaryRef, const char *SecondaryRef, struct CycleInputVals *Inputs)
//{
//	strcpy(Inputs->PrimaryRef,PrimaryRef);
//	strcpy(Inputs->SecondaryRef,SecondaryRef);
//}
int SecondaryCycle (struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs)
{
	if (!strcmp(Inputs->ImposedVariable,"Subcooling"))
	{
		if (!strcmp(Inputs->CycleType,"Secondary"))
			SecondarySolver_SubcoolImposed(0,Inputs, Outputs);
		else if (!strcmp(Inputs->CycleType,"DX"))
			DXSolver_SubcoolImposed(0,Inputs,Outputs);
		else
		{
			printf("Bad cycle type: %s\n",Inputs->CycleType);
			getchar();
			exit(EXIT_FAILURE);
		}

	}
	else if (!strcmp(Inputs->ImposedVariable,"Charge"))
	{
		if (!strcmp(Inputs->CycleType,"Secondary"))
			SecondarySolver_ChargeImposed(0,Inputs, Outputs);
		else if (!strcmp(Inputs->CycleType,"DX"))
			DXSolver_ChargeImposed(0,Inputs,Outputs);
		else
		{
			printf("Bad cycle type: %s\n",Inputs->CycleType);
			getchar();
			exit(EXIT_FAILURE);
		}
	}
	else
	{
		printf("Bad imposed variable\n");
		getchar();
		exit(EXIT_FAILURE);
	}

	return EXIT_SUCCESS;
}