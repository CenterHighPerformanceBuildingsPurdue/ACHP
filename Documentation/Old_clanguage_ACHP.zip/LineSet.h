
#ifndef LINESET_H
#define LINESET_H

struct LineSetInputVals
{
	// Refrigerant props
	double Tin;
	double pin;
	double mdot;

	// Geometry
	double L;
	double ID;
	double OD;
	double k_tube;
	double k_insul;
	double t_insul;
	double h_air;
	double T_air;
};

struct LineSetOutputVals
{
	double Q, DP, Tout,Re,h,hout,Charge;
};

int LineSet_Calculate(char *Ref, struct LineSetInputVals *Inputs, struct LineSetOutputVals *Outputs);

#endif