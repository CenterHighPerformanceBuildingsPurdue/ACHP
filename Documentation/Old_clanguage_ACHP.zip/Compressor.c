#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>

#include "string.h"
#include <stdio.h>
#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"
#include "Compressor.h"


int Compressor_Calculate(char * Ref, struct CompressorInputVals *Inputs, struct CompressorOutputVals *Outputs)
{
    double M[11], P[11], power_map, mdot_map, v_map,v_actual, F, P1, P2, T1_map, T1_actual, 
		Tsat_s, Tsat_d, h1_actual, h1_map, s1_map, s1_actual, h2s_map, h2s_actual,fp,power, 
		mdot, h1, h2, Td, Tsat_s_K, Tsat_d_K, DT_sh_K;

	Tsat_s_K=Inputs->Tsat_s;
	Tsat_d_K=Inputs->Tsat_d;
	DT_sh_K=Inputs->DT_sh;
	fp=Inputs->fp;

	M[1]=Inputs->M1;
	M[2]=Inputs->M2;
	M[3]=Inputs->M3;
	M[4]=Inputs->M4;
	M[5]=Inputs->M5;
	M[6]=Inputs->M6;
	M[7]=Inputs->M7;
	M[8]=Inputs->M8;
	M[9]=Inputs->M9;
	M[10]=Inputs->M10;

	P[1]=Inputs->P1;
	P[2]=Inputs->P2;
	P[3]=Inputs->P3;
	P[4]=Inputs->P4;
	P[5]=Inputs->P5;
	P[6]=Inputs->P6;
	P[7]=Inputs->P7;
	P[8]=Inputs->P8;
	P[9]=Inputs->P9;
	P[10]=Inputs->P10;

    //Convert saturation temperatures in K to F
		Tsat_s = Tsat_s_K * 9 / 5 - 456.67;
		Tsat_d = Tsat_d_K * 9 / 5 - 456.67;

	//Apply the 10 coefficient ARI map to saturation temps in F
		power_map = P[1] + P[2] * Tsat_s + P[3] * Tsat_d + P[4] * Tsat_s*Tsat_s + P[5] * Tsat_s * Tsat_d + P[6] * Tsat_d*Tsat_d + P[7] * Tsat_s*Tsat_s*Tsat_s + P[8] * Tsat_d * Tsat_s*Tsat_s + P[9] * Tsat_d*Tsat_d*Tsat_s + P[10] * Tsat_d*Tsat_d*Tsat_d;
		mdot_map = M[1] + M[2] * Tsat_s + M[3] * Tsat_d + M[4] * Tsat_s*Tsat_s + M[5] * Tsat_s * Tsat_d + M[6] * Tsat_d*Tsat_d + M[7] * Tsat_s*Tsat_s*Tsat_s + M[8] * Tsat_d * Tsat_s*Tsat_s + M[9] * Tsat_d*Tsat_d*Tsat_s + M[10] * Tsat_d*Tsat_d*Tsat_d;

    // Convert mass flow rate to kg/s from lbm/h
		mdot_map *= 0.000125998; 

	// Add more mass flow rate to scale
		mdot_map*=Inputs->Vdot_ratio;
		power_map*=Inputs->Vdot_ratio;

	P1 = Props('P', 'T', Tsat_s_K,'Q',1.0,Ref);
    P2 = Props('P', 'T', Tsat_d_K,'Q',1.0,Ref);
    T1_actual = Tsat_s_K + DT_sh_K;

    v_map = 1 / Props('D', 'T', Tsat_s_K + 20.0/9.0*5.0, 'P', P1, Ref);
    v_actual = 1 / Props('D', 'T', Tsat_s_K + DT_sh_K, 'P', P1, Ref);
    F = 0.75;
    mdot = (1 + F * (v_map / v_actual - 1)) * mdot_map;

    T1_map = Tsat_s_K + 20 * 5 / 9;
    s1_map = Props('S', 'T', T1_map, 'P', P1, Ref);
    h1_map = Props('H', 'T', T1_map, 'P', P1, Ref);
    h2s_map = h_sp(Ref, s1_map, P2, T1_map + 40); //'+20 for guess value

    s1_actual = Props('S', 'T', T1_actual, 'P', P1, Ref);
    h1_actual = Props('H', 'T', T1_actual, 'P', P1, Ref);
    h2s_actual = h_sp(Ref, s1_actual, P2, T1_actual + 40); //'+20 for guess value

    //'Shaft power based on 20F superheat calculation from fit overall isentropic efficiency
    power = power_map * (mdot / mdot_map) * (h2s_actual - h1_actual) / (h2s_map - h1_map);

    h2 = power/1000 * (1 - fp) / mdot + h1_actual;
    Td = T_hp(Ref, h2, P2, T1_map + 20); //'Plus 20 for guess value for discharge temp

    h1 = h1_actual;

    Outputs->h1 = h1_actual*1000;									//[J/kg]
    Outputs->h2 = h2*1000;											//[J/kg]
    Outputs->mdot = mdot;											//[kg/s]
    Outputs->power = power;											//[W]
    Outputs->Td = Td;												//[K]
	Outputs->s1=Props('S','T',T1_actual,'P',P1,Ref)*1000.0;			//[J/kg-K]
	Outputs->s2=Props('S','T',Td,'P',P2,Ref)*1000.0;				//[J/kg-K]

	return 0;
}