#ifndef SOLVERS_H
#define SOLVERS_H

double Dekker(double(*fptr)(double),double x_min, double x_max, double eps);

#endif