#ifndef MATINV_H
#define MATINV_H
	
	void migs (double a[100][100],int n, double x[100][100],int indx[]);

#endif