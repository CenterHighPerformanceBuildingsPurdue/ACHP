#ifndef EVAPORATOR_H
#define EVAPORATOR_H

#include "Correlations.h"

struct EvaporatorInputVals
{
	double Tout_r;
	double mdot_r;
	double pout_r;
	double Tsat_r;
	double xin_r;
	double h_r;
	double hin_a;
	double DT_sh;

	double Vdot_a;
	double pin_a;
	double Tin_a;
	double RHin_a;

	double RHout_superheat;
	double Tdbout_superheat;
	double haout_superheat;

	double RHout_2phase;
	double Tdbout_2phase;
	double haout_2phase;

	// Geometric Parameters
	double OD; // Outer diameter of the outer annulus (at inside of outer wall)
	double ID; // Outer diameter of the outer annulus (at inside of outer wall)
	double Lcircuit; //Average Length of a single circuit
	int Ncircuits;
	double FanPower;
	char Mode[255];
};
struct EvaporatorOutputVals
{
	
	double Q;
	double Q_superheat;
	double Q_2phase;
	double Q_subcool;

	double Charge;
	double Charge_superheat;
	double Charge_2phase;
	double Charge_subcool;

	double DP;
	double DP_superheat;
	double DP_2phase;
	double DP_subcool;


	double f_dry;

	double DT_sh;
	double Tout_r;
	double Tout_a;
	double hout_a;
	double hin_a;
	double hin_r;
	double sin_r;
	double sout_r;
	double xin_r;
	double Tin_r;
	double hout_r;
	double SHR;
	double DP_g;
	
	double Re_superheat;
	double Re_subcool;
	double h_superheat;
	double h_2phase;
	double h_subcool;
	double w_superheat;
	double w_2phase;
	double w_subcool;
	int ExistsSubcool;

	double omega_out;
	double omega_shout;
	double omega_tpout;
};


int Evaporator_Calculate(char *Ref_, struct FinHTCDPInputsVals *FinInputs_, struct EvaporatorInputVals *Inputs_, struct EvaporatorOutputVals *Outputs_);


#endif