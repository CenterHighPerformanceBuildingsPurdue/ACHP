#ifndef CONDENSER_H
#define CONDENSER_H

#include "Correlations.h"

struct CondenserInputVals
{
	double Tin_r;
	double Tout_r;
	double mdot_r;
	double pout_r;
	double Tsat_r;

	double Vdot_a;
	double pin_a;
	double Tin_a;
	double RHin_a;

	// Geometric Parameters
	double OD; // Outer diameter of the outer annulus (at inside of outer wall)
	double ID; 
	double Lcircuit; //Average Length of a single circuit
	int Ncircuits;
	double FanPower;
	char Mode[255];
};
struct CondenserOutputVals
{
	double Charge;
	double Charge_subcool;
	double Charge_2phase;
	double Charge_superheat;
	double Q;
	double Q_superheat;
	double Q_2phase;
	double Q_subcool;
	double h_superheat;
	double h_2phase;
	double h_subcool;
	double Re_superheat;
	double Re_2phase;
	double Re_subcool;

	double w_superheat;
	double w_2phase;
	double w_subcool;

	double DP;
	double DP_superheat;
	double DP_subcool;
	double DP_2phase;

	double Aireta_a;
	double Airh_a;
	double Airmdot_a;
	double AirA_a;

	double DT_sc;
	double Tout_r;
	double Tin_r;
	double hout_r;
	double xout_r;
	double xin_r;
	double hin_r;
	double sin;
	double sout;
	int phase_out;
	int Exists_superheat;
	int Exists_2phase;
};

int Condenser_Calculate(char *Ref_, struct FinHTCDPInputsVals *FinInputs_, struct CondenserInputVals *Inputs_, struct CondenserOutputVals *Outputs_);

#endif
