#include "Correlations.h"
#include "Compressor.h"
#include "Condenser.h"
#include "IHX.h"
#include "IndoorCoil.h"
#include "Pump.h"
#include "Evaporator.h"
#include "LineSet.h"
#include "PythonEntry.h"

#ifndef SUBCOOL
#define SUBCOOL 1
#endif

#ifndef CHARGE
#define CHARGE 2
#endif

#ifndef CYCLETYPE_SECONDARY
#define CYCLETYPE_SECONDARY 1
#endif

#ifndef CYCLETYPE_DX
#define CYCLETYPE_DX 2
#endif

#ifndef FUNC_FAILED
#define FUNC_FAILED -1
#endif


#ifndef REFCYCLESOLVER_H
#define REFCYCLESOLVER_H

	static int runFail;
	static char runFailString[1000];

	struct CycleVals
	{
		char ImposedVariable[255];
		double Charge;
		int CycleType;
		char PrimaryRef[255];
		char SecondaryRef[255];
		double DT_subcool;
		double Qnominal;
		double DTsubcoolImposed;
		double ChargeImposed;
	};

	struct runVals
	{
		struct CompressorInputVals CompressorInputs;
		struct CompressorOutputVals CompressorOutputs;
		
		struct IHXInputVals IHXInputs;
		struct IHXOutputVals IHXOutputs;

		struct LineSetInputVals LineSetSupplyInputs;
		struct LineSetOutputVals LineSetSupplyOutputs;
		struct LineSetInputVals LineSetReturnInputs;
		struct LineSetOutputVals LineSetReturnOutputs;

		struct FinHTCDPInputsVals CondFinInputs;
		struct CondenserInputVals CondenserInputs;
		struct CondenserOutputVals CondenserOutputs;
		
		struct FinHTCDPInputsVals IndoorCoilFinInputs;
		struct IndoorCoilInputVals IndoorCoilInputs;
		struct IndoorCoilOutputVals IndoorCoilOutputs;
		struct PumpInputVals PumpInputs;
		
		struct FinHTCDPInputsVals EvaporatorFinInputs;
		struct EvaporatorInputVals EvaporatorInputs;
		struct EvaporatorOutputVals EvaporatorOutputs;

		struct CycleVals Cycle;
	};

	int loadRunStruct(struct CycleInputVals *Inputs, struct runVals *run);
	int Cycle_Calculate(char *PrimaryRef, char *SecondaryRef, struct runVals *run,double Ts_cond, double DT_subcool, double Ts_IHX, double *r );
	int SecondarySolver_ChargeImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs);
	int SecondarySolver_SubcoolImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs);
	void DXSolver_SubcoolImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs);
	void DXSolver_ChargeImposed(int runType, struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs);
	void outputCondenserInputs(struct runVals *run);
	void outputIndoorCoilInputs(struct runVals *run);
	void outputIHXInputs(struct runVals *run);
	void outputCycleInputs(struct runVals *run);

#endif