#if defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <crtdbg.h>
#else
#include <stdlib.h>
#endif

#define pi 3.14159265358979323846
#include <math.h>

#include "string.h"
#include <stdio.h>
#include "Props/CoolProp.h"
#include "Props/HumAir.h"
#include "Correlations.h"

double maxVal(double x1, double x2)
{
	if (x1>x2)
		return x1;
	else
		return x2;
}

double ShahEvaporation_Average(char *Ref, double G, double D, double x_min, double x_max, double T, double q_flux)
{
	int Navg,i;
	double dx,x,h,h_corr;
	Navg = 50;
	dx = (x_max - x_min) / (Navg - 1);
	x=x_min;
	h = 0.0;
	for(i=1;i<=Navg;i++)
	{
		h_corr= ShahEvaporation(Ref,G, D, x, T, q_flux);
		if (i>0 && i<Navg-1)
		{
			h += 2*h_corr;
		}
		else
		{
			h += h_corr;
		}
		x += dx;
	}
	return h / (2*(Navg-1));
}

double ShahEvaporation(char * Ref, double G, double D, double x, double T, double q_flux)
{
	double v_g, v_f, rho_f, rho_g, mu_f, h_fg, cp_f, k_f, Pr_f;
	double mu_g,cp_g,k_g,Pr_g,h_g;
    double psi_bs, psi_cb, psi_nb, psi, g_grav;
	double Co, Fr_L, Bo, N, F, h_L;

        // ********************************
        //        Necessary Properties
        // ********************************
        v_g = 1 / Props('D', 'T', T, 'Q', 1, Ref); // [m^3/kg]
        v_f = 1 / Props('D', 'T', T, 'Q', 0, Ref); // [m^3/kg]
        rho_f = 1 / v_f; // [kg/m^3]
        rho_g = 1 / v_g; // [kg/m^3]
        mu_f = Props('V', 'T', T, 'Q', 0, Ref); // [kg/m-s] 
		mu_g = Props('V', 'T', T, 'Q', 1, Ref); // [kg/m-s] 
        h_fg = (Props('H', 'T', T, 'Q', 1, Ref) - Props('H', 'T', T, 'Q', 0, Ref))*1000; //[J/kg] (conversion from kJ/kg-K to kJ/kg-K)
        cp_f = Props('C', 'T', T, 'Q', 0, Ref)*1000; // [J/kg-K] (conversion from kJ/kg-K to kJ/kg-K)
		cp_g = Props('C', 'T', T, 'Q', 1, Ref)*1000; // [J/kg-K] (conversion from kJ/kg-K to kJ/kg-K)
        k_f = Props('L', 'T', T, 'Q', 0, Ref)*1000; // [W/m-K] (conversion from kW/m-K to W/m-K)
		k_g = Props('L', 'T', T, 'Q', 1, Ref)*1000; // [W/m-K] (conversion from kW/m-K to W/m-K)
        Pr_f = cp_f * mu_f / k_f; //[-]
		Pr_g = cp_g * mu_g / k_g; //[-]

        g_grav = 9.81; //[m/s^2]

        // Shah evaporation correlation
        Co = pow(1 / x - 1,0.8) * sqrt(rho_g / rho_f);		//[-]
        Fr_L = G*G / (rho_f*rho_f * g_grav * D);			//[-]
        Bo = q_flux / (G * h_fg);							//[-]

		// Pure vapor single-phase heat transfer coefficient

		h_g = 0.023 * pow(G * x * D / mu_g, 0.8) * pow(Pr_g,0.4) * k_g / D; //[W/m^2-K]
		if (x>0.999999999999)
		{
			return h_g;
		}

		h_L = 0.023 * pow(G * (1 - x) * D / mu_f, 0.8) * pow(Pr_f,0.4) * k_f / D; //[W/m^2-K]

        if (Bo > 0.0011)
            F = 14.7;
		else
            F = 15.43;

		if (Fr_L >= 0.04)
            N = Co;
		else
            N = 0.38 * pow(Fr_L,-0.3) * Co;

        psi_cb = 1.8 / pow(N,0.8);
        if (0.1 < N && N <= 1.0)
		{
            psi_bs = F * sqrt(Bo) * exp(2.74 * pow(N,-0.1));
            psi = maxVal(psi_bs, psi_cb);
		}
        else
		{
            if (N > 1.0)
			{
                if (Bo > 0.00003)
                    psi_nb = 230 * sqrt(Bo);
                else
                    psi_nb = 1.0 + 46.0 * sqrt(Bo);
                psi = maxVal(psi_nb,psi_cb);
			}
            else
			{
                psi_bs = F * sqrt(Bo) * exp(2.47 * pow(N ,-0.15));
                psi = maxVal(psi_bs, psi_cb);
			}
		}
        return psi * h_L; //[W/m^2-K]
}

double ShahCondensation_Average(char *Ref, double G, double D, double x_min, double x_max, double T)
{
	int Navg,i;
	double dx,x,h,h_c;
	Navg = 30;
	dx = (x_max - x_min) / (Navg - 1);
	x=x_min;
	h = 0.0;
	for(i=1;i<=Navg;i++)
	{
		h_c=ShahCondensation(Ref,G, D, x, T);
		
		// Do a trapezoidal integration, so the interior points
		// get twice the weight, and the edge points of the range
		// get a single weight
		if (i>0 && i<Navg-1)
		{
			h += 2*h_c;
		}
		else
		{
			h += h_c;
		}
		x += dx;
	}
	return h / (2.0*((double)Navg-1.0));
}


double ShahCondensation(char *Ref, double G, double  D, double x, double T)
{

    double  v_g, v_f, rho_f, rho_g, mu_f, h_fg, cp_f, k_f, Pr_f,p,Pstar, h_L;

    // ********************************
    //        Necessary Properties
    // ********************************
    v_g = 1 / Props('D', 'T', T, 'Q', 1, Ref); // %m^3/kg
    v_f = 1 / Props('D', 'T', T, 'Q', 0, Ref); // %m^3/kg
    rho_f = 1 / v_f; // %kg/m^3
    rho_g = 1 / v_g; // %kg/m^3
    mu_f = Props('V', 'T', T, 'Q', 0, Ref); // %kg/m-s 
    h_fg = (Props('H', 'T', T, 'Q', 1, Ref) - Props('H', 'T', T, 'Q', 0, Ref))*1000; //%J/kg
    cp_f = Props('C', 'T', T, 'Q', 0, Ref)*1000; // %J/kg-K
    k_f = Props('L', 'T', T, 'Q', 0, Ref)*1000; // %W/m-K
    Pr_f = cp_f * mu_f / k_f; //[-]
	p=Props('P','T',T,'Q',0.5,Ref); // Use the average in the case that you have refrigerant with glide

    Pstar = p / pcrit(Ref);

    h_L = 0.023 * pow(G * D / mu_f,0.8) * pow(Pr_f,0.4) * k_f / D; //[W/m^2-K]
    return h_L * (pow(1 - x,0.8) + (3.8 * pow(x,0.76) * pow(1 - x,0.04)) / (pow(Pstar, 0.38)) );
}

void f_h_1phase_Tube(double mdot, double ID, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re)
{
    f_h_1phase_Annulus(mdot, ID, 0.0, T, p, Fluid, Phase, f, h, Re);
}

void f_h_1phase_Channel(double mdot, double W, double H, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re, double *Dh)
{
	double mu, cp, k, Pr, e_D, A, B, Nu, rho, Area, u;

    if (!strcmp(Phase, "SatVap"))
	{
        mu = Props('V', 'T', T, 'Q', 1, Fluid); //kg/m-s
        cp = Props('C', 'T', T, 'Q', 1, Fluid)*1000; //J/kg-K
        k = Props('L', 'T', T, 'Q', 1, Fluid)*1000; //W/m-K
		rho = Props('D', 'T', T, 'Q', 1, Fluid); //kg/m^3
	}
    else
	{
        mu = Props('V', 'T', T, 'P', p, Fluid); //kg/m-s
        cp = Props('C', 'T', T, 'P', p, Fluid)*1000; //J/kg-K
        k = Props('L', 'T', T, 'P', p, Fluid)*1000; //W/m-K
		rho = Props('D', 'T', T, 'P', p, Fluid); //kg/m^3
	}

    Pr = cp * mu / k; //[-]

    *Dh = 2*H*W/(H+W);
	Area=W*H;
	u=mdot/(Area*rho);
	*Re=rho*u*(*Dh)/mu;

    // Friction factor of Churchill (Darcy Friction factor where f_laminar=64/Re)
    e_D = 0;
    A = pow((-2.457 * log( pow(7.0 / *Re,0.9) + 0.27 * e_D)),16);
    B = pow(37530.0 / *Re,16);
    *f = 8 * pow(pow(8.0/ *Re,12.0) + 1 / pow(A + B,1.5),1.0/12.0);

    // Heat Transfer coefficient of Gnielinski for high Re, 
	if (*Re>1000)
		Nu = (*f / 8) * (*Re - 1000) * Pr / (1 + 12.7 * sqrt(*f / 8) * (pow(Pr,0.66666) - 1)); //[-]
	else
		Nu = 3.66;
    *h = k * Nu / *Dh; //W/m^2-K
}


void f_h_1phase_Annulus(double mdot, double OD, double ID, double T, double p, char *Fluid, char *Phase, double *f, double *h, double *Re)
{
	double mu, cp, k, Pr, Dh, e_D, A, B, Nu, rho, Area, u;

    if (!strcmp(Phase, "SatVap"))
	{
        mu = Props('V', 'T', T, 'Q', 1, Fluid); //kg/m-s
        cp = Props('C', 'T', T, 'Q', 1, Fluid)*1000; //J/kg-K
        k = Props('L', 'T', T, 'Q', 1, Fluid)*1000; //W/m-K
		rho = Props('D', 'T', T, 'Q', 1, Fluid); //kg/m^3
	}
    else
	{
        mu = Props('V', 'T', T, 'P', p, Fluid); //kg/m-s
        cp = Props('C', 'T', T, 'P', p, Fluid)*1000; //J/kg-K
        k = Props('L', 'T', T, 'P', p, Fluid)*1000; //W/m-K
		rho = Props('D', 'T', T, 'P', p, Fluid); //kg/m^3
	}

    Pr = cp * mu / k; //[-]

    Dh = OD - ID;
	Area=pi*(OD*OD-ID*ID)/4.0;
	u=mdot/(Area*rho);
	*Re=rho*u*Dh/mu;

    // Friction factor of Churchill (Darcy Friction factor where f_laminar=64/Re)
    e_D = 0;
    A = pow((-2.457 * log( pow(7.0 / *Re,0.9) + 0.27 * e_D)),16);
    B = pow(37530.0 / *Re,16);
    *f = 8 * pow(pow(8.0/ *Re,12.0) + 1 / pow(A + B,1.5),1.0/12.0);

    // Heat Transfer coefficient of Gnielinski
    Nu = (*f / 8) * (*Re - 1000) * Pr / (1 + 12.7 * sqrt(*f / 8) * (pow(Pr,0.66666) - 1)); //[-]
    *h = k * Nu / Dh; //W/m^2-K
}
//void DP_HTC_PHE()
//{
//	if (!strcmp(Phase, "SatVap"))
//	{
//        mu = Props('V', 'T', T, 'Q', 1, Fluid); //kg/m-s
//        cp = Props('C', 'T', T, 'Q', 1, Fluid)*1000; //J/kg-K
//        k = Props('L', 'T', T, 'Q', 1, Fluid)*1000; //W/m-K
//		rho = Props('D', 'T', T, 'Q', 1, Fluid); //kg/m^3
//	}
//    else
//	{
//        mu = Props('V', 'T', T, 'P', p, Fluid); //kg/m-s
//        cp = Props('C', 'T', T, 'P', p, Fluid)*1000; //J/kg-K
//        k = Props('L', 'T', T, 'P', p, Fluid)*1000; //W/m-K
//		rho = Props('D', 'T', T, 'P', p, Fluid); //kg/m^3
//	}
//	Re=rho*u*D_H/mu;
//	Nu_h=0.122*pow(Pr,0.333)*pow(mu/mu_w,1.0/6.0)*pow(zeta*Re_h*Re_h*sin(2*phi),0.374);
//	Nu=Nu_h*Phi
//}

void WavyFins(struct FinHTCDPInputsVals *Inputs)
{
    double D, Re_D, s, Af, A_1fin, Ac, t, Pt, Pl, pd, xf, j_3, j, Pr, D_hv, 
		Ltube, A_duct, FPI, FPM, mu_ha,Temp, Tdp, p, W, RH, v, RHin,Vdot_ha, 
		umax, rho_ha, k_ha, h_ha,Tfilm,Sl,St,f_tube,f_fin,pf,G_c,sec_theta, 
		beta, sigma, Nu_l, uduct, Height, k_fin, r, rf_r, X_T, X_D, m, phi, 
		eta_f,h_a,eta_o,A,mdot_ha,cp_ha,fa_total,DeltaP_air,cs_cp;
	int Ntubes_bank, Nfin, Nbank;
    //|| -    xf    ->
    //'^              ==                          ==
    //'|           ==  |  ==                  ==
    //'Pd       ==     |     ==            ==
    //'|     ==        |        ==     ==
    //'=  ==           s             ==  
    //'                |
    //'                |
    //'                |
    //'               ==                          ==
    //'            ==     ==                  ==
    //'         ==           ==            ==
    //'      ==                 ==     ==
    //'   ==                        ==  
    //'
    //' t: thickness of fin plate
    //' Pf: fin pitch (centerline-to-centerline distance between fins)
    //' Pd: indentation for waviness (not including fin thickness)
    //' s: fin spacing (free space between fins) = Pf-t
    //'
    //'
    //'
    //'             |--       Pl      -|
    //'            ___                 |
    //'          /     \               |
    //'   =     |       |              |
    //'   |      \ ___ /               |
    //'   |                            |
    //'   |                           ___      
    //'   |                         /     \      |
    //'  Pt                        |       |     D
    //'   |                         \ ___ /      |
    //'   |    
    //'   |        ___
    //'   |      /     \
    //'   =     |       |
    //'          \ ___ /
    //'          

    //'Default parameters

	//''Tube parameters
    //'Ntubes_bank = 41  'Tubes per bank
    //'Nbank = 1 ' Number of tube banks
    //'Ltube = 2.286 '[m]
    //'D = 0.007 'tube OD
    //'Pl = 0.01905 ' Horizontal Spacing between banks (center to center)
    //'Pt = 0.022225 ' vertical spacing between tubes in a bank (center to center)

	//''Fin parameters
    //'FPI = 25
    //'pd = 0.001
    //'xf = 0.001
    //'t = 0.00011
    //'k_fin = 237 'W/m-K

	//''Air inlet state
    //'Vdot_ha = 1.7934
    //'Temp = 308.15 '95 F to K
    //'p = 101.325
    //'RHin = 0.5

    Ntubes_bank = Inputs->Tubes.Ntubes_bank; //'tubes per bank
    Nbank = Inputs->Tubes.Nbank; //'Number of banks
    Ltube = Inputs->Tubes.Ltube; //'length of a single tube
    D = Inputs->Tubes.D; //'Outer diameter of tube
    Pl = Inputs->Tubes.Pl; //'Horizontal spacing between banks (center to center)
    Pt = Inputs->Tubes.Pt; //'Vertical spacing between tubes in a bank (center to center)

    FPI = Inputs->Fins.FPI;
    pd = Inputs->Fins.Pd;
    xf = Inputs->Fins.xf;
    t = Inputs->Fins.t;
    k_fin = Inputs->Fins.k_fin;

    Vdot_ha = Inputs->Air.Vdot_ha;
    Temp = Inputs->Air.Tdb;
    p = Inputs->Air.p;
    RHin = Inputs->Air.RH;

	// Check that cs_cp is defined, if so, set it to the value passed in
	if (Inputs->Air.cs_cp>0.01 && Inputs->Air.cs_cp<5)
	{
		cs_cp=1.0;//Inputs->Air.cs_cp;
	}
	else
	{
		cs_cp=1.0;
	}

    Tfilm = Temp;
    FPM = FPI / 0.0254;
    s = 1 / FPM - t;

    //'Data from Kim 1999 for staggered tube HX
    Height = Pt * (Ntubes_bank + 0.5);
    A_duct = Pt * (Ntubes_bank + 0.5) * Ltube;
    Nfin = (int)(Ltube * FPM);
    Ac = A_duct - t * Nfin * Height - Ntubes_bank * D * Ltube;

    HumAir(Temp, p, GIVEN_RH, RHin, &Tdp, &W, &h_ha, &RH, &v);
    rho_ha = (1 + W) / v;

    mdot_ha = Vdot_ha * rho_ha;
    umax = mdot_ha / (rho_ha * Ac);
    uduct = mdot_ha / (rho_ha * A_duct);

    //'Assuming the transport properties of humid air to be close to dry air (generally error <1%)
    mu_ha = (0.00002082 - 0.00001846) / (350 - 300) * (Tfilm - 300) + 0.00001846; //'[Pa-s]
    k_ha = (0.03 - 0.0263) / (350 - 300) * (Tfilm - 300) + 0.0263;   //'[W/m-K]

    //'Humid air enthalpy taken as mass weighted average of saturated vapor and dry air
    cp_ha = (1.005 + W * 1.814) / (1 + W) * 1000;
    Pr = cp_ha * mu_ha / k_ha;

    Re_D = rho_ha * umax * D / mu_ha;

    j_3 = 0.394 * pow(Re_D,-0.357) * pow(Pt / Pl,-0.272) * pow(s / D,-0.205) * pow(xf / pd,-0.558) * pow(pd / s,-0.133);
    if (Nbank < 3)
	{
        if (Re_D >= 1000)
            j = j_3 * (0.978 - 0.01 * Nbank);
        else
            j = j_3 * (1.35 - 0.162 * Nbank);
	}
    else
        j = j_3;

    beta = pi * D*D / (4 * Pl * Pt);
    sigma = s / (s + t);
    sec_theta = sqrt(xf*xf + pd*pd) / xf;
    D_hv = 2 * s * (1 - beta) / ((1 - beta) * sec_theta + 2 * s * beta / D);

    Nu_l = j * Re_D * pow(Pr,0.333333) * D_hv / D;
    h_a = Nu_l * k_ha / D_hv;

    //'Fin efficiency based on analysis in 
    //' "FIN EFFICIENCY CALCULATION IN ENHANCED FIN-AND-TUBE HEAT EXCHANGERS IN DRY CONDITIONS"
    //' by Thomas PERROTIN, Denis CLODIC, International Congress of Refrigeration 2006
    r = D / 2;
    X_D = sqrt(Pl*Pl + Pt*Pt / 4) / 2;
    X_T = Pt / 2;
    rf_r = 1.27 * X_T / r * sqrt(X_D / X_T - 0.3);
    m = sqrt(2 * h_a * cs_cp/ (k_fin * t));
    phi = (rf_r - 1) * (1 + 0.35 * log(rf_r));
    eta_f = tanh(m * r * phi) / (m * r * phi); //'* Math.Cos(m * r * phi)

    A_1fin = 2.0 * (Height * Pl * Nbank * sec_theta - Ntubes_bank * Nbank * pi * D*D / 4);   //'Wetted Area of a single fin
    Af = Nfin * A_1fin;
    A = Af + Ntubes_bank * Nbank * pi * D * Ltube;
    eta_o = 1 - Af / A * (1 - eta_f);

	//Define parameters
	St=Pt;
	Sl=Pl;
	pf=1.0/FPM;
    f_tube = 4 / pi * (0.25 + 0.118 / pow(St/D - 1.0,1.08) * pow(Re_D,-0.16)) * (St/D - 1.0);
	f_fin = 1.455 * pow(Re_D, -0.656) * pow(St / Sl, -0.347) * pow(s / D, -0.134) * pow(St / D, 1.23);
    fa_total = f_fin * (Af / A) + f_tube * (1 - Af / A) * (1 - t / pf);
	G_c=mdot_ha/Ac;
	DeltaP_air=fa_total*( A/Ac)*(G_c*G_c)/rho_ha;

	Inputs->Fins.A_a=Af;
	Inputs->Fins.cp_a=cp_ha;
	Inputs->Fins.eta_a=eta_o;
	Inputs->Fins.h_a=h_a;
	Inputs->Fins.mdot_a=mdot_ha;
	Inputs->Fins.f_a=fa_total;
	Inputs->Fins.dP_a=DeltaP_air;

	//printf("dpA%g Pa\n",DeltaP_air);
}


double LMPressureGradientAvg(char *Ref, double G, double D, double x_min, double x_max, double T)
{
	int Navg,i;
	double dx,x,h,dpdz,alpha;
	Navg = 30;
	dx = (x_max - x_min) / (Navg - 1);
	x=x_min;
	h = 0.0;
	for(i=1;i<=Navg;i++)
	{
		LockhartMartinelli(Ref,G, D, x, T, &dpdz,&alpha);
		if (i>0 && i<Navg-1)
		{
			h += 2*dpdz;
		}
		else
		{
			h += dpdz;
		}
		x += dx;
	}
	return h / (2*(Navg-1));
}

void LockhartMartinelli(char *Ref, double G, double D, double x, double Tsat, double *dpdz, double *alpha)
{
	//Following the method laid out in ME506 notes on Separated Flow pressure drop calculations

	double mu_f,mu_g,f_f,f_g,v_g,v_f,Re_g,Re_f,w,dpdz_f,dpdz_g,X,C,phi_f2,phi_g2;

	// Necessary saturation properties
		v_f=1./Props('D','T',Tsat,'Q',0.0,Ref);
		v_g=1./Props('D','T',Tsat,'Q',1.0,Ref);
		mu_f=Props('V','T',Tsat,'Q',0.0,Ref);
		mu_g=Props('V','T',Tsat,'Q',1.0,Ref);

		
	// 1. Find the Reynolds Number for each phase based on the actual flow rate of the individual phase
		Re_g=G*x*D/mu_g;
		Re_f=G*(1-x)*D/mu_f;

	// 2. Friction factor for each phase
		if (Re_f<1000) //Laminar
			f_f=16.0/Re_f;
		else if (Re_f>2000) //Fully-Turbulent
			f_f=0.046/pow(Re_f,0.2);
		else // Mixed
		{	
			// Weighting factor
			w=(Re_f-1000)/(2000-1000);

			// Linear interpolation between laminar and turbulent
			f_f=w*16.0/Re_f+(1-w)*0.046/pow(Re_f,0.2);
		}

		if (Re_g<1000) //Laminar
			f_g=16.0/Re_g;
		else if (Re_g>2000) //Fully-Turbulent
			f_g=0.046/pow(Re_g,0.2);
		else // Mixed
		{
			// Weighting factor
			w=(Re_g-1000)/(2000-1000);
			
			// Linear interpolation between laminar and turbulent
			f_g=w*16.0/Re_g+(1-w)*0.046/pow(Re_g,0.2);
		}

	// 3. Frictional pressure drop based on actual flow rate of each phase
		dpdz_f=2*f_f*G*G*(1.-x)*(1.-x)*v_f/D;
		dpdz_g=2*f_g*G*G*x*x*v_g/D;

		if (x<=0)
		{
			// Entirely liquid
			*alpha=0.0;
			*dpdz=dpdz_f;
			return;
		}
		else if (x>=1.0)
		{
			//Entirely vapor
			*alpha=1.0;
			*dpdz=dpdz_g;
			return;
		}

	// 4. Lockhart-Martinelli parameter
		X=sqrt(dpdz_f/dpdz_g);

	// 5. Find the Constant based on the flow Re of each phase
		// (using 1500 as the transitional Re to ensure continuity)
		if (Re_f>1500 && Re_g > 1500)
			C=20.0;
		else if (Re_f<1500 && Re_g>1500)
			C=12.0;
		else if (Re_f>1500 && Re_g<1500)
			C=10.0;
		else
			C=5.0;

	// 6. Two-phase multipliers for each phase
		phi_g2=1.+C*X+X*X;
		phi_f2=1.+C/X+1./(X*X);
		
	// 7. Find gradient
		if (dpdz_g*phi_g2>dpdz_f*phi_f2)
			*dpdz=dpdz_g*phi_g2;
		else
			*dpdz=dpdz_f*phi_f2;

	// 8. Void Fraction
		*alpha=1.-X/sqrt(X*X+20*X+1);
}
void WavyLouveredFins(struct FinHTCDPInputsVals *Inputs)
{
    double D, Re_D, s, Af, A_1fin, Ac, Atube, pf, t, Pt, Pl, 
	pd, xf, j, Pr, Ltube, A_duct, FPI, FPM, mu_ha,Ntubes_bank, Nfin, Nbank,Temp, 
	Tdp, p, W, RH, v, RHin,Vdot_ha, umax, rho_ha, k_ha,Tfilm,sec_theta, Height, 
	k_fin, r, rf_r, X_T, X_D, m, phi, eta_f,h_ha,h_a,eta_o,A,mdot_ha,cp_ha,fa_total,
	DeltaP_air,cs_cp,G_c;


		/*
        || -    xf    ->
        ^              ==                          ==
        |           ==  |  ==                  ==
        Pd       ==     |     ==            ==
        |     ==        |        ==     ==
        =  ==           s             ==  
                        |
                        |
                        |
                       ==                        ==
                    ==     ==                 ==
                 ==           ==           ==
              ==                 ==     ==
           ==                        ==  
        
         t: thickness of fin plate
         Pf: fin pitch (centerline-to-centerline distance between fins)
         Pd: indentation for waviness (not including fin thickness)
         s: fin spacing (free space between fins) = Pf-t
        
        
        
                     |--       Pl      -|
                    ___                 |
                  /     \               |
           =     |       |              |
           |      \ ___ /               |
           |                            |
           |                           ___      
           |                         /     \      |
          Pt                        |       |     D
           |                         \ ___ /      |
           |    
           |        ___
           |      /     \
           =     |       |
                  \ ___ /
        */

        /*
		Default parameters

		// Tube parameters
        Ntubes_bank = 41  'Tubes per bank
        Nbank = 1 ' Number of tube banks
        Ltube = 2.286 '[m]
        D = 0.007 'tube OD
        Pl = 0.01905 ' Horizontal Spacing between banks (center to center)
        Pt = 0.022225 ' vertical spacing between tubes in a bank (center to center)

		// Fin parameters
        FPI = 25
        pd = 0.001
        xf = 0.001
        t = 0.00011
        k_fin = 237 'W/m-K

		// Air inlet state
        Vdot_ha = 1.7934
        Temp = 308.15 '95 F to K
        p = 101.325
        RHin = 0.5
		*/


        Ntubes_bank =	Inputs->Tubes.Ntubes_bank;		//tubes per bank
        Nbank =			Inputs->Tubes.Nbank;			//Number of banks
        Ltube =			Inputs->Tubes.Ltube;			//length of a single tube
        D =				Inputs->Tubes.D;				//Outer diameter of tube
        Pl =			Inputs->Tubes.Pl;				//Horizontal spacing between banks (center to center)
        Pt =			Inputs->Tubes.Pt;				//Vertical spacing between tubes in a bank (center to center)

        FPI =			Inputs->Fins.FPI;
        pd =			Inputs->Fins.Pd;
        xf =			Inputs->Fins.xf;
        t =				Inputs->Fins.t;
        k_fin =			Inputs->Fins.k_fin;

        Vdot_ha =		Inputs->Air.Vdot_ha;
        Temp =			Inputs->Air.Tmean;
        p =				Inputs->Air.p;
        RHin =			Inputs->Air.RHmean;

		// Check that cs_cp is defined, if so, set it to the value passed in
		if (Inputs->Air.cs_cp>0.01 && Inputs->Air.cs_cp<5)
		{
			cs_cp=Inputs->Air.cs_cp;
		}
		else
		{
			cs_cp=1.0;
		}

        Tfilm = Temp;
        FPM = FPI / 0.0254;
        pf = 1 / FPM;
        s = 1 / FPM - t;

        //Data from Kim 1999 for staggered tube HX
        Height = Pt * (Ntubes_bank);
        A_duct = Height * Ltube;
        Nfin = Ltube * FPM;
        sec_theta = sqrt(xf*xf + pd*pd) / xf;
        Ac = A_duct - t * Nfin * (Height-D*Ntubes_bank) - Ntubes_bank * D * Ltube;
        Atube = Ntubes_bank * Nbank * pi * D * Ltube;
		
        A_1fin = 2.0 * (Height * Pl * Nbank * sec_theta  - Ntubes_bank*Nbank * pi*D*D/4);   //Wetted Area of a single fin
        Af = Nfin * A_1fin;
        A = Af + Ntubes_bank * Nbank * pi * D * (Ltube-Nfin*t);

		// Evaluate the mass flow rate based on inlet conditions
        HumAir(Inputs->Air.Tdb, p, GIVEN_RH, Inputs->Air.RH, &Tdp, &W, &h_ha, &RH, &v);
        rho_ha = (1 + W) / v;
        mdot_ha = Vdot_ha * rho_ha;

        umax = mdot_ha / (rho_ha * Ac);

        //Assuming the transport properties of humid air to be close to dry air (generally error <1%)
        mu_ha = (0.00002082 - 0.00001846) / (350 - 300) * (Tfilm - 300) + 0.00001846	;	//[Pa-s]
        k_ha = (0.03 - 0.0263) / (350 - 300) * (Tfilm - 300) + 0.0263;					//[W/m-K]

        //Humid air enthalpy taken as mass weighted average of saturated vapor and dry air
        cp_ha = (1.006 + W * 1.86)  * 1000;
        Pr = cp_ha * mu_ha / k_ha;

        Re_D = rho_ha * umax * D / mu_ha;
        j = 16.06 * pow(Re_D,-1.02 * (pf / D) - 0.256) * pow(A / Atube, -0.601) * pow(Nbank,-0.069) * pow(pf / D,0.84);
        h_a = j * rho_ha * umax * cp_ha / pow(Pr,2.0/3.0);

		if (Re_D>1e3)
		{
			fa_total=0.264*(0.105+0.708*exp(-Re_D/225.0))*pow(Re_D,-0.637)*pow(A/Atube,0.263)*pow(pf/D,-0.317);
		}
		else
		{
			fa_total=0.768*(0.0494+0.142*exp(-Re_D/1180.0))*pow(Re_D,-0.637)*pow(A/Atube,0.0195)*pow(pf/D,-0.121);
		}

        //Fin efficiency based on analysis in 
        // "FIN EFFICIENCY CALCULATION IN ENHANCED FIN-AND-TUBE HEAT EXCHANGERS IN DRY CONDITIONS"
        // by Thomas PERROTIN, Denis CLODIC, International Congress of Refrigeration 2006
        r = D / 2;
        X_D = sqrt(Pl*Pl + Pt*Pt / 4) / 2;
        X_T = Pt / 2;
        rf_r = 1.27 * X_T / r * sqrt(X_D / X_T - 0.3);
        m = sqrt(2 * h_a * cs_cp / (k_fin * t)); //cs_cp is the correction for heat/mass transfer
        phi = (rf_r - 1) * (1 + 0.35 * log(rf_r));
		//phi = (rf_r - 1) * (1 + (0.3+pow(m*(rf_r*r-r)/2.5,1.5-rf_r/12.0)*(0.26*pow(rf_r,0.3)-0.3)) * log(rf_r));
        eta_f = tanh(m * r * phi) / (m * r * phi);//*cos(m * r * phi);
        eta_o = 1 - Af / A * (1 - eta_f);

		G_c=mdot_ha/Ac;
		DeltaP_air=A/Atube/rho_ha*G_c*G_c/2.0;

		Inputs->Fins.A_a=A;
		Inputs->Fins.cp_a=cp_ha;
		Inputs->Fins.eta_a=eta_o;
		Inputs->Fins.h_a=h_a;
		Inputs->Fins.mdot_a=mdot_ha;
		Inputs->Fins.f_a=fa_total;
		Inputs->Fins.dP_a=DeltaP_air;

        /*'MsgBox("h " & FormatNumber(h, 6) & " W/m^2-K")

        'f_tube = 4 / pi * (0.25 + 0.118 / (St / D - 1) ^ 1.08 * Re_D ^ -0.16) * (St / D - 1)
        'f_fin = 1.455 * Re_D ^ -0.656 * (St / Sl) ^ -0.347 * (s / D) ^ -0.134 * (St / D) ^ 1.23
        'f_total = f_fin * (Af / A) + f_tube * (1 - Af / A) * (1 - t / pf)*/

	}

 //   double PlainFins()
	//{
 //       double St, D, Re_D, f_tube, Sl, s, f_fin, Af, A, pf, t, f_total;

 //       // t: thickness of fin plate
 //       //Data from Kim 1999 for staggered tube HX

 //       f_tube = 4 / pi * (0.25 + 0.118 / (St / D - 1) ^ 1.08 * Re_D ^ -0.16) * (St / D - 1);
 //       f_fin = 1.455 * Re_D ^ -0.656 * (St / Sl) ^ -0.347 * (s / D) ^ -0.134 * (St / D) ^ 1.23;
 //       f_total = f_fin * (Af / A) + f_tube * (1 - Af / A) * (1 - t / pf);

	//}




	