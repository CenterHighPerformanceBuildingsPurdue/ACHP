	

#ifndef PYTHONENTRY_H
#define PYTHONENTRY_H


struct CycleInputVals
{

	double CondenserAirVdot;
    double CondenserAirTdb;
    double CondenserAirp;
    double CondenserAirRH;
    double CondenserTubesNtubes;
    double CondenserTubesNbank;
    double CondenserTubesL;
    double CondenserTubesOD;
    double CondenserTubesID;
    double CondenserTubesPl;
    double CondenserTubesPt;
    double CondenserTubesNcircuit;
	double CondenserFinFPI;
	double CondenserFinxf;
	double CondenserFinpd;
	double CondenserFint;
	double CondenserFink;
	double CondenserFanPower;

	double CompM1;
	double CompM2;
	double CompM3;
	double CompM4;
	double CompM5;
	double CompM6;
	double CompM7;
	double CompM8;
	double CompM9;
	double CompM10;

	double CompP1;
	double CompP2;
	double CompP3;
	double CompP4;
	double CompP5;
	double CompP6;
	double CompP7;
	double CompP8;
	double CompP9;
	double CompP10;

	double Compfp;
	double CompVdot_ratio;

	double IHXLength;
	double IHXAnnOD;
	double IHXAnnID;
	double IHXTubeID;
	double IHXSuperheat;
	int IHXN;

	double IndoorCoilAirVdot;
    double IndoorCoilAirTdb;
    double IndoorCoilAirp;
    double IndoorCoilAirRH;
    double IndoorCoilTubesNtubes;
    double IndoorCoilTubesNbank;
    double IndoorCoilTubesL;
    double IndoorCoilTubesOD;
    double IndoorCoilTubesID;
    double IndoorCoilTubesPl;
    double IndoorCoilTubesPt;
    double IndoorCoilTubesNcircuit;
	double IndoorCoilFinFPI;
	double IndoorCoilFinxf;
	double IndoorCoilFinpd;
	double IndoorCoilFint;
	double IndoorCoilFink;
	double IndoorCoilFanPower;

	double EvaporatorAirVdot;
    double EvaporatorAirTdb;
    double EvaporatorAirp;
    double EvaporatorAirRH;
    double EvaporatorTubesNtubes;
    double EvaporatorTubesNbank;
    double EvaporatorTubesL;
    double EvaporatorTubesOD;
    double EvaporatorTubesID;
    double EvaporatorTubesPl;
    double EvaporatorTubesPt;
    double EvaporatorTubesNcircuit;
	double EvaporatorFinFPI;
	double EvaporatorFinxf;
	double EvaporatorFinpd;
	double EvaporatorFint;
	double EvaporatorFink;
	double EvaporatorDTsh;
	double EvaporatorFanPower;

	double Pumppout;
	double PumpVdot;
	double PumpEff;

	double LineSetL,LineSetOD_supply,LineSetID_supply,LineSetOD_return,
		LineSetID_return,LineSetTubek,LineSetInsult,LineSetInsulk,LineSeth_air,
		LineSetT_air;

	double CycleCharge;
	double DT_subcool;
	double CycleQnominal;

	char *PrimaryRef;
	char *SecondaryRef;
	char *CycleType;
	char *ImposedVariable;

};

struct CycleOutputVals
{
	double COP;

	double CyclePower,CycleCapacity,CycleCOPeff,CycleSHR,CycleCOP,CycleCharge,CycleChargeTarget;

	double TsatCond;
	double TsatEvap;

	double Compressorhin,Compressorhout,CompressorPower,CompressorTin,CompressorTout,Compressormdot,
		Compressorsin,Compressorsout,Compressorpin,Compressorpout;

	double Condenserhin,Condenserhout,Condenserh_superheat,Condenserh_2phase,Condenserh_subcool,
		CondenserQ_superheat,CondenserQ_2phase,CondenserQ_subcool,CondenserQ,CondenserCharge_superheat,
		CondenserCharge_2phase,CondenserCharge_subcool,CondenserAireta_a,CondenserAirh_a,CondenserAirA_a,
		CondenserAirmdot_a,Condenserw_superheat,Condenserw_2phase,Condenserw_subcool,CondenserCharge,
		CondenserAirdP_a,Condensersin,Condensersout,CondenserTin,CondenserTout,Condenserpin, Condenserpout,
		CondenserDP_r,CondenserDP_r_superheat,CondenserDP_r_2phase, CondenserDP_r_subcool;

	double IHXhin_r,IHXhout_r,IHXTin_r,IHXTout_r,IHXQ_superheat,IHXQ_2phase,IHXQ_subcool,IHXQ,
		IHXCharge_superheat,IHXCharge_2phase,IHXCharge_subcool,IHXCharge,IHXh_r_superheat,IHXh_r_2phase,
		IHXh_r_subcool,IHXw_superheat,IHXw_2phase,IHXw_subcool,IHXDP_g_superheat,IHXDP_g_2phase,
		IHXDP_g_subcool,IHXsin_r,IHXsout_r,IHXTout_g,IHXTin_g,IHXh_g_subcool,IHXh_g_2phase,IHXh_g_superheat,
		IHXRe_g_subcool,IHXRe_g_2phase,IHXRe_g_superheat,IHXpin_r,IHXpout_r,IHXxin_r,IHXDP_r,IHXDP_r_superheat,
		IHXDP_r_2phase,IHXDP_r_subcool;

	double IndoorCoilTin_g,IndoorCoilTout_g,IndoorCoilh_g,IndoorCoilRe_g,IndoorCoilDP_g,IndoorCoilQ,
		IndoorCoilAireta_a,IndoorCoilAirh_a,IndoorCoilAirA_a,IndoorCoilAirmdot_a,IndoorCoilAirdP_a,
		IndoorCoilSHR,IndoorCoilAirf_dry,IndoorCoilAirTout;

	double Evaporatorhin_r,Evaporatorhout_r,EvaporatorTin_r,EvaporatorTout_r,EvaporatorQ_superheat,EvaporatorQ_2phase,EvaporatorQ_subcool,EvaporatorQ,
		EvaporatorCharge_superheat,EvaporatorCharge_2phase,EvaporatorCharge_subcool,EvaporatorCharge,Evaporatorh_superheat,Evaporatorh_2phase,
		Evaporatorh_subcool,Evaporatorw_superheat,Evaporatorw_2phase,Evaporatorw_subcool,EvaporatorDP_g_superheat,EvaporatorDP_g_2phase,
		EvaporatorDP_g_subcool,Evaporatorsin_r,Evaporatorsout_r,EvaporatorTout_g,EvaporatorTin_g,Evaporatorh_g_subcool,Evaporatorh_g_2phase,Evaporatorh_g_superheat,
		EvaporatorRe_g_subcool,EvaporatorRe_g_2phase,EvaporatorRe_g_superheat,EvaporatorSHR,EvaporatorAireta_a,EvaporatorAirh_a,EvaporatorAirA_a,EvaporatorAirmdot_a,EvaporatorAirdP_a,
		Evaporatorf_dry,Evaporatorpin_r,Evaporatorpout_r,EvaporatorTout_a,Evaporatorxin_r,EvaporatorDP_r,EvaporatorDP_r_superheat,
		EvaporatorDP_r_2phase,EvaporatorDP_r_subcool;

	double LineSetSupplyTin, LineSetSupplyTout, LineSetSupplyRe, LineSetSupplyh, LineSetSupplyDP,
		LineSetSupplyQ,LineSetSupplyCharge;

	double LineSetReturnTin, LineSetReturnTout, LineSetReturnRe, LineSetReturnh, LineSetReturnDP,
		LineSetReturnQ,LineSetReturnCharge;

	double PumpPower,Pumpmdot,PumpDP;

	int Failed;
	char *FailString;
		
};

int SecondaryCycle (struct CycleInputVals *Inputs, struct CycleOutputVals *Outputs);
//int SetFluids (const char * PrimaryRef, const char *SecondaryRef, struct CycleInputVals *Inputs);

#endif